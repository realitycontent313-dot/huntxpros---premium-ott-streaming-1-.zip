package com.example.data.repository

import com.example.base.FirestoreEmulatorTestBase
import com.example.data.model.CatalogItem
import com.example.data.model.UploadJob
import com.example.data.model.UserProfile
import com.google.firebase.firestore.FirebaseFirestoreException
import java.util.UUID
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking
import kotlinx.coroutines.withTimeout
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test

class HuntXProsRepositoryRuleTest : FirestoreEmulatorTestBase() {

    @Test
    fun ensureUserProfile_and_watchlist_isolatedPerUser() = runBlocking {
        val aliceUid = signInTestUser("alice_${UUID.randomUUID().toString().take(6)}@test.com")
        val aliceRepo = HuntXProsRepository(firestore, auth)

        val saveProfileResult = withTimeout(DEFAULT_TIMEOUT_MS) {
            aliceRepo.ensureOrUpdateUserProfile(
                UserProfile(
                    displayName = "Alice Cinema",
                    preferredLanguage = "hi",
                )
            )
        }
        assertTrue(saveProfileResult.isSuccess)

        val sampleItem = CatalogItem(
            id = "item_${UUID.randomUUID().toString().replace("-", "").take(10)}",
            title = "Open Cinema Feature",
            contentType = "MOVIE",
            posterUrl = "https://example.com/poster.jpg",
            genre = "Sci-Fi",
        )
        val addWatchlist = withTimeout(DEFAULT_TIMEOUT_MS) {
            aliceRepo.toggleWatchlist(sampleItem, currentlySaved = false)
        }
        assertTrue(addWatchlist.isSuccess)

        val emittedWatchlist = withTimeout(FLOW_TIMEOUT_MS) {
            aliceRepo.observeWatchlist(aliceUid).first { list -> list.any { it.contentId == sampleItem.id } }
        }
        assertTrue(emittedWatchlist.any { it.contentId == sampleItem.id })

        // Cross-user access by Bob must fail with PERMISSION_DENIED
        signInTestUser("bob_${UUID.randomUUID().toString().take(6)}@test.com")
        val bobRepo = HuntXProsRepository(firestore, auth)
        var caught: Throwable? = null
        try {
            withTimeout(FLOW_TIMEOUT_MS) {
                bobRepo.observeWatchlist(aliceUid).first()
            }
        } catch (e: Throwable) {
            caught = e
        }
        assertNotNull(caught)
        val fsEx = checkNotNull(caught?.unwrapFirestoreException()) { "Expected FirebaseFirestoreException, got $caught" }
        assertEquals(FirebaseFirestoreException.Code.PERMISSION_DENIED, fsEx.code)
    }

    @Test
    fun nonOwnerViewer_cannotCreateCatalogItem_failsWithPermissionDenied() = runBlocking {
        signInTestUser("viewer_${UUID.randomUUID().toString().take(6)}@test.com")
        val viewerRepo = HuntXProsRepository(firestore, auth)

        val result = withTimeout(DEFAULT_TIMEOUT_MS) {
            viewerRepo.saveCatalogItem(
                CatalogItem(
                    title = "Unauthorized Upload",
                    description = "Viewer attempting admin write",
                    contentType = "MOVIE",
                    genre = "Action",
                    language = "English",
                    releaseYear = 2026L,
                    durationMinutes = 90L,
                    ageRating = "U",
                    posterUrl = "https://example.com/p.jpg",
                    bannerUrl = "https://example.com/b.jpg",
                    streamUrl = "https://test-streams.mux.dev/x36xhzz/x36xhzz.m3u8",
                    streamFormat = "HLS",
                    publicationStatus = "PUBLISHED",
                )
            )
        }
        assertTrue(result.isFailure)
        val fsEx = result.exceptionOrNull()?.unwrapFirestoreException()
        assertNotNull(fsEx)
        assertEquals(FirebaseFirestoreException.Code.PERMISSION_DENIED, fsEx?.code)
    }

    @Test
    fun unauthenticatedCaller_observePublishedCatalog_failsWithPermissionDenied() = runBlocking {
        auth.signOut()
        val repo = HuntXProsRepository(firestore, auth)

        var caught: Throwable? = null
        try {
            withTimeout(FLOW_TIMEOUT_MS) {
                repo.observePublishedCatalog().first()
            }
        } catch (e: Throwable) {
            caught = e
        }
        assertNotNull(caught)
        val fsEx = checkNotNull(caught?.unwrapFirestoreException()) { "Expected FirebaseFirestoreException, got $caught" }
        assertEquals(FirebaseFirestoreException.Code.PERMISSION_DENIED, fsEx.code)
    }

    @Test
    fun nonOwnerViewer_cannotCreateOrListUploadJobs_failsWithPermissionDenied() = runBlocking {
        val viewerUid = signInTestUser("viewer_upl_${UUID.randomUUID().toString().take(6)}@test.com")
        val viewerRepo = HuntXProsRepository(firestore, auth)

        val saveJobResult = withTimeout(DEFAULT_TIMEOUT_MS) {
            viewerRepo.saveUploadJob(
                UploadJob(
                    fileName = "unauthorized_viewer_movie.mp4",
                    mimeType = "video/mp4",
                    fileSizeBytes = 4_194_304L,
                    totalChunks = 2L,
                    status = "QUEUED",
                )
            )
        }
        assertTrue(saveJobResult.isFailure)
        assertEquals(
            FirebaseFirestoreException.Code.PERMISSION_DENIED,
            saveJobResult.exceptionOrNull()?.unwrapFirestoreException()?.code,
        )

        var listCaught: Throwable? = null
        try {
            withTimeout(FLOW_TIMEOUT_MS) {
                viewerRepo.observeOwnerUploadJobs(viewerUid).first()
            }
        } catch (e: Throwable) {
            listCaught = e
        }
        assertNotNull(listCaught)
        assertEquals(
            FirebaseFirestoreException.Code.PERMISSION_DENIED,
            listCaught?.unwrapFirestoreException()?.code,
        )
    }

    @Test
    fun nonOwnerViewer_cannotCreateOrListBackupSnapshots_failsWithPermissionDenied() = runBlocking {
        val viewerUid = signInTestUser("viewer_bkp_${UUID.randomUUID().toString().take(6)}@test.com")
        val viewerRepo = HuntXProsRepository(firestore, auth)

        val createSnapResult = withTimeout(DEFAULT_TIMEOUT_MS) {
            viewerRepo.createBackupSnapshot("Unauthorized Viewer Snapshot")
        }
        assertTrue(createSnapResult.isFailure)
        assertEquals(
            FirebaseFirestoreException.Code.PERMISSION_DENIED,
            createSnapResult.exceptionOrNull()?.unwrapFirestoreException()?.code,
        )

        var listCaught: Throwable? = null
        try {
            withTimeout(FLOW_TIMEOUT_MS) {
                viewerRepo.observeBackupSnapshots(viewerUid).first()
            }
        } catch (e: Throwable) {
            listCaught = e
        }
        assertNotNull(listCaught)
        assertEquals(
            FirebaseFirestoreException.Code.PERMISSION_DENIED,
            listCaught?.unwrapFirestoreException()?.code,
        )
    }

    private companion object {
        const val DEFAULT_TIMEOUT_MS = 5000L
        const val FLOW_TIMEOUT_MS = 4000L
    }
}
