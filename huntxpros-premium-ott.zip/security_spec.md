# HUNTXPROS Zero-Trust Firestore Security Specification

## 1. Data Invariants
1. **Single-Owner Administration (`isOwnerAdmin`)**: Administrative mutations (`catalog_items`, `episodes`, `tv_channels`, `epg_programs`, `upload_jobs`, `platform_config`) are strictly restricted to the verified platform owner (`request.auth.token.email == 'd92139816@gmail.com' && request.auth.token.email_verified == true`) OR a server-provisioned `/admins/{uid}` record. Clients can NEVER create, update, or delete `/admins/{uid}` documents.
2. **No Premature Publishing**: `CatalogItem` and `EpisodeItem` documents with `publicationStatus == 'PUBLISHED'` MUST possess a non-empty `streamUrl` (`data.streamUrl.size() > 0`). Draft, uploading, processing, and unpublished items are invisible to viewers.
3. **Strict Multi-Tenant Viewer Isolation**: `/users/{userId}` and all subcollections (`watchlist`, `watch_history`, `favorite_channels`) are strictly isolated to `request.auth.uid == userId`. Listing `/users` is forbidden (`allow list: if false`).
4. **Query Enforcer Alignment**: Every `allow list` rule evaluates `resource.data` (e.g., `resource.data.publicationStatus == 'PUBLISHED'`, `resource.data.visibility == 'PUBLIC'`, or `resource.data.userId == request.auth.uid`). Blanket `allow list: if isSignedIn()` is strictly prohibited.
5. **Accidental Deletion Safeguard**: `upload_jobs` with `deleteProtected == true` cannot be deleted until `deleteProtected` is explicitly turned off by the owner, and `platform_config` documents cannot be deleted.
6. **Temporal & Structural Integrity**: All timestamps validate `<= request.time`, immutable fields (`createdAt`, `userId`, `ownerId`) cannot change on update, every string enforces `.size()` limits, and every document ID enforces `isValidId()`.

## 2. Dirty Dozen Adversarial Payloads
1. **Unauthenticated Catalog Scrape**: `unauth.collection("catalog_items").where("publicationStatus", "==", "PUBLISHED").get()` -> REJECTED.
2. **Unfiltered Viewer Catalog Query**: `viewer.collection("catalog_items").get()` (missing `publicationStatus == 'PUBLISHED'`) -> REJECTED (Rules are not filters).
3. **Self-Admin Escalation**: `viewer.collection("admins").doc(viewerUid).set({ uid: viewerUid, role: "OWNER" })` -> REJECTED (`allow write: if false`).
4. **Unverified Owner Email Spoof**: Token with `email: "d92139816@gmail.com"` and `email_verified: false` writing to `catalog_items` -> REJECTED.
5. **Viewer Publishing Content**: Authenticated viewer creating or updating `catalog_items` -> REJECTED.
6. **Cross-User Watch History Read**: Alice reading `/users/bob/watch_history/item1` -> REJECTED.
7. **Shadow Ghost Field Injection**: Updating `/users/alice` with `{ displayName: "Alice", isAdmin: true }` -> REJECTED by `hasOnly` and `affectedKeys().hasOnly()`.
8. **Premature Empty-Stream Publish**: Owner creating `catalog_items` with `publicationStatus: "PUBLISHED"` and `streamUrl: ""` -> REJECTED (`streamUrl.size() > 0` required when published).
9. **ID Poisoning Attack**: Writing document ID with >128 chars or special characters -> REJECTED by `isValidId()`.
10. **String Oversize DoS**: Creating comment with 10,000-char text -> REJECTED (`text.size() <= 1000`).
11. **Protected Upload Deletion**: Owner deleting `/upload_jobs/job1` while `deleteProtected == true` -> REJECTED.
12. **Viewer Reading Storage Config**: Viewer reading `/platform_config/storage` -> REJECTED (only `branding` and `system_status` readable by non-admin signed-in viewers).
