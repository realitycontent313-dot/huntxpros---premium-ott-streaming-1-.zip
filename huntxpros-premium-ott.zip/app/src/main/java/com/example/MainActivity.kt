package com.example

import android.app.Application
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.LiveTv
import androidx.compose.material.icons.filled.Movie
import androidx.compose.material.icons.filled.Newspaper
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Tv
import androidx.compose.material.icons.outlined.Home
import androidx.compose.material.icons.outlined.LiveTv
import androidx.compose.material.icons.outlined.Movie
import androidx.compose.material.icons.outlined.Newspaper
import androidx.compose.material.icons.outlined.Person
import androidx.compose.material.icons.outlined.Tv
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.NavigationRail
import androidx.compose.material3.NavigationRailItem
import androidx.compose.material3.NavigationRailItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.credentials.CredentialManager
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.lifecycle.viewmodel.initializer
import androidx.lifecycle.viewmodel.viewModelFactory
import com.example.auth.authStateFlow
import com.example.auth.performSafeSignOut
import com.example.data.local.LocalAppPreferences
import com.example.data.local.PreferencesManager
import com.example.data.model.CatalogItem
import com.example.data.model.UiState
import com.example.data.repository.HuntXProsRepository
import com.example.data.storage.ResumableVideoUploadEngine
import com.example.i18n.LocalStrings
import com.example.ui.screens.AdminModule
import com.example.ui.screens.AdminPanelScreen
import com.example.ui.screens.AuthSignInScreen
import com.example.ui.screens.CategoryCatalogGridScreen
import com.example.ui.screens.CinematicSplashScreen
import com.example.ui.screens.ContentDetailScreen
import com.example.ui.screens.GlobalSearchScreen
import com.example.ui.screens.HomeScreen
import com.example.ui.screens.LiveTvScreen
import com.example.ui.screens.MyListAndHistoryScreen
import com.example.ui.screens.SettingsScreen
import com.example.ui.theme.HuntCrimsonBright
import com.example.ui.theme.HuntCrimsonRed
import com.example.ui.theme.HuntDeepCharcoal
import com.example.ui.theme.HuntMutedSilver
import com.example.ui.theme.HuntPlatinumWhite
import com.example.ui.theme.HuntXProsTheme
import com.example.ui.viewmodel.HuntXProsViewModel
import com.google.firebase.Firebase
import com.google.firebase.auth.FirebaseUser
import com.google.firebase.auth.auth
import com.google.firebase.firestore.FirebaseFirestore
import kotlinx.coroutines.launch

enum class PrimaryNavTab {
    HOME,
    LIVE_TV,
    MOVIES,
    SERIES,
    NEWS,
    MY_LIST,
}

sealed interface OverlayRoute {
    data object None : OverlayRoute
    data class ContentDetail(val contentId: String) : OverlayRoute
    data class CategoryGrid(val sectionType: String) : OverlayRoute
    data object Search : OverlayRoute
    data object Settings : OverlayRoute
    data class Admin(val initialModule: AdminModule? = null) : OverlayRoute
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        val preferencesManager = PreferencesManager(applicationContext)

        setContent {
            val rootPrefs by preferencesManager.preferencesFlow.collectAsStateWithLifecycle(
                initialValue = LocalAppPreferences()
            )
            val scope = rememberCoroutineScope()
            var splashComplete by rememberSaveable { mutableStateOf(false) }
            val currentUser by Firebase.auth.authStateFlow().collectAsStateWithLifecycle(
                initialValue = Firebase.auth.currentUser
            )

            HuntXProsTheme(
                darkTheme = rootPrefs.darkMode,
                languageCode = rootPrefs.languageCode,
            ) {
                when {
                    !splashComplete -> {
                        CinematicSplashScreen(
                            onSplashFinished = { splashComplete = true }
                        )
                    }

                    currentUser == null -> {
                        AuthSignInScreen(
                            currentLanguageCode = rootPrefs.languageCode,
                            onLanguageSelected = { code ->
                                scope.launch { preferencesManager.setLanguage(code) }
                            },
                            onAuthSuccess = { /* authStateFlow automatically transitions */ },
                        )
                    }

                    else -> {
                        AuthenticatedPlatformShell(
                            user = currentUser!!,
                            preferencesManager = preferencesManager,
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun AuthenticatedPlatformShell(
    user: FirebaseUser,
    preferencesManager: PreferencesManager,
) {
    val context = LocalContext.current
    val app = context.applicationContext as Application
    val scope = rememberCoroutineScope()
    val credentialManager = remember(context) { CredentialManager.create(context) }

    val viewModel: HuntXProsViewModel = viewModel(
        key = "huntxpros_vm_${user.uid}",
        factory = remember(user.uid) {
            viewModelFactory {
                initializer {
                    val application = this[ViewModelProvider.AndroidViewModelFactory.APPLICATION_KEY] ?: app
                    val databaseId = application.getString(R.string.firestore_database_id)
                    val namedFirestore = FirebaseFirestore.getInstance(databaseId)
                    HuntXProsViewModel(
                        repository = HuntXProsRepository(
                            db = namedFirestore,
                            auth = Firebase.auth,
                        ),
                        preferencesManager = preferencesManager,
                        uploadEngine = ResumableVideoUploadEngine(application),
                        currentUserId = user.uid,
                        currentUserEmail = user.email,
                        currentUserDisplayName = user.displayName,
                        currentUserPhotoUrl = user.photoUrl?.toString(),
                        isEmailVerified = user.isEmailVerified,
                    )
                }
            }
        }
    )

    val strings = LocalStrings.current
    val snackbarHostState = remember { SnackbarHostState() }

    val bannerMessage by viewModel.bannerMessage.collectAsStateWithLifecycle()
    val prefs by viewModel.localPrefs.collectAsStateWithLifecycle()
    val userProfile by viewModel.userProfile.collectAsStateWithLifecycle()
    val brandingConfig by viewModel.brandingConfig.collectAsStateWithLifecycle()
    val catalogState by viewModel.catalogState.collectAsStateWithLifecycle()
    val channelsState by viewModel.channelsState.collectAsStateWithLifecycle()
    val watchlist by viewModel.watchlist.collectAsStateWithLifecycle()
    val watchHistory by viewModel.watchHistory.collectAsStateWithLifecycle()
    val favoriteChannels by viewModel.favoriteChannels.collectAsStateWithLifecycle()
    val selectedSeriesEpisodes by viewModel.selectedSeriesEpisodes.collectAsStateWithLifecycle()
    val selectedContentLikes by viewModel.selectedContentLikes.collectAsStateWithLifecycle()
    val selectedContentComments by viewModel.selectedContentComments.collectAsStateWithLifecycle()
    val selectedChannelId by viewModel.selectedChannelId.collectAsStateWithLifecycle()
    val selectedChannelEpg by viewModel.selectedChannelEpg.collectAsStateWithLifecycle()
    val ownerCatalog by viewModel.ownerCatalog.collectAsStateWithLifecycle()
    val isBusy by viewModel.isBusy.collectAsStateWithLifecycle()

    var activeTab by rememberSaveable { mutableStateOf(PrimaryNavTab.HOME) }
    var myListInitialSubTab by rememberSaveable { mutableIntStateOf(0) }
    var overlayRoute by remember { mutableStateOf<OverlayRoute>(OverlayRoute.None) }

    LaunchedEffect(bannerMessage) {
        bannerMessage?.let { msg ->
            snackbarHostState.showSnackbar(msg)
            viewModel.showMessage(null)
        }
    }

    val publishedCatalog = (catalogState as? UiState.Success)?.data.orEmpty()
    val publishedChannels = (channelsState as? UiState.Success)?.data.orEmpty()

    val openDetail: (String) -> Unit = { contentId ->
        viewModel.selectContent(contentId)
        overlayRoute = OverlayRoute.ContentDetail(contentId)
    }

    val handleLogout: () -> Unit = {
        performSafeSignOut(
            credentialManager = credentialManager,
            onSignOutComplete = { overlayRoute = OverlayRoute.None },
            scope = scope,
        )
    }

    val navItems = listOf(
        NavDestination(PrimaryNavTab.HOME, strings.home, Icons.Filled.Home, Icons.Outlined.Home, "nav_home"),
        NavDestination(PrimaryNavTab.LIVE_TV, strings.liveTv, Icons.Filled.LiveTv, Icons.Outlined.LiveTv, "nav_live_tv"),
        NavDestination(PrimaryNavTab.MOVIES, strings.movies, Icons.Filled.Movie, Icons.Outlined.Movie, "nav_movies"),
        NavDestination(PrimaryNavTab.SERIES, strings.series, Icons.Filled.Tv, Icons.Outlined.Tv, "nav_series"),
        NavDestination(PrimaryNavTab.NEWS, strings.news, Icons.Filled.Newspaper, Icons.Outlined.Newspaper, "nav_news"),
        NavDestination(PrimaryNavTab.MY_LIST, strings.myList, Icons.Filled.Person, Icons.Outlined.Person, "nav_my_list"),
    )

    val showPrimaryNavigation = overlayRoute == OverlayRoute.None

    BoxWithConstraints(modifier = Modifier.fillMaxSize()) {
        val useSideRail = maxWidth >= 720.dp

        Scaffold(
            contentWindowInsets = WindowInsets.statusBars,
            snackbarHost = { SnackbarHost(hostState = snackbarHostState) },
            bottomBar = {
                if (showPrimaryNavigation && !useSideRail) {
                    NavigationBar(
                        containerColor = HuntDeepCharcoal,
                        windowInsets = WindowInsets.navigationBars,
                        modifier = Modifier.testTag("bottom_navigation_bar"),
                    ) {
                        navItems.forEach { dest ->
                            val selected = activeTab == dest.tab
                            NavigationBarItem(
                                selected = selected,
                                onClick = {
                                    activeTab = dest.tab
                                    if (dest.tab == PrimaryNavTab.MY_LIST) myListInitialSubTab = 0
                                },
                                icon = {
                                    Icon(
                                        imageVector = if (selected) dest.selectedIcon else dest.unselectedIcon,
                                        contentDescription = dest.label,
                                    )
                                },
                                label = {
                                    Text(
                                        text = dest.label,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis,
                                        fontWeight = if (selected) FontWeight.Bold else FontWeight.Normal,
                                    )
                                },
                                colors = NavigationBarItemDefaults.colors(
                                    selectedIconColor = HuntCrimsonBright,
                                    selectedTextColor = HuntCrimsonBright,
                                    indicatorColor = HuntCrimsonRed.copy(alpha = 0.16f),
                                    unselectedIconColor = HuntMutedSilver,
                                    unselectedTextColor = HuntMutedSilver,
                                ),
                                modifier = Modifier.testTag(dest.testTag),
                            )
                        }
                    }
                }
            },
            containerColor = MaterialTheme.colorScheme.background,
        ) { innerPadding ->
            Row(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding),
            ) {
                if (showPrimaryNavigation && useSideRail) {
                    NavigationRail(
                        containerColor = HuntDeepCharcoal,
                        modifier = Modifier
                            .fillMaxHeight()
                            .windowInsetsPadding(WindowInsets.navigationBars)
                            .testTag("side_navigation_rail"),
                    ) {
                        navItems.forEach { dest ->
                            val selected = activeTab == dest.tab
                            NavigationRailItem(
                                selected = selected,
                                onClick = {
                                    activeTab = dest.tab
                                    if (dest.tab == PrimaryNavTab.MY_LIST) myListInitialSubTab = 0
                                },
                                icon = {
                                    Icon(
                                        imageVector = if (selected) dest.selectedIcon else dest.unselectedIcon,
                                        contentDescription = dest.label,
                                    )
                                },
                                label = { Text(dest.label, maxLines = 1) },
                                colors = NavigationRailItemDefaults.colors(
                                    selectedIconColor = HuntCrimsonBright,
                                    selectedTextColor = HuntPlatinumWhite,
                                    indicatorColor = HuntCrimsonRed.copy(alpha = 0.2f),
                                    unselectedIconColor = HuntMutedSilver,
                                    unselectedTextColor = HuntMutedSilver,
                                ),
                                modifier = Modifier.testTag("rail_${dest.testTag}"),
                            )
                        }
                    }
                }

                Box(modifier = Modifier.weight(1f).fillMaxSize()) {
                    when (val currentOverlay = overlayRoute) {
                        is OverlayRoute.ContentDetail -> {
                            val targetItem = publishedCatalog.firstOrNull { it.id == currentOverlay.contentId }
                                ?: ownerCatalog.firstOrNull { it.id == currentOverlay.contentId }

                            if (targetItem != null) {
                                ContentDetailScreen(
                                    item = targetItem,
                                    allCatalog = publishedCatalog,
                                    episodes = selectedSeriesEpisodes,
                                    likes = selectedContentLikes,
                                    comments = selectedContentComments,
                                    watchHistory = watchHistory,
                                    watchlist = watchlist,
                                    prefs = prefs,
                                    brandingConfig = brandingConfig,
                                    currentUserId = viewModel.currentUserId,
                                    isOwnerAdmin = viewModel.isOwnerAdmin,
                                    onBack = {
                                        viewModel.selectContent(null)
                                        overlayRoute = OverlayRoute.None
                                    },
                                    onSelectRelatedContent = openDetail,
                                    onToggleWatchlist = { viewModel.toggleWatchlist(it) },
                                    onToggleLike = { viewModel.toggleLike(it) },
                                    onPostComment = { cid, txt -> viewModel.postComment(cid, txt) },
                                    onDeleteComment = { commentId -> viewModel.deleteComment(commentId) },
                                    onSaveProgress = { epId, title, sub, thumb, sUrl, posMs, durMs ->
                                        viewModel.saveWatchProgress(
                                            contentId = targetItem.id,
                                            episodeId = epId,
                                            contentType = targetItem.contentType,
                                            title = title,
                                            subtitle = sub,
                                            thumbnailUrl = thumb,
                                            streamUrl = sUrl,
                                            positionMs = posMs,
                                            durationMs = durMs,
                                        )
                                    },
                                    onSessionEnded = { watchedSec, completed ->
                                        viewModel.recordPlaybackAnalytics(
                                            contentId = targetItem.id,
                                            contentTitle = targetItem.title,
                                            contentType = targetItem.contentType,
                                            category = targetItem.genre.ifBlank { targetItem.contentType },
                                            watchedSeconds = watchedSec,
                                            completed = completed,
                                            isLiveChannel = false,
                                        )
                                    },
                                )
                            } else {
                                overlayRoute = OverlayRoute.None
                            }
                        }

                        is OverlayRoute.CategoryGrid -> {
                            CategoryCatalogGridScreen(
                                sectionType = currentOverlay.sectionType,
                                catalog = publishedCatalog,
                                onBack = { overlayRoute = OverlayRoute.None },
                                onOpenSearch = { overlayRoute = OverlayRoute.Search },
                                onSelectContent = openDetail,
                            )
                        }

                        OverlayRoute.Search -> {
                            GlobalSearchScreen(
                                catalog = publishedCatalog,
                                channels = publishedChannels,
                                onBack = { overlayRoute = OverlayRoute.None },
                                onSelectContent = openDetail,
                                onSelectChannel = { chId ->
                                    viewModel.selectChannel(chId)
                                    overlayRoute = OverlayRoute.None
                                    activeTab = PrimaryNavTab.LIVE_TV
                                },
                            )
                        }

                        OverlayRoute.Settings -> {
                            SettingsScreen(
                                prefs = prefs,
                                displayName = userProfile?.displayName?.ifBlank { user.displayName ?: "Viewer" }
                                    ?: user.displayName ?: "Viewer",
                                email = user.email.orEmpty(),
                                avatarUrl = userProfile?.avatarUrl ?: user.photoUrl?.toString(),
                                isOwnerAdmin = viewModel.isOwnerAdmin,
                                onBack = { overlayRoute = OverlayRoute.None },
                                onUpdateDisplayName = { viewModel.updateDisplayName(it) },
                                onUpdateLanguage = { viewModel.updateLanguagePreference(it) },
                                onUpdateDarkMode = { viewModel.updateDarkModePreference(it) },
                                onUpdateAutoPlay = { viewModel.updateAutoPlayPreference(it) },
                                onUpdateQuality = { viewModel.updateQualityPreference(it) },
                                onUpdateSubtitle = { viewModel.updateSubtitlePreference(it) },
                                onUpdateNotifications = { viewModel.updateNotificationsPreference(it) },
                                onOpenWatchHistory = {
                                    overlayRoute = OverlayRoute.None
                                    myListInitialSubTab = 1
                                    activeTab = PrimaryNavTab.MY_LIST
                                },
                                onOpenAdminPanel = { overlayRoute = OverlayRoute.Admin() },
                                onLogout = handleLogout,
                            )
                        }

                        is OverlayRoute.Admin -> {
                            AdminPanelScreen(
                                viewModel = viewModel,
                                initialModule = currentOverlay.initialModule,
                                onBackToApp = { overlayRoute = OverlayRoute.None },
                                onPreviewContent = openDetail,
                                onLogout = handleLogout,
                            )
                        }

                        OverlayRoute.None -> {
                            when (activeTab) {
                                PrimaryNavTab.HOME -> {
                                    HomeScreen(
                                        catalogState = catalogState,
                                        channelsState = channelsState,
                                        watchHistory = watchHistory,
                                        watchlist = watchlist,
                                        brandingConfig = brandingConfig,
                                        userDisplayName = userProfile?.displayName?.ifBlank { user.displayName ?: "Viewer" }
                                            ?: user.displayName ?: "Viewer",
                                        userAvatarUrl = userProfile?.avatarUrl ?: user.photoUrl?.toString(),
                                        isOwnerAdmin = viewModel.isOwnerAdmin,
                                        isBusy = isBusy,
                                        onOpenSearch = { overlayRoute = OverlayRoute.Search },
                                        onOpenSettings = { overlayRoute = OverlayRoute.Settings },
                                        onOpenAdminPanel = { overlayRoute = OverlayRoute.Admin() },
                                        onOpenContentDetail = openDetail,
                                        onOpenCategorySection = { sectionType ->
                                            overlayRoute = OverlayRoute.CategoryGrid(sectionType)
                                        },
                                        onOpenLiveTvChannel = { chId ->
                                            viewModel.selectChannel(chId)
                                            activeTab = PrimaryNavTab.LIVE_TV
                                        },
                                        onToggleWatchlist = { viewModel.toggleWatchlist(it) },
                                        onSeedAuthorizedStreams = { viewModel.seedOpenLicenseTestCatalog() },
                                    )
                                }

                                PrimaryNavTab.LIVE_TV -> {
                                    LiveTvScreen(
                                        channelsState = channelsState,
                                        selectedChannelId = selectedChannelId,
                                        epgPrograms = selectedChannelEpg,
                                        favoriteChannels = favoriteChannels,
                                        prefs = prefs,
                                        brandingConfig = brandingConfig,
                                        isOwnerAdmin = viewModel.isOwnerAdmin,
                                        onSelectChannel = { ch ->
                                            viewModel.selectChannel(ch.id)
                                            viewModel.recordChannelWatched(ch)
                                        },
                                        onToggleFavoriteChannel = { ch -> viewModel.toggleChannelFavorite(ch) },
                                        onRecordChannelSession = { ch, watchedSeconds ->
                                            viewModel.recordPlaybackAnalytics(
                                                contentId = ch.id,
                                                contentTitle = ch.name,
                                                contentType = "LIVE_TV",
                                                category = ch.category,
                                                watchedSeconds = watchedSeconds,
                                                completed = false,
                                                isLiveChannel = true,
                                            )
                                        },
                                        onOpenAdminChannels = {
                                            overlayRoute = OverlayRoute.Admin(AdminModule.CHANNELS)
                                        },
                                    )
                                }

                                PrimaryNavTab.MOVIES -> {
                                    CategoryCatalogGridScreen(
                                        sectionType = "MOVIE",
                                        catalog = publishedCatalog,
                                        onBack = null,
                                        onOpenSearch = { overlayRoute = OverlayRoute.Search },
                                        onSelectContent = openDetail,
                                    )
                                }

                                PrimaryNavTab.SERIES -> {
                                    CategoryCatalogGridScreen(
                                        sectionType = "SERIES",
                                        catalog = publishedCatalog,
                                        onBack = null,
                                        onOpenSearch = { overlayRoute = OverlayRoute.Search },
                                        onSelectContent = openDetail,
                                    )
                                }

                                PrimaryNavTab.NEWS -> {
                                    CategoryCatalogGridScreen(
                                        sectionType = "NEWS",
                                        catalog = publishedCatalog,
                                        onBack = null,
                                        onOpenSearch = { overlayRoute = OverlayRoute.Search },
                                        onSelectContent = openDetail,
                                    )
                                }

                                PrimaryNavTab.MY_LIST -> {
                                    MyListAndHistoryScreen(
                                        watchlist = watchlist,
                                        watchHistory = watchHistory,
                                        favoriteChannels = favoriteChannels,
                                        catalog = publishedCatalog,
                                        initialTab = myListInitialSubTab,
                                        isOwnerAdmin = viewModel.isOwnerAdmin,
                                        onOpenContentDetail = openDetail,
                                        onRemoveWatchlistItem = { entry ->
                                            viewModel.toggleWatchlist(
                                                CatalogItem(
                                                    id = entry.contentId,
                                                    title = entry.title,
                                                    contentType = entry.contentType,
                                                    posterUrl = entry.posterUrl,
                                                    genre = entry.genre,
                                                )
                                            )
                                        },
                                        onOpenLiveChannel = { chId ->
                                            viewModel.selectChannel(chId)
                                            activeTab = PrimaryNavTab.LIVE_TV
                                        },
                                        onOpenSettings = { overlayRoute = OverlayRoute.Settings },
                                        onOpenAdminPanel = { overlayRoute = OverlayRoute.Admin() },
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

private data class NavDestination(
    val tab: PrimaryNavTab,
    val label: String,
    val selectedIcon: ImageVector,
    val unselectedIcon: ImageVector,
    val testTag: String,
)
