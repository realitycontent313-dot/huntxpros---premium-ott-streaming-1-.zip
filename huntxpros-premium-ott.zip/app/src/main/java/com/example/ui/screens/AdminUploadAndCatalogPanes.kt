package com.example.ui.screens

import android.content.Intent
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.CloudUpload
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.FolderOpen
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.LockOpen
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PhotoLibrary
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.PlaylistAdd
import androidx.compose.material.icons.filled.Publish
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Unpublished
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.data.model.CatalogItem
import com.example.data.model.EpisodeItem
import com.example.data.model.UploadJob
import com.example.data.storage.LocalVideoMetadata
import com.example.ui.components.HuntCategoryChip
import com.example.ui.components.HuntGlassButton
import com.example.ui.components.HuntPrimaryButton
import com.example.ui.player.HuntExoPlayerView
import com.example.ui.theme.HuntAmberWarning
import com.example.ui.theme.HuntBorderSubtle
import com.example.ui.theme.HuntCrimsonBright
import com.example.ui.theme.HuntCrimsonRed
import com.example.ui.theme.HuntElevatedCard
import com.example.ui.theme.HuntEmeraldGreen
import com.example.ui.theme.HuntMetallicSilver
import com.example.ui.theme.HuntMutedSilver
import com.example.ui.theme.HuntObsidianBlack
import com.example.ui.theme.HuntPlatinumWhite
import com.example.ui.theme.HuntRoyalGold
import com.example.ui.theme.HuntSurfaceCard
import com.example.ui.viewmodel.HuntXProsViewModel

private val VOD_CONTENT_TYPES = listOf(
    "MOVIE", "SERIES", "SHORT_FILM", "SHOW", "DOCUMENTARY", "NEWS", "SPORTS", "EDUCATIONAL"
)

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun AdminUploadVideosPane(
    viewModel: HuntXProsViewModel,
    uploadJobs: List<UploadJob>,
    isBusy: Boolean,
) {
    val context = LocalContext.current

    var selectedUri by remember { mutableStateOf<Uri?>(null) }
    var inspectedMeta by remember { mutableStateOf<LocalVideoMetadata?>(null) }
    var showLocalPreview by remember { mutableStateOf(false) }

    var draftTitle by remember { mutableStateOf("") }
    var draftDescription by remember { mutableStateOf("") }
    var draftContentType by remember { mutableStateOf("MOVIE") }
    var draftGenre by remember { mutableStateOf("Action") }
    var draftLanguage by remember { mutableStateOf("English") }
    var draftAgeRating by remember { mutableStateOf("U/A 13+") }
    var draftPosterUrl by remember { mutableStateOf("") }
    var draftBannerUrl by remember { mutableStateOf("") }
    var draftStreamUrl by remember { mutableStateOf("") }

    // Zero-permission Android Photo Picker (Gallery)
    val galleryPicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri ->
        if (uri != null) {
            selectedUri = uri
            val meta = viewModel.inspectVideoUri(uri)
            inspectedMeta = meta
            if (draftTitle.isBlank()) {
                draftTitle = meta.fileName.substringBeforeLast(".")
            }
        }
    }

    // Android Storage Access Framework (File Manager / Storage)
    val documentPicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri ->
        if (uri != null) {
            runCatching {
                context.contentResolver.takePersistableUriPermission(
                    uri,
                    Intent.FLAG_GRANT_READ_URI_PERMISSION,
                )
            }
            selectedUri = uri
            val meta = viewModel.inspectVideoUri(uri)
            inspectedMeta = meta
            if (draftTitle.isBlank()) {
                draftTitle = meta.fileName.substringBeforeLast(".")
            }
        }
    }

    LazyColumn(
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp),
        modifier = Modifier
            .fillMaxSize()
            .testTag("admin_upload_videos_pane"),
    ) {
        item {
            Card(
                shape = RoundedCornerShape(18.dp),
                colors = CardDefaults.cardColors(containerColor = HuntSurfaceCard),
                border = BorderStroke(1.dp, HuntBorderSubtle),
                modifier = Modifier.fillMaxWidth(),
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "Mobile Master Video Selection & Chunked Upload",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = HuntPlatinumWhite,
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "Select company-owned master videos (MP4/MOV/MKV) from your phone Gallery or File Manager. Large files stream in 2 MB chunks with SHA-256 integrity hashing so Android memory never overflows.",
                        style = MaterialTheme.typography.bodySmall,
                        color = HuntMutedSilver,
                    )
                    Spacer(modifier = Modifier.height(14.dp))
                    Row(
                        horizontalArrangement = Arrangement.spacedBy(10.dp),
                        modifier = Modifier.fillMaxWidth(),
                    ) {
                        HuntPrimaryButton(
                            text = "Phone Gallery",
                            icon = Icons.Filled.PhotoLibrary,
                            onClick = {
                                galleryPicker.launch(
                                    PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.VideoOnly)
                                )
                            },
                            testTag = "pick_video_gallery_btn",
                            modifier = Modifier.weight(1f),
                        )
                        HuntGlassButton(
                            text = "File Manager",
                            icon = Icons.Filled.FolderOpen,
                            onClick = { documentPicker.launch(arrayOf("video/*")) },
                            testTag = "pick_video_files_btn",
                            modifier = Modifier.weight(1f),
                        )
                    }

                    val meta = inspectedMeta
                    val uri = selectedUri
                    if (meta != null && uri != null) {
                        Spacer(modifier = Modifier.height(14.dp))
                        Surface(
                            shape = RoundedCornerShape(12.dp),
                            color = HuntObsidianBlack,
                            border = BorderStroke(1.dp, HuntEmeraldGreen.copy(alpha = 0.5f)),
                            modifier = Modifier.fillMaxWidth(),
                        ) {
                            Column(modifier = Modifier.padding(12.dp)) {
                                val sizeMb = String.format("%.2f MB", meta.fileSizeBytes / (1024.0 * 1024.0))
                                val chunks = ((meta.fileSizeBytes + 2_097_151L) / 2_097_152L).coerceAtLeast(1L)
                                Text(
                                    text = meta.fileName,
                                    style = MaterialTheme.typography.titleSmall,
                                    fontWeight = FontWeight.Bold,
                                    color = HuntPlatinumWhite,
                                )
                                Text(
                                    text = "Format: ${meta.mimeType} • Size: $sizeMb ($chunks × 2MB chunks) • Est. ${meta.durationMinutes} min • ${meta.widthPx}×${meta.heightPx}",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = HuntEmeraldGreen,
                                )
                                Spacer(modifier = Modifier.height(8.dp))
                                OutlinedButton(
                                    onClick = { showLocalPreview = !showLocalPreview },
                                    shape = RoundedCornerShape(8.dp),
                                ) {
                                    Icon(Icons.Filled.Visibility, contentDescription = null)
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text(if (showLocalPreview) "Hide Local Preview" else "Preview Selected File Before Publishing")
                                }
                                if (showLocalPreview) {
                                    Spacer(modifier = Modifier.height(8.dp))
                                    HuntExoPlayerView(
                                        streamUrl = uri.toString(),
                                        streamFormat = "MP4",
                                        title = meta.fileName,
                                        watermarkEnabled = true,
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }

        // Metadata & Draft Catalog Registration Card
        item {
            Card(
                shape = RoundedCornerShape(18.dp),
                colors = CardDefaults.cardColors(containerColor = HuntSurfaceCard),
                border = BorderStroke(1.dp, HuntBorderSubtle),
                modifier = Modifier.fillMaxWidth(),
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "Content Metadata & Artwork",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = HuntPlatinumWhite,
                    )
                    Spacer(modifier = Modifier.height(10.dp))

                    OutlinedTextField(
                        value = draftTitle,
                        onValueChange = { draftTitle = it },
                        label = { Text("Title *") },
                        singleLine = true,
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("upload_title_input"),
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    OutlinedTextField(
                        value = draftDescription,
                        onValueChange = { draftDescription = it },
                        label = { Text("Synopsis / Description") },
                        minLines = 2,
                        modifier = Modifier.fillMaxWidth(),
                    )
                    Spacer(modifier = Modifier.height(10.dp))
                    Text("Section / Content Type", style = MaterialTheme.typography.labelMedium, color = HuntMetallicSilver)
                    Spacer(modifier = Modifier.height(6.dp))
                    FlowRow(
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                        verticalArrangement = Arrangement.spacedBy(6.dp),
                    ) {
                        VOD_CONTENT_TYPES.forEach { cType ->
                            HuntCategoryChip(
                                label = cType,
                                selected = draftContentType == cType,
                                onClick = { draftContentType = cType },
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(
                            value = draftGenre,
                            onValueChange = { draftGenre = it },
                            label = { Text("Genre") },
                            singleLine = true,
                            modifier = Modifier.weight(1f),
                        )
                        OutlinedTextField(
                            value = draftLanguage,
                            onValueChange = { draftLanguage = it },
                            label = { Text("Language") },
                            singleLine = true,
                            modifier = Modifier.weight(1f),
                        )
                        OutlinedTextField(
                            value = draftAgeRating,
                            onValueChange = { draftAgeRating = it },
                            label = { Text("Age Rating") },
                            singleLine = true,
                            modifier = Modifier.weight(1f),
                        )
                    }

                    Spacer(modifier = Modifier.height(8.dp))
                    OutlinedTextField(
                        value = draftPosterUrl,
                        onValueChange = { draftPosterUrl = it },
                        label = { Text("Poster Image HTTPS URL") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth(),
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    OutlinedTextField(
                        value = draftBannerUrl,
                        onValueChange = { draftBannerUrl = it },
                        label = { Text("Cinematic Hero Banner HTTPS URL") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth(),
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    OutlinedTextField(
                        value = draftStreamUrl,
                        onValueChange = { draftStreamUrl = it },
                        label = { Text("Authorized HLS (.m3u8) / DASH / CDN Stream URL (required to Publish)") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth(),
                    )

                    Spacer(modifier = Modifier.height(14.dp))
                    Row(
                        horizontalArrangement = Arrangement.spacedBy(10.dp),
                        modifier = Modifier.fillMaxWidth(),
                    ) {
                        val uri = selectedUri
                        val meta = inspectedMeta
                        HuntPrimaryButton(
                            text = "Start 2MB Chunk Upload",
                            icon = Icons.Filled.CloudUpload,
                            enabled = uri != null && meta != null,
                            onClick = {
                                if (uri != null && meta != null) {
                                    viewModel.startMobileVideoUpload(
                                        uri = uri,
                                        metadata = meta,
                                        thumbnailUrl = draftPosterUrl,
                                    )
                                }
                            },
                            testTag = "start_chunk_upload_btn",
                            modifier = Modifier.weight(1f),
                        )

                        HuntGlassButton(
                            text = "Save Draft VOD",
                            icon = Icons.Filled.Add,
                            onClick = {
                                if (draftTitle.isBlank()) {
                                    viewModel.showMessage("Please enter a Title before saving.")
                                    return@HuntGlassButton
                                }
                                val item = CatalogItem(
                                    title = draftTitle,
                                    description = draftDescription.ifBlank { "Authorized HUNTXPROS release." },
                                    contentType = draftContentType,
                                    genre = draftGenre,
                                    language = draftLanguage,
                                    ageRating = draftAgeRating,
                                    durationMinutes = inspectedMeta?.durationMinutes ?: 110L,
                                    posterUrl = draftPosterUrl,
                                    bannerUrl = draftBannerUrl.ifBlank { draftPosterUrl },
                                    streamUrl = draftStreamUrl,
                                    streamFormat = if (draftStreamUrl.endsWith(".mpd", true)) "DASH" else if (draftStreamUrl.endsWith(".mp4", true)) "MP4" else "HLS",
                                    publicationStatus = "DRAFT", // Never publish automatically until verified!
                                    fileSizeBytes = inspectedMeta?.fileSizeBytes,
                                )
                                viewModel.saveCatalogItem(item) {
                                    draftTitle = ""
                                    draftDescription = ""
                                }
                            },
                            testTag = "save_draft_vod_btn",
                            modifier = Modifier.weight(1f),
                        )
                    }
                }
            }
        }

        // Active & Historical Upload Jobs Queue
        item {
            Text(
                text = "Resumable Upload Jobs & SHA-256 Verification (${uploadJobs.size})",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = HuntPlatinumWhite,
            )
        }

        if (uploadJobs.isEmpty()) {
            item {
                Text(
                    text = "No mobile upload jobs yet. Select a video above to compute SHA-256 integrity and run chunked upload.",
                    style = MaterialTheme.typography.bodySmall,
                    color = HuntMutedSilver,
                )
            }
        } else {
            items(uploadJobs, key = { it.id }) { job ->
                UploadJobRowCard(
                    job = job,
                    selectedFallbackUri = selectedUri,
                    onPause = { viewModel.pauseUpload(job.id) },
                    onResumeOrRetry = { viewModel.resumeOrRetryUpload(job, selectedUri) },
                    onToggleLock = { viewModel.toggleUploadProtection(job) },
                    onDelete = { viewModel.deleteUploadRecord(job) },
                    onCreateDraftFromJob = {
                        val validHls = job.hlsManifestUrl.startsWith("https://")
                        viewModel.saveCatalogItem(
                            CatalogItem(
                                title = job.fileName.substringBeforeLast("."),
                                description = "Uploaded from mobile (${job.mimeType})",
                                contentType = draftContentType,
                                posterUrl = job.thumbnailUrl,
                                bannerUrl = job.thumbnailUrl,
                                streamUrl = if (validHls) job.hlsManifestUrl else "",
                                publicationStatus = "DRAFT",
                                storageObjectKey = job.masterStoragePath,
                                masterChecksumSha256 = job.sha256Checksum,
                                fileSizeBytes = job.fileSizeBytes,
                            )
                        )
                    },
                )
            }
        }
    }
}

@Composable
private fun UploadJobRowCard(
    job: UploadJob,
    selectedFallbackUri: Uri?,
    onPause: () -> Unit,
    onResumeOrRetry: () -> Unit,
    onToggleLock: () -> Unit,
    onDelete: () -> Unit,
    onCreateDraftFromJob: () -> Unit,
) {
    val progress = if (job.totalChunks > 0L) {
        (job.uploadedChunks.toFloat() / job.totalChunks.toFloat()).coerceIn(0f, 1f)
    } else 0f

    val statusColor = when (job.status) {
        "COMPLETED" -> HuntEmeraldGreen
        "UPLOADING" -> HuntRoyalGold
        "AWAITING_CLOUD_BUCKET", "PAUSED" -> HuntAmberWarning
        else -> HuntCrimsonBright
    }

    Card(
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = HuntSurfaceCard),
        border = BorderStroke(1.dp, HuntBorderSubtle),
        modifier = Modifier
            .fillMaxWidth()
            .testTag("upload_job_card_${job.id}"),
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = job.fileName,
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.Bold,
                        color = HuntPlatinumWhite,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                    )
                    Text(
                        text = "${job.status} • Chunks ${job.uploadedChunks}/${job.totalChunks}",
                        style = MaterialTheme.typography.labelSmall,
                        color = statusColor,
                        fontWeight = FontWeight.Bold,
                    )
                }
                IconButton(
                    onClick = onToggleLock,
                    modifier = Modifier.testTag("upload_lock_btn_${job.id}"),
                ) {
                    Icon(
                        imageVector = if (job.deleteProtected) Icons.Filled.Lock else Icons.Filled.LockOpen,
                        contentDescription = if (job.deleteProtected) "Delete Protected" else "Unlocked",
                        tint = if (job.deleteProtected) HuntEmeraldGreen else HuntAmberWarning,
                    )
                }
                IconButton(
                    onClick = onDelete,
                    modifier = Modifier.testTag("upload_delete_btn_${job.id}"),
                ) {
                    Icon(
                        imageVector = Icons.Filled.Delete,
                        contentDescription = "Delete Upload Record",
                        tint = if (job.deleteProtected) HuntMutedSilver.copy(alpha = 0.4f) else HuntCrimsonBright,
                    )
                }
            }

            Spacer(modifier = Modifier.height(8.dp))
            LinearProgressIndicator(
                progress = { progress },
                color = statusColor,
                trackColor = HuntObsidianBlack,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(6.dp)
                    .clip(RoundedCornerShape(3.dp)),
            )

            if (job.sha256Checksum.isNotBlank()) {
                Spacer(modifier = Modifier.height(6.dp))
                Text(
                    text = "SHA-256: ${job.sha256Checksum.take(28)}...",
                    style = MaterialTheme.typography.labelSmall,
                    color = HuntMetallicSilver,
                )
            }
            if (job.errorMessage.isNotBlank()) {
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = job.errorMessage,
                    style = MaterialTheme.typography.bodySmall,
                    color = HuntAmberWarning,
                )
            }

            Spacer(modifier = Modifier.height(8.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                if (job.status == "UPLOADING") {
                    OutlinedButton(onClick = onPause) {
                        Icon(Icons.Filled.Pause, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Pause")
                    }
                } else if (job.status in listOf("PAUSED", "FAILED", "AWAITING_CLOUD_BUCKET")) {
                    OutlinedButton(onClick = onResumeOrRetry) {
                        Icon(Icons.Filled.Refresh, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(if (job.status == "PAUSED") "Resume" else "Retry")
                    }
                }
                OutlinedButton(onClick = onCreateDraftFromJob) {
                    Icon(Icons.Filled.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Create Draft VOD")
                }
            }
        }
    }
}

@Composable
fun AdminManageContentPane(
    viewModel: HuntXProsViewModel,
    catalog: List<CatalogItem>,
    episodes: List<EpisodeItem>,
    onPreviewContent: (String) -> Unit,
) {
    var filterType by remember { mutableStateOf("ALL") }
    var editingItem by remember { mutableStateOf<CatalogItem?>(null) }
    var managingEpisodesForSeries by remember { mutableStateOf<CatalogItem?>(null) }

    val filtered = remember(catalog, filterType) {
        if (filterType == "ALL") catalog else catalog.filter { it.contentType == filterType }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .testTag("admin_manage_content_pane"),
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween,
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 10.dp),
        ) {
            Text(
                text = "Catalog Titles (${filtered.size})",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = HuntPlatinumWhite,
            )
            HuntPrimaryButton(
                text = "+ Add Title",
                icon = Icons.Filled.Add,
                onClick = { editingItem = CatalogItem(publicationStatus = "DRAFT") },
                testTag = "admin_add_catalog_btn",
            )
        }

        LazyRow(
            contentPadding = PaddingValues(horizontal = 16.dp, vertical = 4.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            items(listOf("ALL") + VOD_CONTENT_TYPES) { typeCode ->
                HuntCategoryChip(
                    label = typeCode,
                    selected = filterType == typeCode,
                    onClick = { filterType = typeCode },
                )
            }
        }

        LazyColumn(
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
            modifier = Modifier.fillMaxSize(),
        ) {
            items(filtered, key = { it.id }) { item ->
                val isPublished = item.publicationStatus == "PUBLISHED"
                Card(
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = HuntSurfaceCard),
                    border = BorderStroke(1.dp, if (isPublished) HuntEmeraldGreen.copy(alpha = 0.4f) else HuntBorderSubtle),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("admin_catalog_row_${item.id}"),
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = item.title,
                                    style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.Bold,
                                    color = HuntPlatinumWhite,
                                )
                                Text(
                                    text = "${item.contentType} • ${item.genre} • ${item.language} • ${item.releaseYear} • ${item.viewsCount} views",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = HuntMutedSilver,
                                )
                            }
                            Surface(
                                shape = RoundedCornerShape(6.dp),
                                color = if (isPublished) HuntEmeraldGreen.copy(alpha = 0.2f) else HuntElevatedCard,
                            ) {
                                Text(
                                    text = item.publicationStatus,
                                    style = MaterialTheme.typography.labelSmall,
                                    color = if (isPublished) HuntEmeraldGreen else HuntAmberWarning,
                                    fontWeight = FontWeight.Bold,
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(10.dp))

                        Row(
                            horizontalArrangement = Arrangement.spacedBy(6.dp),
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            OutlinedButton(
                                onClick = {
                                    if (!isPublished && !item.streamUrl.startsWith("https://")) {
                                        viewModel.showMessage("Cannot publish '${item.title}' until an authorized HTTPS stream URL is attached.")
                                    } else {
                                        val nextStatus = if (isPublished) "UNPUBLISHED" else "PUBLISHED"
                                        viewModel.saveCatalogItem(item.copy(publicationStatus = nextStatus))
                                    }
                                },
                                modifier = Modifier.testTag("toggle_publish_${item.id}"),
                            ) {
                                Icon(
                                    imageVector = if (isPublished) Icons.Filled.Unpublished else Icons.Filled.Publish,
                                    contentDescription = null,
                                    modifier = Modifier.size(16.dp),
                                )
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(if (isPublished) "Unpublish" else "Publish")
                            }

                            if (item.contentType == "SERIES") {
                                val epCount = episodes.count { it.seriesId == item.id }
                                OutlinedButton(
                                    onClick = { managingEpisodesForSeries = item },
                                    modifier = Modifier.testTag("manage_episodes_${item.id}"),
                                ) {
                                    Icon(Icons.Filled.PlaylistAdd, contentDescription = null, modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("Episodes ($epCount)")
                                }
                            }

                            Spacer(modifier = Modifier.weight(1f))

                            IconButton(onClick = { onPreviewContent(item.id) }) {
                                Icon(Icons.Filled.PlayArrow, contentDescription = "Preview", tint = HuntMetallicSilver)
                            }
                            IconButton(onClick = { editingItem = item }) {
                                Icon(Icons.Filled.Edit, contentDescription = "Edit", tint = HuntPlatinumWhite)
                            }
                            IconButton(onClick = { viewModel.deleteCatalogItem(item.id) }) {
                                Icon(Icons.Filled.Delete, contentDescription = "Delete", tint = HuntCrimsonBright)
                            }
                        }
                    }
                }
            }
        }
    }

    editingItem?.let { current ->
        CatalogEditorDialog(
            initial = current,
            onDismiss = { editingItem = null },
            onSave = { updated ->
                if (updated.publicationStatus == "PUBLISHED" && !updated.streamUrl.startsWith("https://")) {
                    viewModel.showMessage("Authorized HTTPS stream URL is required before setting status to PUBLISHED.")
                } else {
                    viewModel.saveCatalogItem(updated) { editingItem = null }
                }
            },
        )
    }

    managingEpisodesForSeries?.let { series ->
        SeriesEpisodesManagerDialog(
            series = series,
            episodes = episodes.filter { it.seriesId == series.id },
            onDismiss = { managingEpisodesForSeries = null },
            onSaveEpisode = { ep -> viewModel.saveEpisode(ep) },
            onDeleteEpisode = { epId -> viewModel.deleteEpisode(epId) },
            onValidationError = { msg -> viewModel.showMessage(msg) },
        )
    }
}

@Composable
private fun CatalogEditorDialog(
    initial: CatalogItem,
    onDismiss: () -> Unit,
    onSave: (CatalogItem) -> Unit,
) {
    var title by remember { mutableStateOf(initial.title) }
    var description by remember { mutableStateOf(initial.description) }
    var contentType by remember { mutableStateOf(initial.contentType) }
    var genre by remember { mutableStateOf(initial.genre) }
    var language by remember { mutableStateOf(initial.language) }
    var yearText by remember { mutableStateOf(initial.releaseYear.toString()) }
    var durationText by remember { mutableStateOf(initial.durationMinutes.toString()) }
    var ageRating by remember { mutableStateOf(initial.ageRating) }
    var posterUrl by remember { mutableStateOf(initial.posterUrl) }
    var bannerUrl by remember { mutableStateOf(initial.bannerUrl) }
    var trailerUrl by remember { mutableStateOf(initial.trailerUrl.orEmpty()) }
    var streamUrl by remember { mutableStateOf(initial.streamUrl) }
    var streamFormat by remember { mutableStateOf(initial.streamFormat) }
    var castText by remember { mutableStateOf(initial.castCrew.joinToString(", ")) }
    var isHero by remember { mutableStateOf(initial.isFeaturedHero) }
    var isTrending by remember { mutableStateOf(initial.isTrending) }
    var isPopular by remember { mutableStateOf(initial.isPopular) }
    var publishNow by remember { mutableStateOf(initial.publicationStatus == "PUBLISHED") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (initial.id.isBlank()) "Create VOD Content" else "Edit '${initial.title}'") },
        text = {
            Column(
                verticalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(430.dp)
                    .verticalScroll(rememberScrollState()),
            ) {
                OutlinedTextField(value = title, onValueChange = { title = it }, label = { Text("Title *") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(value = description, onValueChange = { description = it }, label = { Text("Description") }, minLines = 2, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(value = contentType, onValueChange = { contentType = it.uppercase() }, label = { Text("Type (MOVIE, SERIES, SHORT_FILM, SHOW, NEWS...)") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(value = genre, onValueChange = { genre = it }, label = { Text("Genre") }, singleLine = true, modifier = Modifier.weight(1f))
                    OutlinedTextField(value = language, onValueChange = { language = it }, label = { Text("Language") }, singleLine = true, modifier = Modifier.weight(1f))
                }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(value = yearText, onValueChange = { yearText = it }, label = { Text("Year") }, singleLine = true, modifier = Modifier.weight(1f))
                    OutlinedTextField(value = durationText, onValueChange = { durationText = it }, label = { Text("Duration (m)") }, singleLine = true, modifier = Modifier.weight(1f))
                    OutlinedTextField(value = ageRating, onValueChange = { ageRating = it }, label = { Text("Rating") }, singleLine = true, modifier = Modifier.weight(1f))
                }
                OutlinedTextField(value = posterUrl, onValueChange = { posterUrl = it }, label = { Text("Poster HTTPS URL") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(value = bannerUrl, onValueChange = { bannerUrl = it }, label = { Text("Banner HTTPS URL") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(value = streamUrl, onValueChange = { streamUrl = it }, label = { Text("Authorized Stream HTTPS URL (.m3u8/.mpd/.mp4)") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(value = trailerUrl, onValueChange = { trailerUrl = it }, label = { Text("Trailer HTTPS URL (Optional)") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(value = streamFormat, onValueChange = { streamFormat = it.uppercase() }, label = { Text("Format (HLS, DASH, MP4)") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(value = castText, onValueChange = { castText = it }, label = { Text("Cast & Crew (comma separated)") }, singleLine = true, modifier = Modifier.fillMaxWidth())

                Row(verticalAlignment = Alignment.CenterVertically) {
                    Checkbox(checked = isHero, onCheckedChange = { isHero = it })
                    Text("Hero", style = MaterialTheme.typography.bodySmall)
                    Checkbox(checked = isTrending, onCheckedChange = { isTrending = it })
                    Text("Trending", style = MaterialTheme.typography.bodySmall)
                    Checkbox(checked = isPopular, onCheckedChange = { isPopular = it })
                    Text("Popular", style = MaterialTheme.typography.bodySmall)
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Checkbox(checked = publishNow, onCheckedChange = { publishNow = it })
                    Text("Publish Live to Viewers", fontWeight = FontWeight.Bold)
                }
            }
        },
        confirmButton = {
            TextButton(
                onClick = {
                    if (title.isBlank()) return@TextButton
                    onSave(
                        initial.copy(
                            title = title,
                            description = description,
                            contentType = if (contentType in VOD_CONTENT_TYPES) contentType else "MOVIE",
                            genre = genre,
                            language = language,
                            releaseYear = yearText.toLongOrNull() ?: 2026L,
                            durationMinutes = durationText.toLongOrNull() ?: 120L,
                            ageRating = ageRating,
                            posterUrl = posterUrl,
                            bannerUrl = bannerUrl.ifBlank { posterUrl },
                            trailerUrl = trailerUrl.ifBlank { null },
                            streamUrl = streamUrl,
                            streamFormat = if (streamFormat in listOf("HLS", "DASH", "MP4")) streamFormat else "HLS",
                            castCrew = castText.split(",").map { it.trim() }.filter { it.isNotEmpty() },
                            isFeaturedHero = isHero,
                            isTrending = isTrending,
                            isPopular = isPopular,
                            publicationStatus = if (publishNow) "PUBLISHED" else "DRAFT",
                        )
                    )
                },
            ) {
                Text("Save")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Cancel") }
        },
    )
}

@Composable
private fun SeriesEpisodesManagerDialog(
    series: CatalogItem,
    episodes: List<EpisodeItem>,
    onDismiss: () -> Unit,
    onSaveEpisode: (EpisodeItem) -> Unit,
    onDeleteEpisode: (String) -> Unit,
    onValidationError: (String) -> Unit,
) {
    var seasonText by remember { mutableStateOf("1") }
    var epNumText by remember { mutableStateOf(((episodes.size) + 1).toString()) }
    var epTitle by remember { mutableStateOf("") }
    var epDesc by remember { mutableStateOf("") }
    var epDurationText by remember { mutableStateOf("45") }
    var epThumbUrl by remember { mutableStateOf(series.bannerUrl.ifBlank { series.posterUrl }) }
    var epStreamUrl by remember { mutableStateOf("") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Episodes • ${series.title}") },
        text = {
            Column(
                verticalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(440.dp)
                    .verticalScroll(rememberScrollState()),
            ) {
                Text("Add New Episode", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(value = seasonText, onValueChange = { seasonText = it }, label = { Text("Season #") }, singleLine = true, modifier = Modifier.weight(1f))
                    OutlinedTextField(value = epNumText, onValueChange = { epNumText = it }, label = { Text("Episode #") }, singleLine = true, modifier = Modifier.weight(1f))
                    OutlinedTextField(value = epDurationText, onValueChange = { epDurationText = it }, label = { Text("Min") }, singleLine = true, modifier = Modifier.weight(1f))
                }
                OutlinedTextField(value = epTitle, onValueChange = { epTitle = it }, label = { Text("Episode Title *") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(value = epDesc, onValueChange = { epDesc = it }, label = { Text("Episode Synopsis") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(value = epThumbUrl, onValueChange = { epThumbUrl = it }, label = { Text("Thumbnail HTTPS URL") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(value = epStreamUrl, onValueChange = { epStreamUrl = it }, label = { Text("Authorized HLS/MP4 Stream URL *") }, singleLine = true, modifier = Modifier.fillMaxWidth())

                HuntPrimaryButton(
                    text = "Save & Publish Episode",
                    onClick = {
                        if (epTitle.isBlank() || !epStreamUrl.startsWith("https://")) {
                            onValidationError("Episode Title and valid HTTPS Stream URL are required.")
                            return@HuntPrimaryButton
                        }
                        onSaveEpisode(
                            EpisodeItem(
                                seriesId = series.id,
                                seasonNumber = seasonText.toLongOrNull() ?: 1L,
                                episodeNumber = epNumText.toLongOrNull() ?: 1L,
                                title = epTitle,
                                description = epDesc,
                                thumbnailUrl = epThumbUrl,
                                durationMinutes = epDurationText.toLongOrNull() ?: 45L,
                                streamUrl = epStreamUrl,
                                streamFormat = if (epStreamUrl.endsWith(".mp4", true)) "MP4" else "HLS",
                                publicationStatus = "PUBLISHED",
                            )
                        )
                        epTitle = ""
                        epDesc = ""
                    },
                    modifier = Modifier.fillMaxWidth(),
                )

                Spacer(modifier = Modifier.height(8.dp))
                Text("Existing Episodes (${episodes.size})", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
                episodes.sortedWith(compareBy({ it.seasonNumber }, { it.episodeNumber })).forEach { ep ->
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(HuntObsidianBlack, RoundedCornerShape(8.dp))
                            .padding(8.dp),
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text("S${ep.seasonNumber} E${ep.episodeNumber} • ${ep.title}", style = MaterialTheme.typography.labelLarge, fontWeight = FontWeight.Bold)
                            Text("${ep.durationMinutes}m • ${ep.publicationStatus}", style = MaterialTheme.typography.labelSmall, color = HuntMutedSilver)
                        }
                        IconButton(onClick = { onDeleteEpisode(ep.id) }) {
                            Icon(Icons.Filled.Delete, contentDescription = "Delete Episode", tint = HuntCrimsonBright)
                        }
                    }
                }
            }
        },
        confirmButton = {
            TextButton(onClick = onDismiss) { Text("Done") }
        },
    )
}
