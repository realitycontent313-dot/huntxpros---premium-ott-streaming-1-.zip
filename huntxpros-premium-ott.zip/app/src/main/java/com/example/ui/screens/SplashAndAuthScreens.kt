package com.example.ui.screens

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Hd
import androidx.compose.material.icons.filled.Language
import androidx.compose.material.icons.filled.LiveTv
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Movie
import androidx.compose.material.icons.filled.Tv
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.credentials.CredentialManager
import com.example.R
import com.example.auth.attemptAutoSignIn
import com.example.auth.onGoogleSignInClicked
import com.example.i18n.LocalStrings
import com.example.i18n.SupportedLanguages
import com.example.ui.components.HuntPrimaryButton
import com.example.ui.theme.HuntBorderSubtle
import com.example.ui.theme.HuntCrimsonBright
import com.example.ui.theme.HuntCrimsonDark
import com.example.ui.theme.HuntCrimsonRed
import com.example.ui.theme.HuntDeepCharcoal
import com.example.ui.theme.HuntMetallicSilver
import com.example.ui.theme.HuntMutedSilver
import com.example.ui.theme.HuntObsidianBlack
import com.example.ui.theme.HuntPlatinumWhite
import com.example.ui.theme.HuntRoyalGold
import com.example.ui.theme.HuntSurfaceCard
import kotlinx.coroutines.delay

@Composable
fun CinematicSplashScreen(
    onSplashFinished: () -> Unit,
) {
    val scale = remember { Animatable(0.76f) }
    val alpha = remember { Animatable(0f) }

    LaunchedEffect(Unit) {
        alpha.animateTo(1f, tween(450, easing = FastOutSlowInEasing))
        scale.animateTo(
            targetValue = 1f,
            animationSpec = spring(
                dampingRatio = Spring.DampingRatioMediumBouncy,
                stiffness = Spring.StiffnessLow,
            ),
        )
        delay(850L)
        onSplashFinished()
    }

    Box(
        contentAlignment = Alignment.Center,
        modifier = Modifier
            .fillMaxSize()
            .background(
                Brush.radialGradient(
                    colors = listOf(
                        HuntCrimsonDark.copy(alpha = 0.42f),
                        HuntDeepCharcoal,
                        HuntObsidianBlack,
                    ),
                )
            )
            .testTag("cinematic_splash_screen"),
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            modifier = Modifier
                .scale(scale.value)
                .alpha(alpha.value)
                .padding(24.dp),
        ) {
            Image(
                painter = painterResource(id = R.drawable.huntxpros_logo),
                contentDescription = "HUNTXPROS Official Brand Logo",
                contentScale = ContentScale.Fit,
                modifier = Modifier
                    .size(156.dp)
                    .clip(RoundedCornerShape(28.dp))
                    .border(1.5.dp, HuntCrimsonRed.copy(alpha = 0.7f), RoundedCornerShape(28.dp)),
            )
            Spacer(modifier = Modifier.height(22.dp))
            Text(
                text = buildAnnotatedString {
                    withStyle(SpanStyle(color = HuntPlatinumWhite, fontWeight = FontWeight.Black)) {
                        append("HUNT")
                    }
                    withStyle(SpanStyle(color = HuntCrimsonBright, fontWeight = FontWeight.Black)) {
                        append("X")
                    }
                    withStyle(SpanStyle(color = HuntMetallicSilver, fontWeight = FontWeight.Black)) {
                        append("PROS")
                    }
                },
                style = MaterialTheme.typography.displayMedium.copy(letterSpacing = 3.sp),
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = LocalStrings.current.brandTagline.uppercase(),
                style = MaterialTheme.typography.labelLarge.copy(letterSpacing = 2.5.sp),
                color = HuntRoyalGold,
            )
        }
    }
}

@Composable
fun AuthSignInScreen(
    currentLanguageCode: String,
    onLanguageSelected: (String) -> Unit,
    onAuthSuccess: () -> Unit,
) {
    val context = LocalContext.current
    val strings = LocalStrings.current
    val scope = rememberCoroutineScope()
    val credentialManager = remember(context) { CredentialManager.create(context) }

    var isLoading by remember { mutableStateOf(false) }
    var authError by remember { mutableStateOf<String?>(null) }
    var showLanguageDialog by remember { mutableStateOf(false) }

    LaunchedEffect(Unit) {
        attemptAutoSignIn(
            context = context,
            credentialManager = credentialManager,
            onAuthSuccess = onAuthSuccess,
            onUnauthenticated = {},
            scope = scope,
        )
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    colors = listOf(
                        HuntCrimsonDark.copy(alpha = 0.35f),
                        HuntObsidianBlack,
                        HuntObsidianBlack,
                    )
                )
            )
            .statusBarsPadding()
            .navigationBarsPadding(),
    ) {
        // Top Bar with Language Selector
        Row(
            horizontalArrangement = Arrangement.End,
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 12.dp),
        ) {
            Surface(
                onClick = { showLanguageDialog = true },
                shape = RoundedCornerShape(50),
                color = HuntSurfaceCard,
                border = BorderStroke(1.dp, HuntBorderSubtle),
                modifier = Modifier.testTag("auth_language_button"),
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.padding(horizontal = 14.dp, vertical = 8.dp),
                ) {
                    Icon(
                        imageVector = Icons.Filled.Language,
                        contentDescription = strings.languageLabel,
                        tint = HuntMetallicSilver,
                        modifier = Modifier.size(18.dp),
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    val activeLang = SupportedLanguages.firstOrNull { it.code == currentLanguageCode }
                    Text(
                        text = activeLang?.nativeName ?: "English",
                        style = MaterialTheme.typography.labelLarge,
                        color = HuntPlatinumWhite,
                    )
                }
            }
        }

        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center,
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 24.dp, vertical = 56.dp),
        ) {
            Card(
                shape = RoundedCornerShape(24.dp),
                colors = CardDefaults.cardColors(containerColor = HuntDeepCharcoal.copy(alpha = 0.94f)),
                border = BorderStroke(1.dp, HuntBorderSubtle),
                modifier = Modifier.widthIn(max = 460.dp),
            ) {
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    modifier = Modifier.padding(28.dp),
                ) {
                    Image(
                        painter = painterResource(id = R.drawable.huntxpros_logo),
                        contentDescription = "HUNTXPROS Official Logo",
                        contentScale = ContentScale.Fit,
                        modifier = Modifier
                            .size(116.dp)
                            .clip(RoundedCornerShape(22.dp))
                            .border(1.dp, HuntCrimsonRed.copy(alpha = 0.65f), RoundedCornerShape(22.dp)),
                    )

                    Spacer(modifier = Modifier.height(16.dp))

                    Text(
                        text = buildAnnotatedString {
                            withStyle(SpanStyle(color = HuntPlatinumWhite, fontWeight = FontWeight.Black)) {
                                append("HUNT")
                            }
                            withStyle(SpanStyle(color = HuntCrimsonBright, fontWeight = FontWeight.Black)) {
                                append("X")
                            }
                            withStyle(SpanStyle(color = HuntMetallicSilver, fontWeight = FontWeight.Black)) {
                                append("PROS")
                            }
                        },
                        style = MaterialTheme.typography.headlineLarge.copy(letterSpacing = 2.sp),
                    )

                    Text(
                        text = strings.brandTagline,
                        style = MaterialTheme.typography.labelLarge,
                        color = HuntRoyalGold,
                    )

                    Spacer(modifier = Modifier.height(18.dp))

                    Text(
                        text = strings.signInHeadline,
                        style = MaterialTheme.typography.titleLarge,
                        color = HuntPlatinumWhite,
                        textAlign = TextAlign.Center,
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    Text(
                        text = strings.signInSubhead,
                        style = MaterialTheme.typography.bodyMedium,
                        color = HuntMutedSilver,
                        textAlign = TextAlign.Center,
                    )

                    Spacer(modifier = Modifier.height(20.dp))

                    // Feature Pills matching brand logo badges
                    Row(
                        horizontalArrangement = Arrangement.SpaceEvenly,
                        modifier = Modifier.fillMaxWidth(),
                    ) {
                        AuthFeaturePill(icon = Icons.Filled.Movie, label = strings.movies)
                        AuthFeaturePill(icon = Icons.Filled.LiveTv, label = strings.liveTv)
                        AuthFeaturePill(icon = Icons.Filled.Tv, label = strings.series)
                        AuthFeaturePill(icon = Icons.Filled.Hd, label = "HD / HLS")
                    }

                    Spacer(modifier = Modifier.height(26.dp))

                    HuntPrimaryButton(
                        text = strings.signInWithGoogle,
                        isLoading = isLoading,
                        onClick = {
                            authError = null
                            isLoading = true
                            onGoogleSignInClicked(
                                context = context,
                                credentialManager = credentialManager,
                                onAuthSuccess = {
                                    isLoading = false
                                    onAuthSuccess()
                                },
                                onAuthError = { msg ->
                                    isLoading = false
                                    authError = msg
                                },
                                scope = scope,
                                onAuthCancelled = {
                                    isLoading = false
                                },
                            )
                        },
                        testTag = "google_sign_in_button",
                        modifier = Modifier.fillMaxWidth(),
                    )

                    if (authError != null) {
                        Spacer(modifier = Modifier.height(12.dp))
                        Surface(
                            shape = RoundedCornerShape(10.dp),
                            color = HuntCrimsonDark.copy(alpha = 0.45f),
                            modifier = Modifier.fillMaxWidth(),
                        ) {
                            Text(
                                text = authError.orEmpty(),
                                style = MaterialTheme.typography.bodySmall,
                                color = HuntPlatinumWhite,
                                textAlign = TextAlign.Center,
                                modifier = Modifier.padding(10.dp),
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.Center,
                    ) {
                        Icon(
                            imageVector = Icons.Filled.Lock,
                            contentDescription = null,
                            tint = HuntMutedSilver,
                            modifier = Modifier.size(14.dp),
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "Protected by Google Identity & Zero-Trust Cloud Rules",
                            style = MaterialTheme.typography.labelSmall,
                            color = HuntMutedSilver,
                        )
                    }
                }
            }
        }
    }

    if (showLanguageDialog) {
        AlertDialog(
            onDismissRequest = { showLanguageDialog = false },
            title = { Text(strings.languageLabel) },
            text = {
                Column(modifier = Modifier.verticalScroll(rememberScrollState())) {
                    SupportedLanguages.forEach { lang ->
                        TextButton(
                            onClick = {
                                onLanguageSelected(lang.code)
                                showLanguageDialog = false
                            },
                            modifier = Modifier.fillMaxWidth(),
                        ) {
                            Text(
                                text = "${lang.nativeName} (${lang.englishName})" +
                                    if (lang.code == currentLanguageCode) " ✓" else "",
                                color = if (lang.code == currentLanguageCode) HuntCrimsonBright else MaterialTheme.colorScheme.onSurface,
                            )
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { showLanguageDialog = false }) { Text("Close") }
            },
        )
    }
}

@Composable
private fun AuthFeaturePill(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    label: String,
) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Box(
            contentAlignment = Alignment.Center,
            modifier = Modifier
                .size(40.dp)
                .clip(RoundedCornerShape(10.dp))
                .background(HuntSurfaceCard)
                .border(1.dp, HuntBorderSubtle, RoundedCornerShape(10.dp)),
        ) {
            Icon(
                imageVector = icon,
                contentDescription = label,
                tint = HuntCrimsonBright,
                modifier = Modifier.size(20.dp),
            )
        }
        Spacer(modifier = Modifier.height(4.dp))
        Text(
            text = label,
            style = MaterialTheme.typography.labelSmall,
            color = HuntMetallicSilver,
        )
    }
}
