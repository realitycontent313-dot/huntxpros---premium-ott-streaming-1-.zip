package com.example.ui.viewmodel

import android.net.Uri
import android.util.Log
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.local.LocalAppPreferences
import com.example.data.local.PreferencesManager
import com.example.data.model.AnalyticsSummary
import com.example.data.model.BackupSnapshot
import com.example.data.model.CatalogItem
import com.example.data.model.ContentComment
import com.example.data.model.ContentLike
import com.example.data.model.EpgProgram
import com.example.data.model.EpisodeItem
import com.example.data.model.FavoriteChannelEntry
import com.example.data.model.OWNER_ADMIN_EMAIL
import com.example.data.model.PlatformConfig
import com.example.data.model.StorageHealthStatus
import com.example.data.model.TvChannel
import com.example.data.model.UiState
import com.example.data.model.UploadJob
import com.example.data.model.UserProfile
import com.example.data.model.WatchHistoryEntry
import com.example.data.model.WatchlistEntry
import com.example.data.repository.HuntXProsRepository
import com.example.data.storage.LocalVideoMetadata
import com.example.data.storage.ResumableVideoUploadEngine
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

private const val VM_TAG = "HuntXProsVM"
private const val STOP_TIMEOUT_MS = 5000L

@OptIn(ExperimentalCoroutinesApi::class)
class HuntXProsViewModel(
    private val repository: HuntXProsRepository,
    private val preferencesManager: PreferencesManager,
    private val uploadEngine: ResumableVideoUploadEngine,
    val currentUserId: String,
    val currentUserEmail: String?,
    val currentUserDisplayName: String?,
    val currentUserPhotoUrl: String?,
    val isEmailVerified: Boolean,
) : ViewModel() {

    val isOwnerAdmin: Boolean =
        currentUserEmail?.equals(OWNER_ADMIN_EMAIL, ignoreCase = true) == true && isEmailVerified

    private val _bannerMessage = MutableStateFlow<String?>(null)
    val bannerMessage: StateFlow<String?> = _bannerMessage.asStateFlow()

    private val _isBusy = MutableStateFlow(false)
    val isBusy: StateFlow<Boolean> = _isBusy.asStateFlow()

    val localPrefs: StateFlow<LocalAppPreferences> = preferencesManager.preferencesFlow
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(STOP_TIMEOUT_MS), LocalAppPreferences())

    val userProfile: StateFlow<UserProfile?> = repository.observeUserProfile(currentUserId)
        .catch { e ->
            Log.w(VM_TAG, "Profile stream error", e)
            emit(null)
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(STOP_TIMEOUT_MS), null)

    val brandingConfig: StateFlow<PlatformConfig?> = repository.observeBrandingConfig()
        .catch { emit(null) }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(STOP_TIMEOUT_MS), null)

    val catalogState: StateFlow<UiState<List<CatalogItem>>> = repository.observePublishedCatalog()
        .map<List<CatalogItem>, UiState<List<CatalogItem>>> { UiState.Success(it) }
        .catch { e ->
            Log.w(VM_TAG, "Published catalog stream error", e)
            emit(UiState.Error(e.localizedMessage ?: "Failed to load catalog"))
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(STOP_TIMEOUT_MS), UiState.Loading)

    val channelsState: StateFlow<UiState<List<TvChannel>>> = repository.observePublishedChannels()
        .map<List<TvChannel>, UiState<List<TvChannel>>> { UiState.Success(it) }
        .catch { e ->
            Log.w(VM_TAG, "Published channels stream error", e)
            emit(UiState.Error(e.localizedMessage ?: "Failed to load Live TV channels"))
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(STOP_TIMEOUT_MS), UiState.Loading)

    val watchlist: StateFlow<List<WatchlistEntry>> = repository.observeWatchlist(currentUserId)
        .catch { emit(emptyList()) }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(STOP_TIMEOUT_MS), emptyList())

    val watchHistory: StateFlow<List<WatchHistoryEntry>> = repository.observeWatchHistory(currentUserId)
        .catch { emit(emptyList()) }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(STOP_TIMEOUT_MS), emptyList())

    val favoriteChannels: StateFlow<List<FavoriteChannelEntry>> = repository.observeFavoriteChannels(currentUserId)
        .catch { emit(emptyList()) }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(STOP_TIMEOUT_MS), emptyList())

    // Active Content Detail / Series Episodes / Comments / Likes
    private val _selectedContentId = MutableStateFlow<String?>(null)
    val selectedContentId: StateFlow<String?> = _selectedContentId.asStateFlow()

    val selectedSeriesEpisodes: StateFlow<List<EpisodeItem>> = _selectedContentId
        .flatMapLatest { id ->
            if (id.isNullOrBlank()) flowOf(emptyList())
            else repository.observePublishedEpisodes(id).catch { emit(emptyList()) }
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(STOP_TIMEOUT_MS), emptyList())

    val selectedContentLikes: StateFlow<List<ContentLike>> = _selectedContentId
        .flatMapLatest { id ->
            if (id.isNullOrBlank()) flowOf(emptyList())
            else repository.observeLikesForContent(id).catch { emit(emptyList()) }
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(STOP_TIMEOUT_MS), emptyList())

    val selectedContentComments: StateFlow<List<ContentComment>> = _selectedContentId
        .flatMapLatest { id ->
            if (id.isNullOrBlank()) flowOf(emptyList())
            else repository.observeCommentsForContent(id).catch { emit(emptyList()) }
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(STOP_TIMEOUT_MS), emptyList())

    // Active Live TV Channel & EPG
    private val _selectedChannelId = MutableStateFlow<String?>(null)
    val selectedChannelId: StateFlow<String?> = _selectedChannelId.asStateFlow()

    val selectedChannelEpg: StateFlow<List<EpgProgram>> = _selectedChannelId
        .flatMapLatest { id ->
            if (id.isNullOrBlank()) flowOf(emptyList())
            else repository.observePublishedEpg(id).catch { emit(emptyList()) }
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(STOP_TIMEOUT_MS), emptyList())

    // Owner Admin Streams (Only subscribed when isOwnerAdmin == true)
    val ownerCatalog: StateFlow<List<CatalogItem>> =
        (if (isOwnerAdmin) repository.observeOwnerCatalog(currentUserId) else flowOf(emptyList()))
            .catch { emit(emptyList()) }
            .stateIn(viewModelScope, SharingStarted.WhileSubscribed(STOP_TIMEOUT_MS), emptyList())

    val ownerEpisodes: StateFlow<List<EpisodeItem>> =
        (if (isOwnerAdmin) repository.observeOwnerEpisodes(currentUserId) else flowOf(emptyList()))
            .catch { emit(emptyList()) }
            .stateIn(viewModelScope, SharingStarted.WhileSubscribed(STOP_TIMEOUT_MS), emptyList())

    val ownerChannels: StateFlow<List<TvChannel>> =
        (if (isOwnerAdmin) repository.observeOwnerChannels(currentUserId) else flowOf(emptyList()))
            .catch { emit(emptyList()) }
            .stateIn(viewModelScope, SharingStarted.WhileSubscribed(STOP_TIMEOUT_MS), emptyList())

    val ownerEpg: StateFlow<List<EpgProgram>> =
        (if (isOwnerAdmin) repository.observeOwnerEpg(currentUserId) else flowOf(emptyList()))
            .catch { emit(emptyList()) }
            .stateIn(viewModelScope, SharingStarted.WhileSubscribed(STOP_TIMEOUT_MS), emptyList())

    val ownerUploadJobs: StateFlow<List<UploadJob>> =
        (if (isOwnerAdmin) repository.observeOwnerUploadJobs(currentUserId) else flowOf(emptyList()))
            .catch { emit(emptyList()) }
            .stateIn(viewModelScope, SharingStarted.WhileSubscribed(STOP_TIMEOUT_MS), emptyList())

    val ownerBackupSnapshots: StateFlow<List<BackupSnapshot>> =
        (if (isOwnerAdmin) repository.observeBackupSnapshots(currentUserId) else flowOf(emptyList()))
            .catch { emit(emptyList()) }
            .stateIn(viewModelScope, SharingStarted.WhileSubscribed(STOP_TIMEOUT_MS), emptyList())

    val defaultFirebaseBucket: String = uploadEngine.resolveDefaultFirebaseBucket()

    private val _storageConfig = MutableStateFlow<PlatformConfig?>(null)
    val storageConfig: StateFlow<PlatformConfig?> = _storageConfig.asStateFlow()

    private val _storageHealthStatus = MutableStateFlow<StorageHealthStatus?>(null)
    val storageHealthStatus: StateFlow<StorageHealthStatus?> = _storageHealthStatus.asStateFlow()

    private val _analyticsState = MutableStateFlow<UiState<AnalyticsSummary>>(UiState.Loading)
    val analyticsState: StateFlow<UiState<AnalyticsSummary>> = _analyticsState.asStateFlow()

    // Retain local URI map in memory so Owner can pause/resume/retry active mobile uploads
    private val activeUploadUris = mutableMapOf<String, Uri>()

    init {
        ensureInitialUserProfile()
        if (isOwnerAdmin) {
            refreshStorageConfig()
            refreshAnalytics()
            verifyCloudStorageHealth()
        }
    }

    private fun ensureInitialUserProfile() {
        viewModelScope.launch {
            val prefs = localPrefs.value
            repository.ensureOrUpdateUserProfile(
                UserProfile(
                    userId = currentUserId,
                    displayName = currentUserDisplayName ?: "Viewer",
                    avatarUrl = currentUserPhotoUrl,
                    preferredLanguage = prefs.languageCode,
                    darkMode = prefs.darkMode,
                    autoPlay = prefs.autoPlay,
                    defaultQuality = prefs.defaultQuality,
                    subtitleLanguage = prefs.subtitleLanguage,
                    notificationsEnabled = prefs.notificationsEnabled,
                )
            )
        }
    }

    fun showMessage(msg: String?) {
        _bannerMessage.value = msg
    }

    fun selectContent(contentId: String?) {
        _selectedContentId.value = contentId
    }

    fun selectChannel(channelId: String?) {
        _selectedChannelId.value = channelId
    }

    // -------------------------------------------------------------------------
    // Viewer Actions
    // -------------------------------------------------------------------------
    fun updateDisplayName(newName: String) {
        val current = userProfile.value ?: UserProfile(userId = currentUserId)
        viewModelScope.launch {
            repository.ensureOrUpdateUserProfile(current.copy(displayName = newName.trim().ifBlank { "Viewer" }))
                .onSuccess { showMessage("Profile updated") }
                .onFailure { showMessage(it.localizedMessage ?: "Failed to update profile") }
        }
    }

    fun updateLanguagePreference(code: String) {
        viewModelScope.launch {
            preferencesManager.setLanguage(code)
            val current = userProfile.value ?: UserProfile(
                userId = currentUserId,
                displayName = currentUserDisplayName ?: "Viewer",
            )
            repository.ensureOrUpdateUserProfile(current.copy(preferredLanguage = code))
        }
    }

    fun updateDarkModePreference(enabled: Boolean) {
        viewModelScope.launch {
            preferencesManager.setDarkMode(enabled)
            val current = userProfile.value ?: UserProfile(userId = currentUserId, displayName = currentUserDisplayName ?: "Viewer")
            repository.ensureOrUpdateUserProfile(current.copy(darkMode = enabled))
        }
    }

    fun updateAutoPlayPreference(enabled: Boolean) {
        viewModelScope.launch {
            preferencesManager.setAutoPlay(enabled)
            val current = userProfile.value ?: UserProfile(userId = currentUserId, displayName = currentUserDisplayName ?: "Viewer")
            repository.ensureOrUpdateUserProfile(current.copy(autoPlay = enabled))
        }
    }

    fun updateQualityPreference(quality: String) {
        viewModelScope.launch {
            preferencesManager.setDefaultQuality(quality)
            val current = userProfile.value ?: UserProfile(userId = currentUserId, displayName = currentUserDisplayName ?: "Viewer")
            repository.ensureOrUpdateUserProfile(current.copy(defaultQuality = quality))
        }
    }

    fun updateSubtitlePreference(sub: String) {
        viewModelScope.launch {
            preferencesManager.setSubtitleLanguage(sub)
            val current = userProfile.value ?: UserProfile(userId = currentUserId, displayName = currentUserDisplayName ?: "Viewer")
            repository.ensureOrUpdateUserProfile(current.copy(subtitleLanguage = sub))
        }
    }

    fun updateNotificationsPreference(enabled: Boolean) {
        viewModelScope.launch {
            preferencesManager.setNotificationsEnabled(enabled)
            val current = userProfile.value ?: UserProfile(userId = currentUserId, displayName = currentUserDisplayName ?: "Viewer")
            repository.ensureOrUpdateUserProfile(current.copy(notificationsEnabled = enabled))
        }
    }

    fun toggleWatchlist(item: CatalogItem) {
        val isSaved = watchlist.value.any { it.contentId == item.id }
        viewModelScope.launch {
            repository.toggleWatchlist(item, currentlySaved = isSaved)
                .onSuccess {
                    showMessage(if (isSaved) "Removed from My List" else "Added to My List")
                }
                .onFailure { showMessage(it.localizedMessage ?: "Could not update My List") }
        }
    }

    fun toggleLike(contentId: String) {
        val isLiked = selectedContentLikes.value.any { it.userId == currentUserId }
        viewModelScope.launch {
            repository.toggleLike(contentId, currentlyLiked = isLiked)
        }
    }

    fun postComment(contentId: String, text: String) {
        val author = userProfile.value?.displayName?.ifBlank { currentUserDisplayName ?: "Viewer" }
            ?: currentUserDisplayName ?: "Viewer"
        viewModelScope.launch {
            repository.addComment(contentId, author, text)
                .onSuccess { showMessage("Comment posted") }
                .onFailure { showMessage(it.localizedMessage ?: "Failed to post comment") }
        }
    }

    fun deleteComment(commentId: String) {
        viewModelScope.launch {
            repository.deleteComment(commentId)
        }
    }

    fun saveWatchProgress(
        contentId: String,
        episodeId: String?,
        contentType: String,
        title: String,
        subtitle: String?,
        thumbnailUrl: String,
        streamUrl: String,
        positionMs: Long,
        durationMs: Long,
    ) {
        viewModelScope.launch {
            repository.saveWatchProgress(
                contentId = contentId,
                episodeId = episodeId,
                contentType = contentType,
                title = title,
                subtitle = subtitle,
                thumbnailUrl = thumbnailUrl,
                streamUrl = streamUrl,
                positionMs = positionMs,
                durationMs = durationMs,
            )
        }
    }

    fun recordPlaybackAnalytics(
        contentId: String,
        contentTitle: String,
        contentType: String,
        category: String,
        watchedSeconds: Long,
        completed: Boolean,
        isLiveChannel: Boolean = false,
    ) {
        viewModelScope.launch {
            repository.recordPlaybackSession(
                contentId = contentId,
                contentTitle = contentTitle,
                contentType = contentType,
                category = category,
                watchedSeconds = watchedSeconds,
                completed = completed,
                isLiveChannel = isLiveChannel,
            )
        }
    }

    fun toggleChannelFavorite(channel: TvChannel) {
        val existing = favoriteChannels.value.firstOrNull { it.channelId == channel.id }
        val nextFav = !(existing?.isFavorite ?: false)
        viewModelScope.launch {
            repository.recordChannelInteraction(channel, isFavorite = nextFav)
                .onSuccess { showMessage(if (nextFav) "${channel.name} added to Favorites" else "${channel.name} removed from Favorites") }
        }
    }

    fun recordChannelWatched(channel: TvChannel) {
        val isFav = favoriteChannels.value.firstOrNull { it.channelId == channel.id }?.isFavorite ?: false
        viewModelScope.launch {
            repository.recordChannelInteraction(channel, isFavorite = isFav)
        }
    }

    // -------------------------------------------------------------------------
    // Owner Admin Actions (Server-Side Verified by firestore.rules)
    // -------------------------------------------------------------------------
    fun inspectVideoUri(uri: Uri): LocalVideoMetadata = uploadEngine.inspectSelectedVideo(uri)

    fun startMobileVideoUpload(
        uri: Uri,
        metadata: LocalVideoMetadata,
        thumbnailUrl: String,
        linkedContentId: String = "",
    ) {
        if (!isOwnerAdmin) {
            showMessage("Unauthorized: Only the platform owner can upload content.")
            return
        }
        viewModelScope.launch {
            val storageCfg = _storageConfig.value
            val initialJob = UploadJob(
                fileName = metadata.fileName,
                mimeType = metadata.mimeType,
                fileSizeBytes = metadata.fileSizeBytes.coerceAtLeast(1024L),
                chunkSizeBytes = 2_097_152L,
                totalChunks = ((metadata.fileSizeBytes + 2_097_151L) / 2_097_152L).coerceAtLeast(1L),
                status = "UPLOADING",
                storageProvider = storageCfg?.storageProvider?.ifBlank { "GCS_SIGNED_MULTIPART" } ?: "GCS_SIGNED_MULTIPART",
                thumbnailUrl = thumbnailUrl,
                linkedContentId = linkedContentId,
                deleteProtected = true,
                ownerId = currentUserId,
            )
            repository.saveUploadJob(initialJob)
                .onSuccess { jobId ->
                    val savedJob = initialJob.copy(id = jobId)
                    activeUploadUris[jobId] = uri
                    runUploadWorker(savedJob, uri)
                }
                .onFailure { showMessage(it.localizedMessage ?: "Failed to create upload record") }
        }
    }

    private fun runUploadWorker(job: UploadJob, uri: Uri) {
        viewModelScope.launch {
            val storageCfg = _storageConfig.value
            val finalJob = uploadEngine.processChunkedUpload(
                job = job,
                videoUri = uri,
                signedUploadEndpoint = storageCfg?.signedUploadEndpoint.orEmpty(),
                storageBucket = storageCfg?.masterBucketName.orEmpty(),
                cdnBaseUrl = storageCfg?.cdnBaseUrl.orEmpty(),
                onProgress = { progressJob ->
                    repository.saveUploadJob(progressJob)
                }
            )
            repository.saveUploadJob(finalJob)
            showMessage(
                when (finalJob.status) {
                    "COMPLETED" -> "Upload & SHA-256 verification completed: ${finalJob.fileName}"
                    "AWAITING_CLOUD_BUCKET" -> finalJob.errorMessage.ifBlank {
                        "SHA-256 verified! Activate Firebase Storage (Blaze plan) & publish /storage.rules, or set a Signed Upload Endpoint."
                    }
                    "PAUSED" -> "Upload paused at chunk ${finalJob.uploadedChunks}/${finalJob.totalChunks}"
                    else -> finalJob.errorMessage.ifBlank { "Upload finished with status: ${finalJob.status}" }
                }
            )
        }
    }

    fun pauseUpload(jobId: String) {
        uploadEngine.requestPause(jobId)
    }

    fun resumeOrRetryUpload(job: UploadJob, fallbackUri: Uri? = null) {
        val uri = activeUploadUris[job.id] ?: fallbackUri
        if (uri == null) {
            showMessage("Please re-select '${job.fileName}' from Gallery/File Manager to resume chunk ${job.uploadedChunks + 1}.")
            return
        }
        activeUploadUris[job.id] = uri
        runUploadWorker(job, uri)
    }

    fun toggleUploadProtection(job: UploadJob) {
        viewModelScope.launch {
            repository.saveUploadJob(job.copy(deleteProtected = !job.deleteProtected))
        }
    }

    fun deleteUploadRecord(job: UploadJob) {
        if (job.deleteProtected) {
            showMessage("Delete Lock is ON. Unlock protection first to prevent accidental deletion.")
            return
        }
        viewModelScope.launch {
            repository.deleteUploadJob(job.id)
                .onSuccess { showMessage("Upload record deleted") }
                .onFailure { showMessage(it.localizedMessage ?: "Delete rejected by security rules") }
        }
    }

    fun saveCatalogItem(item: CatalogItem, onSuccess: () -> Unit = {}) {
        viewModelScope.launch {
            _isBusy.value = true
            repository.saveCatalogItem(item)
                .onSuccess {
                    _isBusy.value = false
                    showMessage("Saved '${item.title}' (${item.publicationStatus})")
                    onSuccess()
                }
                .onFailure {
                    _isBusy.value = false
                    showMessage(it.localizedMessage ?: "Failed to save content")
                }
        }
    }

    fun deleteCatalogItem(itemId: String) {
        viewModelScope.launch {
            repository.deleteCatalogItem(itemId)
                .onSuccess { showMessage("Content deleted") }
                .onFailure { showMessage(it.localizedMessage ?: "Delete failed") }
        }
    }

    fun saveEpisode(episode: EpisodeItem, onSuccess: () -> Unit = {}) {
        viewModelScope.launch {
            repository.saveEpisode(episode)
                .onSuccess {
                    showMessage("Episode S${episode.seasonNumber}E${episode.episodeNumber} saved")
                    onSuccess()
                }
                .onFailure { showMessage(it.localizedMessage ?: "Failed to save episode") }
        }
    }

    fun deleteEpisode(episodeId: String) {
        viewModelScope.launch {
            repository.deleteEpisode(episodeId)
                .onSuccess { showMessage("Episode deleted") }
        }
    }

    fun saveTvChannel(channel: TvChannel, onSuccess: () -> Unit = {}) {
        viewModelScope.launch {
            repository.saveTvChannel(channel)
                .onSuccess {
                    showMessage("Channel '${channel.name}' saved")
                    onSuccess()
                }
                .onFailure { showMessage(it.localizedMessage ?: "Failed to save channel") }
        }
    }

    fun deleteTvChannel(channelId: String) {
        viewModelScope.launch {
            repository.deleteTvChannel(channelId)
                .onSuccess { showMessage("Channel deleted") }
        }
    }

    fun saveEpgProgram(program: EpgProgram, onSuccess: () -> Unit = {}) {
        viewModelScope.launch {
            repository.saveEpgProgram(program)
                .onSuccess {
                    showMessage("EPG slot '${program.programTitle}' saved")
                    onSuccess()
                }
                .onFailure { showMessage(it.localizedMessage ?: "Failed to save EPG program") }
        }
    }

    fun deleteEpgProgram(programId: String) {
        viewModelScope.launch {
            repository.deleteEpgProgram(programId)
        }
    }

    fun refreshStorageConfig() {
        if (!isOwnerAdmin) return
        viewModelScope.launch {
            repository.getStorageConfig().onSuccess { _storageConfig.value = it }
        }
    }

    fun saveBrandingAndStorage(branding: PlatformConfig, storage: PlatformConfig) {
        viewModelScope.launch {
            repository.savePlatformConfig("branding", branding.copy(configType = "BRANDING"))
            repository.savePlatformConfig("storage", storage.copy(configType = "STORAGE"))
                .onSuccess {
                    _storageConfig.value = storage
                    showMessage("Branding & Cloud Storage configuration saved")
                    verifyCloudStorageHealth()
                }
                .onFailure { showMessage(it.localizedMessage ?: "Failed to save configuration") }
        }
    }

    fun verifyCloudStorageHealth() {
        if (!isOwnerAdmin) return
        viewModelScope.launch {
            val configuredBucket = _storageConfig.value?.masterBucketName.orEmpty()
            val status = uploadEngine.probeCloudStorageBucketHealth(configuredBucket)
            _storageHealthStatus.value = status
        }
    }

    fun createRecoveryBackupSnapshot(label: String) {
        if (!isOwnerAdmin) return
        viewModelScope.launch {
            _isBusy.value = true
            repository.createBackupSnapshot(label)
                .onSuccess { snapId ->
                    _isBusy.value = false
                    showMessage("Immutable recovery snapshot saved ($snapId)")
                }
                .onFailure {
                    _isBusy.value = false
                    showMessage(it.localizedMessage ?: "Failed to create recovery snapshot")
                }
        }
    }

    fun restoreRecoverySnapshot(snapshot: BackupSnapshot) {
        if (!isOwnerAdmin) return
        viewModelScope.launch {
            _isBusy.value = true
            repository.restoreFromBackupSnapshot(snapshot)
                .onSuccess { restored ->
                    _isBusy.value = false
                    showMessage("Restored $restored catalog, episode, channel & EPG records from '${snapshot.label}'")
                    refreshAnalytics()
                }
                .onFailure {
                    _isBusy.value = false
                    showMessage(it.localizedMessage ?: "Snapshot restore failed")
                }
        }
    }

    fun refreshAnalytics() {
        if (!isOwnerAdmin) return
        viewModelScope.launch {
            _analyticsState.value = UiState.Loading
            repository.loadOwnerAnalytics(currentUserId)
                .onSuccess { _analyticsState.value = UiState.Success(it) }
                .onFailure { _analyticsState.value = UiState.Error(it.localizedMessage ?: "Failed to load analytics") }
        }
    }

    fun seedOpenLicenseTestCatalog() {
        if (!isOwnerAdmin) return
        viewModelScope.launch {
            _isBusy.value = true
            repository.initializeOpenLicensedCatalogForOwner()
                .onSuccess { count ->
                    _isBusy.value = false
                    showMessage("Initialized $count authorized CC-BY open cinema titles, episodes, Live TV test streams & EPG!")
                    refreshAnalytics()
                }
                .onFailure {
                    _isBusy.value = false
                    showMessage(it.localizedMessage ?: "Failed to initialize test streams")
                }
        }
    }
}
