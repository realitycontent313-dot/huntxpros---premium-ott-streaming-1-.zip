package com.example.data.local

import android.content.Context
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.huntDataStore by preferencesDataStore(name = "huntxpros_user_prefs")

data class LocalAppPreferences(
    val languageCode: String = "en",
    val darkMode: Boolean = true,
    val autoPlay: Boolean = true,
    val defaultQuality: String = "AUTO",
    val subtitleLanguage: String = "OFF",
    val notificationsEnabled: Boolean = true,
)

class PreferencesManager(private val context: Context) {
    private val appContext = context.applicationContext

    val preferencesFlow: Flow<LocalAppPreferences> = appContext.huntDataStore.data.map { prefs ->
        LocalAppPreferences(
            languageCode = prefs[KEY_LANGUAGE] ?: "en",
            darkMode = prefs[KEY_DARK_MODE] ?: true,
            autoPlay = prefs[KEY_AUTO_PLAY] ?: true,
            defaultQuality = prefs[KEY_QUALITY] ?: "AUTO",
            subtitleLanguage = prefs[KEY_SUBTITLE] ?: "OFF",
            notificationsEnabled = prefs[KEY_NOTIFICATIONS] ?: true,
        )
    }

    suspend fun setLanguage(code: String) {
        appContext.huntDataStore.edit { it[KEY_LANGUAGE] = code }
    }

    suspend fun setDarkMode(enabled: Boolean) {
        appContext.huntDataStore.edit { it[KEY_DARK_MODE] = enabled }
    }

    suspend fun setAutoPlay(enabled: Boolean) {
        appContext.huntDataStore.edit { it[KEY_AUTO_PLAY] = enabled }
    }

    suspend fun setDefaultQuality(quality: String) {
        appContext.huntDataStore.edit { it[KEY_QUALITY] = quality }
    }

    suspend fun setSubtitleLanguage(lang: String) {
        appContext.huntDataStore.edit { it[KEY_SUBTITLE] = lang }
    }

    suspend fun setNotificationsEnabled(enabled: Boolean) {
        appContext.huntDataStore.edit { it[KEY_NOTIFICATIONS] = enabled }
    }

    private companion object {
        val KEY_LANGUAGE = stringPreferencesKey("language_code")
        val KEY_DARK_MODE = booleanPreferencesKey("dark_mode")
        val KEY_AUTO_PLAY = booleanPreferencesKey("auto_play")
        val KEY_QUALITY = stringPreferencesKey("default_quality")
        val KEY_SUBTITLE = stringPreferencesKey("subtitle_language")
        val KEY_NOTIFICATIONS = booleanPreferencesKey("notifications_enabled")
    }
}
