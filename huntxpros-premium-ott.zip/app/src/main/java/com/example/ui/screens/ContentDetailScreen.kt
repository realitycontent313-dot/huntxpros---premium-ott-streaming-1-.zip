package com.example.ui.screens

import android.content.Intent
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.MovieCreation
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.ThumbUp
import androidx.compose.material.icons.outlined.ThumbUp
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import com.example.data.local.LocalAppPreferences
import com.example.data.model.CatalogItem
import com.example.data.model.ContentComment
import com.example.data.model.ContentLike
import com.example.data.model.EpisodeItem
import com.example.data.model.PlatformConfig
import com.example.data.model.WatchHistoryEntry
import com.example.data.model.WatchlistEntry
import com.example.i18n.LocalStrings
import com.example.ui.components.HuntCategoryChip
import com.example.ui.components.HuntGlassButton
import com.example.ui.components.HuntPrimaryButton
import com.example.ui.components.PosterContentCard
import com.example.ui.player.HuntExoPlayerView
import com.example.ui.theme.HuntBorderSubtle
import com.example.ui.theme.HuntCrimsonBright
import com.example.ui.theme.HuntCrimsonRed
import com.example.ui.theme.HuntElevatedCard
import com.example.ui.theme.HuntMetallicSilver
import com.example.ui.theme.HuntMutedSilver
import com.example.ui.theme.HuntObsidianBlack
import com.example.ui.theme.HuntPlatinumWhite
import com.example.ui.theme.HuntRoyalGold
import com.example.ui.theme.HuntSurfaceCard

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun ContentDetailScreen(
    item: CatalogItem,
    allCatalog: List<CatalogItem>,
    episodes: List<EpisodeItem>,
    likes: List<ContentLike>,
    comments: List<ContentComment>,
    watchHistory: List<WatchHistoryEntry>,
    watchlist: List<WatchlistEntry>,
    prefs: LocalAppPreferences,
    brandingConfig: PlatformConfig?,
    currentUserId: String,
    isOwnerAdmin: Boolean,
    onBack: () -> Unit,
    onSelectRelatedContent: (String) -> Unit,
    onToggleWatchlist: (CatalogItem) -> Unit,
    onToggleLike: (String) -> Unit,
    onPostComment: (String, String) -> Unit,
    onDeleteComment: (String) -> Unit,
    onSaveProgress: (episodeId: String?, title: String, subtitle: String?, thumb: String, streamUrl: String, posMs: Long, durMs: Long) -> Unit,
    onSessionEnded: (watchedSeconds: Long, completed: Boolean) -> Unit,
) {
    val context = LocalContext.current
    val strings = LocalStrings.current

    var isFullscreen by remember { mutableStateOf(false) }
    var playingTrailer by remember { mutableStateOf(false) }
    var activeEpisode by remember(item.id, episodes) {
        mutableStateOf(episodes.firstOrNull())
    }
    var selectedSeason by remember(episodes) {
        mutableLongStateOf(episodes.minOfOrNull { it.seasonNumber } ?: 1L)
    }
    var activeTabIndex by remember { mutableIntStateOf(0) } // 0=Related/Episodes, 1=Comments, 2=More Info, 3=Cast & Crew
    var commentDraft by remember { mutableStateOf("") }

    BackHandler {
        if (isFullscreen) {
            isFullscreen = false
        } else {
            onBack()
        }
    }

    val savedHistory = remember(watchHistory, item.id, activeEpisode?.id) {
        if (activeEpisode != null) {
            watchHistory.firstOrNull { it.contentId == item.id && it.episodeId == activeEpisode?.id }
        } else {
            watchHistory.firstOrNull { it.contentId == item.id }
        }
    }

    val activeStreamUrl = when {
        playingTrailer && !item.trailerUrl.isNullOrBlank() -> item.trailerUrl
        activeEpisode != null -> activeEpisode!!.streamUrl
        else -> item.streamUrl
    }
    val activeStreamFormat = if (activeEpisode != null && !playingTrailer) activeEpisode!!.streamFormat else item.streamFormat
    val activeTitle = when {
        playingTrailer -> "${item.title} (${strings.watchTrailer})"
        activeEpisode != null -> "${item.title} • S${activeEpisode!!.seasonNumber}E${activeEpisode!!.episodeNumber}: ${activeEpisode!!.title}"
        else -> item.title
    }

    val currentEpisodeIdx = episodes.indexOfFirst { it.id == activeEpisode?.id }
    val prevEpisode = if (currentEpisodeIdx > 0) episodes[currentEpisodeIdx - 1] else null
    val nextEpisode = if (currentEpisodeIdx >= 0 && currentEpisodeIdx < episodes.lastIndex) episodes[currentEpisodeIdx + 1] else null

    if (isFullscreen) {
        HuntExoPlayerView(
            streamUrl = activeStreamUrl,
            streamFormat = activeStreamFormat,
            title = activeTitle,
            isLiveStream = false,
            initialPositionMs = if (playingTrailer) 0L else (savedHistory?.positionMs ?: 0L),
            defaultQualityPref = prefs.defaultQuality,
            watermarkEnabled = brandingConfig?.watermarkEnabled ?: true,
            customLogoUrl = brandingConfig?.customLogoUrl.orEmpty(),
            isFullscreen = true,
            onToggleFullscreen = { isFullscreen = it },
            onBackClick = { isFullscreen = false },
            onPreviousItem = prevEpisode?.let { ep -> { activeEpisode = ep; playingTrailer = false } },
            onNextItem = nextEpisode?.let { ep -> { activeEpisode = ep; playingTrailer = false } },
            autoPlayNext = prefs.autoPlay,
            onProgressUpdate = { pos, dur ->
                if (!playingTrailer) {
                    onSaveProgress(
                        activeEpisode?.id,
                        item.title,
                        activeEpisode?.let { "S${it.seasonNumber} E${it.episodeNumber} • ${it.title}" },
                        activeEpisode?.thumbnailUrl?.ifBlank { item.bannerUrl } ?: item.bannerUrl.ifBlank { item.posterUrl },
                        activeStreamUrl,
                        pos,
                        dur,
                    )
                }
            },
            onSessionEnded = onSessionEnded,
            modifier = Modifier.fillMaxSize(),
        )
        return
    }

    val inMyList = watchlist.any { it.contentId == item.id }
    val isLikedByMe = likes.any { it.userId == currentUserId }
    val totalLikes = maxOf(likes.size.toLong(), item.likesCount)
    val relatedItems = remember(allCatalog, item.id) {
        allCatalog.filter { it.id != item.id && (it.contentType == item.contentType || it.genre == item.genre) }
            .ifEmpty { allCatalog.filter { it.id != item.id } }
            .take(10)
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .testTag("content_detail_screen"),
    ) {
        // Inline Video Player at top matching bottom-left reference screen
        HuntExoPlayerView(
            streamUrl = activeStreamUrl,
            streamFormat = activeStreamFormat,
            title = activeTitle,
            isLiveStream = false,
            initialPositionMs = if (playingTrailer) 0L else (savedHistory?.positionMs ?: 0L),
            defaultQualityPref = prefs.defaultQuality,
            watermarkEnabled = brandingConfig?.watermarkEnabled ?: true,
            customLogoUrl = brandingConfig?.customLogoUrl.orEmpty(),
            isFullscreen = false,
            onToggleFullscreen = { isFullscreen = it },
            onBackClick = onBack,
            onPreviousItem = prevEpisode?.let { ep -> { activeEpisode = ep; playingTrailer = false } },
            onNextItem = nextEpisode?.let { ep -> { activeEpisode = ep; playingTrailer = false } },
            autoPlayNext = prefs.autoPlay,
            onProgressUpdate = { pos, dur ->
                if (!playingTrailer) {
                    onSaveProgress(
                        activeEpisode?.id,
                        item.title,
                        activeEpisode?.let { "S${it.seasonNumber} E${it.episodeNumber} • ${it.title}" },
                        activeEpisode?.thumbnailUrl?.ifBlank { item.bannerUrl } ?: item.bannerUrl.ifBlank { item.posterUrl },
                        activeStreamUrl,
                        pos,
                        dur,
                    )
                }
            },
            onSessionEnded = onSessionEnded,
        )

        LazyColumn(
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp),
            modifier = Modifier.fillMaxSize(),
        ) {
            // Title + Metadata Badges matching reference ("U/A 13+ | HD | Action | Thriller")
            item {
                Text(
                    text = item.title,
                    style = MaterialTheme.typography.headlineMedium,
                    fontWeight = FontWeight.Bold,
                )
                Spacer(modifier = Modifier.height(8.dp))
                FlowRow(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalArrangement = Arrangement.spacedBy(6.dp),
                ) {
                    MetadataBadge(text = item.ageRating, bgColor = HuntElevatedCard, textColor = HuntMetallicSilver)
                    MetadataBadge(text = "HD • ${item.streamFormat}", bgColor = HuntRoyalGold.copy(alpha = 0.2f), textColor = HuntRoyalGold)
                    MetadataBadge(text = "${item.releaseYear}", bgColor = HuntElevatedCard, textColor = HuntMetallicSilver)
                    MetadataBadge(text = "${item.durationMinutes} min", bgColor = HuntElevatedCard, textColor = HuntMetallicSilver)
                    MetadataBadge(text = item.language, bgColor = HuntElevatedCard, textColor = HuntMetallicSilver)
                    item.genre.split("•", ",").map { it.trim() }.filter { it.isNotBlank() }.forEach { g ->
                        MetadataBadge(text = g, bgColor = HuntSurfaceCard, textColor = HuntPlatinumWhite)
                    }
                }
                Spacer(modifier = Modifier.height(10.dp))
                Text(
                    text = item.description,
                    style = MaterialTheme.typography.bodyMedium,
                    color = HuntMetallicSilver,
                )
            }

            // Primary Action Row: Resume/Play, + My List, Like, Trailer, Share
            item {
                LazyRow(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    item {
                        HuntPrimaryButton(
                            text = if ((savedHistory?.positionMs ?: 0L) > 5000L && !playingTrailer) strings.resume else strings.playNow,
                            icon = Icons.Filled.PlayArrow,
                            onClick = { playingTrailer = false },
                            testTag = "detail_play_resume_btn",
                        )
                    }
                    item {
                        HuntGlassButton(
                            text = if (inMyList) strings.inMyList else strings.addToMyList,
                            icon = if (inMyList) Icons.Filled.Check else Icons.Filled.Add,
                            onClick = { onToggleWatchlist(item) },
                            testTag = "detail_mylist_btn",
                        )
                    }
                    item {
                        HuntGlassButton(
                            text = "${if (isLikedByMe) strings.liked else strings.like} ($totalLikes)",
                            icon = if (isLikedByMe) Icons.Filled.ThumbUp else Icons.Outlined.ThumbUp,
                            onClick = { onToggleLike(item.id) },
                            testTag = "detail_like_btn",
                        )
                    }
                    if (!item.trailerUrl.isNullOrBlank()) {
                        item {
                            HuntGlassButton(
                                text = if (playingTrailer) strings.playNow else strings.watchTrailer,
                                icon = Icons.Filled.MovieCreation,
                                onClick = { playingTrailer = !playingTrailer },
                                testTag = "detail_trailer_btn",
                            )
                        }
                    }
                    item {
                        HuntGlassButton(
                            text = strings.share,
                            icon = Icons.Filled.Share,
                            onClick = {
                                val sendIntent = Intent(Intent.ACTION_SEND).apply {
                                    type = "text/plain"
                                    putExtra(Intent.EXTRA_SUBJECT, item.title)
                                    putExtra(
                                        Intent.EXTRA_TEXT,
                                        "Watch '${item.title}' (${item.genre}) on HUNTXPROS — Premium Entertainment!",
                                    )
                                }
                                context.startActivity(Intent.createChooser(sendIntent, strings.share))
                            },
                            testTag = "detail_share_btn",
                        )
                    }
                }
            }

            // Web Series Seasons & Episodes Section
            if (item.contentType == "SERIES" || episodes.isNotEmpty()) {
                val seasons = episodes.map { it.seasonNumber }.distinct().sorted().ifEmpty { listOf(1L) }
                item {
                    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween,
                            modifier = Modifier.fillMaxWidth(),
                        ) {
                            Text(
                                text = "${strings.seasons} & ${strings.episodes}",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                            )
                            if (nextEpisode != null) {
                                Text(
                                    text = "${strings.nextEpisode}: S${nextEpisode.seasonNumber}E${nextEpisode.episodeNumber}",
                                    style = MaterialTheme.typography.labelMedium,
                                    color = HuntCrimsonBright,
                                    modifier = Modifier.clickable {
                                        activeEpisode = nextEpisode
                                        playingTrailer = false
                                    },
                                )
                            }
                        }

                        LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            items(seasons) { sNum ->
                                HuntCategoryChip(
                                    label = "${strings.season} $sNum",
                                    selected = selectedSeason == sNum,
                                    onClick = { selectedSeason = sNum },
                                )
                            }
                        }

                        val seasonEps = episodes.filter { it.seasonNumber == selectedSeason }
                        if (seasonEps.isEmpty()) {
                            Text(
                                text = "No published episodes in Season $selectedSeason yet.",
                                style = MaterialTheme.typography.bodySmall,
                                color = HuntMutedSilver,
                            )
                        } else {
                            seasonEps.forEach { ep ->
                                val isCurrentEp = activeEpisode?.id == ep.id && !playingTrailer
                                Card(
                                    onClick = {
                                        activeEpisode = ep
                                        playingTrailer = false
                                    },
                                    shape = RoundedCornerShape(12.dp),
                                    colors = CardDefaults.cardColors(
                                        containerColor = if (isCurrentEp) HuntElevatedCard else HuntSurfaceCard
                                    ),
                                    border = BorderStroke(
                                        1.dp,
                                        if (isCurrentEp) HuntCrimsonRed else HuntBorderSubtle,
                                    ),
                                    modifier = Modifier.fillMaxWidth(),
                                ) {
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        modifier = Modifier.padding(10.dp),
                                    ) {
                                        Box(
                                            contentAlignment = Alignment.Center,
                                            modifier = Modifier
                                                .width(110.dp)
                                                .height(64.dp)
                                                .clip(RoundedCornerShape(8.dp))
                                                .background(HuntObsidianBlack),
                                        ) {
                                            if (ep.thumbnailUrl.isNotBlank()) {
                                                AsyncImage(
                                                    model = ep.thumbnailUrl,
                                                    contentDescription = ep.title,
                                                    contentScale = ContentScale.Crop,
                                                    modifier = Modifier.fillMaxSize(),
                                                )
                                            }
                                            Icon(
                                                imageVector = Icons.Filled.PlayArrow,
                                                contentDescription = null,
                                                tint = HuntPlatinumWhite,
                                            )
                                        }
                                        Spacer(modifier = Modifier.width(12.dp))
                                        Column(modifier = Modifier.weight(1f)) {
                                            Text(
                                                text = "E${ep.episodeNumber}. ${ep.title}",
                                                style = MaterialTheme.typography.titleSmall,
                                                fontWeight = FontWeight.Bold,
                                                color = HuntPlatinumWhite,
                                                maxLines = 1,
                                                overflow = TextOverflow.Ellipsis,
                                            )
                                            Text(
                                                text = "${ep.durationMinutes} min • ${ep.streamFormat}",
                                                style = MaterialTheme.typography.labelSmall,
                                                color = HuntCrimsonBright,
                                            )
                                            Text(
                                                text = ep.description,
                                                style = MaterialTheme.typography.bodySmall,
                                                color = HuntMutedSilver,
                                                maxLines = 2,
                                                overflow = TextOverflow.Ellipsis,
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }

            // Detail Sub-Tabs matching bottom-left reference ("Related | Comments | More Info | Cast & Crew")
            item {
                val tabs = listOf(
                    strings.relatedContent,
                    "${strings.comments} (${comments.size})",
                    strings.moreInfo,
                    strings.castAndCrew,
                )
                LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(tabs.indices.toList()) { idx ->
                        HuntCategoryChip(
                            label = tabs[idx],
                            selected = activeTabIndex == idx,
                            onClick = { activeTabIndex = idx },
                        )
                    }
                }
            }

            when (activeTabIndex) {
                0 -> item {
                    if (relatedItems.isEmpty()) {
                        Text(
                            text = "More titles coming soon.",
                            style = MaterialTheme.typography.bodySmall,
                            color = HuntMutedSilver,
                        )
                    } else {
                        LazyRow(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                            items(relatedItems, key = { it.id }) { rel ->
                                PosterContentCard(
                                    item = rel,
                                    onClick = { onSelectRelatedContent(rel.id) },
                                )
                            }
                        }
                    }
                }
                1 -> item {
                    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                        ) {
                            OutlinedTextField(
                                value = commentDraft,
                                onValueChange = { commentDraft = it },
                                placeholder = { Text(strings.addCommentPlaceholder) },
                                singleLine = true,
                                modifier = Modifier
                                    .weight(1f)
                                    .testTag("comment_input_field"),
                            )
                            IconButton(
                                onClick = {
                                    if (commentDraft.isNotBlank()) {
                                        onPostComment(item.id, commentDraft)
                                        commentDraft = ""
                                    }
                                },
                                modifier = Modifier.testTag("post_comment_btn"),
                            ) {
                                Icon(
                                    imageVector = Icons.AutoMirrored.Filled.Send,
                                    contentDescription = strings.post,
                                    tint = HuntCrimsonBright,
                                )
                            }
                        }
                        if (comments.isEmpty()) {
                            Text(
                                text = "Be the first viewer to comment.",
                                style = MaterialTheme.typography.bodySmall,
                                color = HuntMutedSilver,
                            )
                        } else {
                            comments.forEach { cmt ->
                                Card(
                                    shape = RoundedCornerShape(10.dp),
                                    colors = CardDefaults.cardColors(containerColor = HuntSurfaceCard),
                                    modifier = Modifier.fillMaxWidth(),
                                ) {
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        modifier = Modifier.padding(12.dp),
                                    ) {
                                        Column(modifier = Modifier.weight(1f)) {
                                            Text(
                                                text = cmt.authorName,
                                                style = MaterialTheme.typography.labelLarge,
                                                color = HuntCrimsonBright,
                                            )
                                            Spacer(modifier = Modifier.height(2.dp))
                                            Text(
                                                text = cmt.text,
                                                style = MaterialTheme.typography.bodyMedium,
                                                color = HuntPlatinumWhite,
                                            )
                                        }
                                        if (cmt.userId == currentUserId || isOwnerAdmin) {
                                            IconButton(onClick = { onDeleteComment(cmt.id) }) {
                                                Icon(
                                                    imageVector = Icons.Filled.Delete,
                                                    contentDescription = "Delete comment",
                                                    tint = HuntMutedSilver,
                                                )
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
                2 -> item {
                    Card(
                        shape = RoundedCornerShape(12.dp),
                        colors = CardDefaults.cardColors(containerColor = HuntSurfaceCard),
                        modifier = Modifier.fillMaxWidth(),
                    ) {
                        Column(
                            verticalArrangement = Arrangement.spacedBy(6.dp),
                            modifier = Modifier.padding(14.dp),
                        ) {
                            Text("Content Type: ${item.contentType}", style = MaterialTheme.typography.bodyMedium)
                            Text("Genre: ${item.genre}", style = MaterialTheme.typography.bodyMedium)
                            Text("Language: ${item.language}", style = MaterialTheme.typography.bodyMedium)
                            Text("Release Year: ${item.releaseYear}", style = MaterialTheme.typography.bodyMedium)
                            Text("Duration: ${item.durationMinutes} min", style = MaterialTheme.typography.bodyMedium)
                            Text("Age Rating: ${item.ageRating}", style = MaterialTheme.typography.bodyMedium)
                            Text("Streaming Protocol: ${item.streamFormat}", style = MaterialTheme.typography.bodyMedium)
                            if (item.tags.isNotEmpty()) {
                                Text("Tags: ${item.tags.joinToString(", ")}", style = MaterialTheme.typography.bodySmall, color = HuntMutedSilver)
                            }
                        }
                    }
                }
                3 -> item {
                    Card(
                        shape = RoundedCornerShape(12.dp),
                        colors = CardDefaults.cardColors(containerColor = HuntSurfaceCard),
                        modifier = Modifier.fillMaxWidth(),
                    ) {
                        Column(
                            verticalArrangement = Arrangement.spacedBy(6.dp),
                            modifier = Modifier.padding(14.dp),
                        ) {
                            if (item.castCrew.isEmpty()) {
                                Text("Authorized HUNTXPROS Studio Production", style = MaterialTheme.typography.bodyMedium)
                            } else {
                                item.castCrew.forEach { member ->
                                    Text("• $member", style = MaterialTheme.typography.bodyMedium, color = HuntPlatinumWhite)
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun MetadataBadge(
    text: String,
    bgColor: androidx.compose.ui.graphics.Color,
    textColor: androidx.compose.ui.graphics.Color,
) {
    Surface(
        shape = RoundedCornerShape(6.dp),
        color = bgColor,
        modifier = Modifier.border(1.dp, HuntBorderSubtle, RoundedCornerShape(6.dp)),
    ) {
        Text(
            text = text,
            style = MaterialTheme.typography.labelSmall,
            color = textColor,
            fontWeight = FontWeight.SemiBold,
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
        )
    }
}
