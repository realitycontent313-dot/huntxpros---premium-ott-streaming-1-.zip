package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Backup
import androidx.compose.material.icons.filled.CloudDone
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Publish
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Restore
import androidx.compose.material.icons.filled.Save
import androidx.compose.material.icons.filled.Schedule
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Unpublished
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.data.model.AnalyticsSummary
import com.example.data.model.BackupSnapshot
import com.example.data.model.EpgProgram
import com.example.data.model.OWNER_ADMIN_EMAIL
import com.example.data.model.PlatformConfig
import com.example.data.model.StorageHealthStatus
import com.example.data.model.TvChannel
import com.example.data.model.UiState
import com.example.ui.components.HuntCategoryChip
import com.example.ui.components.HuntGlassButton
import com.example.ui.components.HuntPrimaryButton
import com.example.ui.components.LivePulseBadge
import com.example.ui.player.HuntExoPlayerView
import com.example.ui.theme.HuntAmberWarning
import com.example.ui.theme.HuntBorderSubtle
import com.example.ui.theme.HuntCrimsonBright
import com.example.ui.theme.HuntCrimsonRed
import com.example.ui.theme.HuntElevatedCard
import com.example.ui.theme.HuntEmeraldGreen
import com.example.ui.theme.HuntMetallicSilver
import com.example.ui.theme.HuntMutedSilver
import com.example.ui.theme.HuntObsidianBlack
import com.example.ui.theme.HuntPlatinumWhite
import com.example.ui.theme.HuntRoyalGold
import com.example.ui.theme.HuntSurfaceCard
import com.example.ui.viewmodel.HuntXProsViewModel

private val CHANNEL_CATEGORIES = listOf("SPORTS", "NEWS", "ENTERTAINMENT", "MOVIES", "MUSIC", "EDUCATIONAL")

@Composable
fun AdminTvChannelsPane(
    viewModel: HuntXProsViewModel,
    channels: List<TvChannel>,
    epgPrograms: List<EpgProgram>,
) {
    var editingChannel by remember { mutableStateOf<TvChannel?>(null) }
    var managingEpgChannel by remember { mutableStateOf<TvChannel?>(null) }
    var previewingChannelId by remember { mutableStateOf<String?>(null) }

    LazyColumn(
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
        modifier = Modifier
            .fillMaxSize()
            .testTag("admin_tv_channels_pane"),
    ) {
        item {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
                modifier = Modifier.fillMaxWidth(),
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = "Authorized Live TV Channels (${channels.size})",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = HuntPlatinumWhite,
                    )
                    Text(
                        text = "Configure licensed HLS/DASH television streams & EPG schedules.",
                        style = MaterialTheme.typography.bodySmall,
                        color = HuntMutedSilver,
                    )
                }
                HuntPrimaryButton(
                    text = "+ Add Channel",
                    icon = Icons.Filled.Add,
                    onClick = { editingChannel = TvChannel(publicationStatus = "DRAFT") },
                    testTag = "admin_add_channel_btn",
                )
            }
        }

        items(channels, key = { it.id }) { ch ->
            val isPublished = ch.publicationStatus == "PUBLISHED"
            val chEpgCount = epgPrograms.count { it.channelId == ch.id }
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = HuntSurfaceCard),
                border = BorderStroke(1.dp, if (isPublished) HuntEmeraldGreen.copy(alpha = 0.4f) else HuntBorderSubtle),
                modifier = Modifier.fillMaxWidth(),
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Column(modifier = Modifier.weight(1f)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(
                                    text = ch.name,
                                    style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.Bold,
                                    color = HuntPlatinumWhite,
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                if (ch.isLive) LivePulseBadge()
                            }
                            Text(
                                text = "${ch.category} • ${ch.language} • ${ch.streamFormat} • ${ch.viewsCount} tunes (${ch.watchTimeMinutes}m)",
                                style = MaterialTheme.typography.bodySmall,
                                color = HuntMutedSilver,
                            )
                        }
                        Surface(
                            shape = RoundedCornerShape(6.dp),
                            color = if (isPublished) HuntEmeraldGreen.copy(alpha = 0.2f) else HuntElevatedCard,
                        ) {
                            Text(
                                text = ch.publicationStatus,
                                style = MaterialTheme.typography.labelSmall,
                                color = if (isPublished) HuntEmeraldGreen else HuntAmberWarning,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                            )
                        }
                    }

                    if (previewingChannelId == ch.id && ch.streamUrl.isNotBlank()) {
                        Spacer(modifier = Modifier.height(10.dp))
                        HuntExoPlayerView(
                            streamUrl = ch.streamUrl,
                            streamFormat = ch.streamFormat,
                            title = ch.name,
                            isLiveStream = true,
                        )
                    }

                    Spacer(modifier = Modifier.height(10.dp))
                    Row(
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        OutlinedButton(
                            onClick = {
                                if (!isPublished && !ch.streamUrl.startsWith("https://")) {
                                    viewModel.showMessage("Attach an authorized HTTPS stream URL before publishing '${ch.name}'.")
                                } else {
                                    viewModel.saveTvChannel(
                                        ch.copy(publicationStatus = if (isPublished) "UNPUBLISHED" else "PUBLISHED")
                                    )
                                }
                            },
                        ) {
                            Icon(
                                imageVector = if (isPublished) Icons.Filled.Unpublished else Icons.Filled.Publish,
                                contentDescription = null,
                                modifier = Modifier.size(16.dp),
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(if (isPublished) "Unpublish" else "Publish")
                        }

                        OutlinedButton(onClick = { managingEpgChannel = ch }) {
                            Icon(Icons.Filled.Schedule, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("EPG ($chEpgCount)")
                        }

                        Spacer(modifier = Modifier.weight(1f))

                        IconButton(onClick = { previewingChannelId = if (previewingChannelId == ch.id) null else ch.id }) {
                            Icon(Icons.Filled.PlayArrow, contentDescription = "Test Stream", tint = HuntEmeraldGreen)
                        }
                        IconButton(onClick = { editingChannel = ch }) {
                            Icon(Icons.Filled.Edit, contentDescription = "Edit Channel", tint = HuntPlatinumWhite)
                        }
                        IconButton(onClick = { viewModel.deleteTvChannel(ch.id) }) {
                            Icon(Icons.Filled.Delete, contentDescription = "Delete Channel", tint = HuntCrimsonBright)
                        }
                    }
                }
            }
        }
    }

    editingChannel?.let { initial ->
        TvChannelEditorDialog(
            initial = initial,
            onDismiss = { editingChannel = null },
            onSave = { updated ->
                if (updated.publicationStatus == "PUBLISHED" && !updated.streamUrl.startsWith("https://")) {
                    viewModel.showMessage("Authorized HTTPS stream URL is required to publish a Live TV channel.")
                } else {
                    viewModel.saveTvChannel(updated) { editingChannel = null }
                }
            },
        )
    }

    managingEpgChannel?.let { channel ->
        ChannelEpgEditorDialog(
            channel = channel,
            programs = epgPrograms.filter { it.channelId == channel.id },
            onDismiss = { managingEpgChannel = null },
            onSaveProgram = { prog -> viewModel.saveEpgProgram(prog) },
            onDeleteProgram = { progId -> viewModel.deleteEpgProgram(progId) },
        )
    }
}

@Composable
private fun TvChannelEditorDialog(
    initial: TvChannel,
    onDismiss: () -> Unit,
    onSave: (TvChannel) -> Unit,
) {
    var name by remember { mutableStateOf(initial.name) }
    var logoUrl by remember { mutableStateOf(initial.logoUrl) }
    var desc by remember { mutableStateOf(initial.description) }
    var category by remember { mutableStateOf(initial.category) }
    var language by remember { mutableStateOf(initial.language) }
    var streamUrl by remember { mutableStateOf(initial.streamUrl) }
    var streamFormat by remember { mutableStateOf(initial.streamFormat) }
    var currentProg by remember { mutableStateOf(initial.currentProgramTitle) }
    var currentTime by remember { mutableStateOf(initial.currentProgramTime) }
    var nextProg by remember { mutableStateOf(initial.upcomingProgramTitle) }
    var nextTime by remember { mutableStateOf(initial.upcomingProgramTime) }
    var isFeatured by remember { mutableStateOf(initial.isFeatured) }
    var publishNow by remember { mutableStateOf(initial.publicationStatus == "PUBLISHED") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (initial.id.isBlank()) "Add Authorized TV Channel" else "Edit '${initial.name}'") },
        text = {
            Column(
                verticalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(420.dp)
                    .verticalScroll(rememberScrollState()),
            ) {
                OutlinedTextField(value = name, onValueChange = { name = it }, label = { Text("Channel Name *") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(value = category, onValueChange = { category = it.uppercase() }, label = { Text("Category (SPORTS, NEWS, ENTERTAINMENT, MOVIES, MUSIC, EDUCATIONAL)") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(value = language, onValueChange = { language = it }, label = { Text("Language") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(value = logoUrl, onValueChange = { logoUrl = it }, label = { Text("Logo HTTPS URL") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(value = streamUrl, onValueChange = { streamUrl = it }, label = { Text("Authorized HLS (.m3u8) / DASH Stream URL *") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(value = streamFormat, onValueChange = { streamFormat = it.uppercase() }, label = { Text("Format (HLS, DASH)") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(value = desc, onValueChange = { desc = it }, label = { Text("Channel Description") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(value = currentProg, onValueChange = { currentProg = it }, label = { Text("Current Program") }, singleLine = true, modifier = Modifier.weight(1f))
                    OutlinedTextField(value = currentTime, onValueChange = { currentTime = it }, label = { Text("Slot Time") }, singleLine = true, modifier = Modifier.weight(1f))
                }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(value = nextProg, onValueChange = { nextProg = it }, label = { Text("Upcoming Program") }, singleLine = true, modifier = Modifier.weight(1f))
                    OutlinedTextField(value = nextTime, onValueChange = { nextTime = it }, label = { Text("Next Time") }, singleLine = true, modifier = Modifier.weight(1f))
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Checkbox(checked = isFeatured, onCheckedChange = { isFeatured = it })
                    Text("Featured on Home")
                    Spacer(modifier = Modifier.width(8.dp))
                    Checkbox(checked = publishNow, onCheckedChange = { publishNow = it })
                    Text("Published")
                }
            }
        },
        confirmButton = {
            TextButton(
                onClick = {
                    if (name.isBlank()) return@TextButton
                    onSave(
                        initial.copy(
                            name = name,
                            logoUrl = logoUrl,
                            description = desc,
                            category = if (category in CHANNEL_CATEGORIES) category else "ENTERTAINMENT",
                            language = language,
                            streamUrl = streamUrl,
                            streamFormat = if (streamFormat in listOf("HLS", "DASH")) streamFormat else "HLS",
                            currentProgramTitle = currentProg,
                            currentProgramTime = currentTime,
                            upcomingProgramTitle = nextProg,
                            upcomingProgramTime = nextTime,
                            isFeatured = isFeatured,
                            publicationStatus = if (publishNow) "PUBLISHED" else "DRAFT",
                        )
                    )
                }
            ) { Text("Save") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } },
    )
}

@Composable
private fun ChannelEpgEditorDialog(
    channel: TvChannel,
    programs: List<EpgProgram>,
    onDismiss: () -> Unit,
    onSaveProgram: (EpgProgram) -> Unit,
    onDeleteProgram: (String) -> Unit,
) {
    var progTitle by remember { mutableStateOf("") }
    var synopsis by remember { mutableStateOf("") }
    var startTime by remember { mutableStateOf("18:00") }
    var endTime by remember { mutableStateOf("19:00") }
    var isLiveNow by remember { mutableStateOf(false) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("EPG Schedule • ${channel.name}") },
        text = {
            Column(
                verticalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(400.dp)
                    .verticalScroll(rememberScrollState()),
            ) {
                OutlinedTextField(value = progTitle, onValueChange = { progTitle = it }, label = { Text("Program Title *") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(value = synopsis, onValueChange = { synopsis = it }, label = { Text("Program Synopsis") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(value = startTime, onValueChange = { startTime = it }, label = { Text("Start (HH:MM)") }, singleLine = true, modifier = Modifier.weight(1f))
                    OutlinedTextField(value = endTime, onValueChange = { endTime = it }, label = { Text("End (HH:MM)") }, singleLine = true, modifier = Modifier.weight(1f))
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Checkbox(checked = isLiveNow, onCheckedChange = { isLiveNow = it })
                    Text("Mark as Live Now")
                }
                HuntPrimaryButton(
                    text = "Add Schedule Slot",
                    onClick = {
                        if (progTitle.isBlank()) return@HuntPrimaryButton
                        onSaveProgram(
                            EpgProgram(
                                channelId = channel.id,
                                channelName = channel.name,
                                programTitle = progTitle,
                                synopsis = synopsis,
                                category = channel.category,
                                startTimeLabel = startTime,
                                endTimeLabel = endTime,
                                isLiveNow = isLiveNow,
                                publicationStatus = "PUBLISHED",
                            )
                        )
                        progTitle = ""
                        synopsis = ""
                    },
                    modifier = Modifier.fillMaxWidth(),
                )
                Spacer(modifier = Modifier.height(6.dp))
                programs.forEach { slot ->
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(HuntObsidianBlack, RoundedCornerShape(8.dp))
                            .padding(8.dp),
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text("${slot.startTimeLabel} - ${slot.endTimeLabel} • ${slot.programTitle}", style = MaterialTheme.typography.labelLarge, fontWeight = FontWeight.Bold)
                            if (slot.synopsis.isNotBlank()) {
                                Text(slot.synopsis, style = MaterialTheme.typography.bodySmall, color = HuntMutedSilver)
                            }
                        }
                        IconButton(onClick = { onDeleteProgram(slot.id) }) {
                            Icon(Icons.Filled.Delete, contentDescription = "Delete Slot", tint = HuntCrimsonBright)
                        }
                    }
                }
            }
        },
        confirmButton = { TextButton(onClick = onDismiss) { Text("Done") } },
    )
}

@Composable
fun AdminAnalyticsPane(
    analyticsState: UiState<AnalyticsSummary>,
    onRefresh: () -> Unit,
) {
    LazyColumn(
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp),
        modifier = Modifier
            .fillMaxSize()
            .testTag("admin_analytics_pane"),
    ) {
        item {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
                modifier = Modifier.fillMaxWidth(),
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = "Real-Time Firestore Telemetry & Analytics",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = HuntPlatinumWhite,
                    )
                    Text(
                        text = "Aggregated from verified playback_events, likes, comments & channel sessions.",
                        style = MaterialTheme.typography.bodySmall,
                        color = HuntMutedSilver,
                    )
                }
                OutlinedButton(onClick = onRefresh) {
                    Icon(Icons.Filled.Refresh, contentDescription = "Refresh", modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Refresh")
                }
            }
        }

        when (analyticsState) {
            is UiState.Loading -> {
                item {
                    Box(contentAlignment = Alignment.Center, modifier = Modifier.fillMaxWidth().padding(40.dp)) {
                        CircularProgressIndicator(color = HuntCrimsonRed)
                    }
                }
            }
            is UiState.Error -> {
                item {
                    Text(analyticsState.message, color = HuntCrimsonBright)
                }
            }
            is UiState.Success -> {
                val data = analyticsState.data
                item {
                    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxWidth()) {
                            AnalyticsKpiCard("Total Views", data.totalViews.toString(), Modifier.weight(1f))
                            AnalyticsKpiCard("Unique Viewers", data.uniqueViewers.toString(), Modifier.weight(1f))
                            AnalyticsKpiCard("Watch Time", "${data.totalWatchTimeMinutes}m", Modifier.weight(1f))
                        }
                        Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxWidth()) {
                            AnalyticsKpiCard("Avg Duration", "${data.averageWatchSeconds}s", Modifier.weight(1f))
                            AnalyticsKpiCard("Completion", "${data.completionRatePercent}%", Modifier.weight(1f))
                            AnalyticsKpiCard("Likes / Reviews", "${data.totalLikes} / ${data.totalComments}", Modifier.weight(1f))
                        }
                    }
                }

                item {
                    AnalyticsBreakdownCard(
                        title = "Most Watched Titles (Watch Seconds)",
                        entries = data.topVideos.map { it.first to "${it.second}s" to it.second.toFloat() },
                    )
                }

                item {
                    AnalyticsBreakdownCard(
                        title = "Category-Wise Views",
                        entries = data.categoryWiseViews.entries.map { (it.key to "${it.value} views") to it.value.toFloat() },
                    )
                }

                item {
                    AnalyticsBreakdownCard(
                        title = "Date-Wise Playback Sessions",
                        entries = data.dateWiseViews.entries.map { (it.key to "${it.value} sessions") to it.value.toFloat() },
                    )
                }

                item {
                    AnalyticsBreakdownCard(
                        title = "Live TV Channel Views & Watch Time",
                        entries = data.channelStats.map {
                            (it.name to "${it.viewsCount} tunes • ${it.watchTimeMinutes}m") to it.viewsCount.toFloat()
                        },
                    )
                }

                item {
                    Card(
                        shape = RoundedCornerShape(14.dp),
                        colors = CardDefaults.cardColors(containerColor = HuntObsidianBlack),
                        border = BorderStroke(1.dp, HuntBorderSubtle),
                        modifier = Modifier.fillMaxWidth(),
                    ) {
                        Text(
                            text = "Telemetry Provenance: All metrics above are computed directly from live Cloud Firestore documents (`playback_events`, `content_likes`, `content_comments`, `catalog_items`, and `tv_channels`). Optional CDN edge-bandwidth billing logs require connecting your external Cloud CDN / S3 access log sink.",
                            style = MaterialTheme.typography.bodySmall,
                            color = HuntMutedSilver,
                            modifier = Modifier.padding(14.dp),
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun AnalyticsKpiCard(
    label: String,
    value: String,
    modifier: Modifier = Modifier,
) {
    Card(
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = HuntSurfaceCard),
        border = BorderStroke(1.dp, HuntBorderSubtle),
        modifier = modifier,
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            Text(value, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.ExtraBold, color = HuntRoyalGold)
            Spacer(modifier = Modifier.height(2.dp))
            Text(label, style = MaterialTheme.typography.labelSmall, color = HuntMetallicSilver)
        }
    }
}

@Composable
private fun AnalyticsBreakdownCard(
    title: String,
    entries: List<Pair<Pair<String, String>, Float>>,
) {
    val maxVal = (entries.maxOfOrNull { it.second } ?: 1f).coerceAtLeast(1f)
    Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = HuntSurfaceCard),
        border = BorderStroke(1.dp, HuntBorderSubtle),
        modifier = Modifier.fillMaxWidth(),
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Text(title, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold, color = HuntPlatinumWhite)
            Spacer(modifier = Modifier.height(10.dp))
            if (entries.isEmpty()) {
                Text("No playback events recorded yet.", style = MaterialTheme.typography.bodySmall, color = HuntMutedSilver)
            } else {
                entries.forEach { (labels, num) ->
                    Row(
                        horizontalArrangement = Arrangement.SpaceBetween,
                        modifier = Modifier.fillMaxWidth(),
                    ) {
                        Text(labels.first, style = MaterialTheme.typography.labelMedium, color = HuntPlatinumWhite, modifier = Modifier.weight(1f))
                        Text(labels.second, style = MaterialTheme.typography.labelSmall, color = HuntMetallicSilver)
                    }
                    Spacer(modifier = Modifier.height(4.dp))
                    LinearProgressIndicator(
                        progress = { (num / maxVal).coerceIn(0.04f, 1f) },
                        color = HuntCrimsonRed,
                        trackColor = HuntObsidianBlack,
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(6.dp)
                            .clip(RoundedCornerShape(3.dp)),
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                }
            }
        }
    }
}

@Composable
fun AdminStorageAndBrandingPane(
    brandingConfig: PlatformConfig?,
    storageConfig: PlatformConfig?,
    defaultFirebaseBucket: String,
    storageHealthStatus: StorageHealthStatus?,
    backupSnapshots: List<BackupSnapshot>,
    isBusy: Boolean,
    onVerifyStorageHealth: () -> Unit,
    onCreateBackupSnapshot: (String) -> Unit,
    onRestoreBackupSnapshot: (BackupSnapshot) -> Unit,
    onSave: (branding: PlatformConfig, storage: PlatformConfig) -> Unit,
) {
    var brandName by remember(brandingConfig) { mutableStateOf(brandingConfig?.brandName ?: "HUNTXPROS") }
    var tagline by remember(brandingConfig) { mutableStateOf(brandingConfig?.tagline ?: "Premium Entertainment") }
    var customLogoUrl by remember(brandingConfig) { mutableStateOf(brandingConfig?.customLogoUrl.orEmpty()) }
    var watermarkEnabled by remember(brandingConfig) { mutableStateOf(brandingConfig?.watermarkEnabled ?: true) }

    var storageProvider by remember(storageConfig) {
        mutableStateOf(storageConfig?.storageProvider?.ifBlank { "Firebase Cloud Storage" } ?: "Firebase Cloud Storage")
    }
    var masterBucket by remember(storageConfig, defaultFirebaseBucket) {
        mutableStateOf(storageConfig?.masterBucketName?.ifBlank { defaultFirebaseBucket } ?: defaultFirebaseBucket)
    }
    var cdnBaseUrl by remember(storageConfig) { mutableStateOf(storageConfig?.cdnBaseUrl.orEmpty()) }
    var signedUploadEndpoint by remember(storageConfig) { mutableStateOf(storageConfig?.signedUploadEndpoint.orEmpty()) }
    var backupReplication by remember(storageConfig) { mutableStateOf(storageConfig?.backupReplicationEnabled ?: true) }
    var snapshotLabel by remember { mutableStateOf("") }

    Column(
        verticalArrangement = Arrangement.spacedBy(14.dp),
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp)
            .testTag("admin_storage_branding_pane"),
    ) {
        // 1. Live Cloud Video Storage & Security Rules Readiness Diagnostic
        val isReady = storageHealthStatus?.isReachableAndWritable == true
        Card(
            shape = RoundedCornerShape(18.dp),
            colors = CardDefaults.cardColors(containerColor = HuntSurfaceCard),
            border = BorderStroke(
                1.dp,
                if (isReady) HuntEmeraldGreen.copy(alpha = 0.55f) else HuntAmberWarning.copy(alpha = 0.55f),
            ),
            modifier = Modifier
                .fillMaxWidth()
                .testTag("cloud_storage_diagnostic_card"),
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = if (isReady) Icons.Filled.CloudDone else Icons.Filled.Security,
                        contentDescription = null,
                        tint = if (isReady) HuntEmeraldGreen else HuntAmberWarning,
                        modifier = Modifier.size(28.dp),
                    )
                    Spacer(modifier = Modifier.width(10.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "Cloud Video Storage & Owner Token Status",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = HuntPlatinumWhite,
                        )
                        Text(
                            text = "Target Bucket: ${masterBucket.ifBlank { defaultFirebaseBucket.ifBlank { "(not configured)" } }}",
                            style = MaterialTheme.typography.labelSmall,
                            color = HuntMetallicSilver,
                        )
                    }
                    Surface(
                        shape = RoundedCornerShape(6.dp),
                        color = if (isReady) HuntEmeraldGreen.copy(alpha = 0.18f) else HuntAmberWarning.copy(alpha = 0.18f),
                    ) {
                        Text(
                            text = if (isReady) "BUCKET ACTIVE" else "ACTION REQUIRED",
                            style = MaterialTheme.typography.labelSmall,
                            fontWeight = FontWeight.Bold,
                            color = if (isReady) HuntEmeraldGreen else HuntAmberWarning,
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                        )
                    }
                }
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = storageHealthStatus?.summaryMessage
                        ?: "Tap below to verify live Firebase Cloud Storage reachability and owner token permissions (zero embedded keys).",
                    style = MaterialTheme.typography.bodySmall,
                    color = if (isReady) HuntEmeraldGreen else HuntMutedSilver,
                )
                Spacer(modifier = Modifier.height(6.dp))
                Text(
                    text = "Prepared Security & Backup Artifacts in Repo Root: /storage.rules (single-owner write lock + delete lock) & /storage-backup-lifecycle.json (Object Versioning + 30-day Soft Delete).",
                    style = MaterialTheme.typography.labelSmall,
                    color = HuntMetallicSilver,
                )
                Spacer(modifier = Modifier.height(10.dp))
                HuntGlassButton(
                    text = "Verify Cloud Storage Bucket & Owner Token",
                    icon = Icons.Filled.Refresh,
                    onClick = onVerifyStorageHealth,
                    testTag = "verify_cloud_storage_btn",
                    modifier = Modifier.fillMaxWidth(),
                )
            }
        }

        // 2. Official Brand Logo & Watermark Management
        Card(
            shape = RoundedCornerShape(18.dp),
            colors = CardDefaults.cardColors(containerColor = HuntSurfaceCard),
            border = BorderStroke(1.dp, HuntBorderSubtle),
            modifier = Modifier.fillMaxWidth(),
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Image(
                        painter = painterResource(id = R.drawable.huntxpros_logo),
                        contentDescription = "Bundled HUNTXPROS Logo",
                        modifier = Modifier
                            .size(56.dp)
                            .clip(RoundedCornerShape(12.dp)),
                    )
                    Spacer(modifier = Modifier.width(12.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Text("Official HUNTXPROS Brand Identity", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                        Text("Original master logo preserved at assets/brand/huntxpros_original_logo.png", style = MaterialTheme.typography.labelSmall, color = HuntEmeraldGreen)
                    }
                }
                Spacer(modifier = Modifier.height(12.dp))
                OutlinedTextField(value = brandName, onValueChange = { brandName = it }, label = { Text("Brand Name") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                Spacer(modifier = Modifier.height(8.dp))
                OutlinedTextField(value = tagline, onValueChange = { tagline = it }, label = { Text("Brand Tagline") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                Spacer(modifier = Modifier.height(8.dp))
                OutlinedTextField(
                    value = customLogoUrl,
                    onValueChange = { customLogoUrl = it },
                    label = { Text("Optional Override Logo HTTPS URL (leave blank for official bundled logo)") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth(),
                )
                Spacer(modifier = Modifier.height(8.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("Show HUNTXPROS Watermark inside Video Player", modifier = Modifier.weight(1f))
                    Switch(
                        checked = watermarkEnabled,
                        onCheckedChange = { watermarkEnabled = it },
                        colors = SwitchDefaults.colors(checkedTrackColor = HuntCrimsonRed),
                    )
                }
                Spacer(modifier = Modifier.height(8.dp))
                HuntGlassButton(
                    text = "Restore Official Bundled HUNTXPROS Logo",
                    icon = Icons.Filled.Restore,
                    onClick = { customLogoUrl = "" },
                    testTag = "restore_official_logo_btn",
                )
            }
        }

        // 3. Permanent Cloud Object Storage & CDN Settings
        Card(
            shape = RoundedCornerShape(18.dp),
            colors = CardDefaults.cardColors(containerColor = HuntSurfaceCard),
            border = BorderStroke(1.dp, HuntBorderSubtle),
            modifier = Modifier.fillMaxWidth(),
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text("Cloud Video Storage, Transcoding & CDN Delivery", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = "Uses Firebase Cloud Storage Resumable Protocol (`X-Goog-Upload-URL` persisted in Firestore) with verified Owner ID tokens — zero secret keys stored in APK.",
                    style = MaterialTheme.typography.bodySmall,
                    color = HuntMutedSilver,
                )
                Spacer(modifier = Modifier.height(10.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    listOf("Firebase Cloud Storage", "Google Cloud Storage", "Cloudflare R2").forEach { provider ->
                        HuntCategoryChip(
                            label = provider,
                            selected = storageProvider == provider,
                            onClick = { storageProvider = provider },
                        )
                    }
                }
                Spacer(modifier = Modifier.height(10.dp))
                OutlinedTextField(
                    value = masterBucket,
                    onValueChange = { masterBucket = it },
                    label = { Text("Firebase / GCS Bucket Name") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth(),
                )
                Spacer(modifier = Modifier.height(8.dp))
                OutlinedTextField(
                    value = cdnBaseUrl,
                    onValueChange = { cdnBaseUrl = it },
                    label = { Text("Optional Cloud CDN Base HTTPS URL (e.g. https://cdn.huntxpros.com)") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth(),
                )
                Spacer(modifier = Modifier.height(8.dp))
                OutlinedTextField(
                    value = signedUploadEndpoint,
                    onValueChange = { signedUploadEndpoint = it },
                    label = { Text("Optional Custom Signed Multipart Upload Gateway HTTPS URL") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth(),
                )
                Spacer(modifier = Modifier.height(8.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("Enforce Multi-Region Bucket Versioning & Soft-Delete Lock", modifier = Modifier.weight(1f))
                    Switch(
                        checked = backupReplication,
                        onCheckedChange = { backupReplication = it },
                        colors = SwitchDefaults.colors(checkedTrackColor = HuntEmeraldGreen),
                    )
                }
            }
        }

        HuntPrimaryButton(
            text = "Save Branding & Cloud Storage Configuration",
            icon = Icons.Filled.Save,
            onClick = {
                onSave(
                    PlatformConfig(
                        id = "branding",
                        configType = "BRANDING",
                        brandName = brandName,
                        tagline = tagline,
                        customLogoUrl = customLogoUrl.trim(),
                        watermarkEnabled = watermarkEnabled,
                    ),
                    PlatformConfig(
                        id = "storage",
                        configType = "STORAGE",
                        storageProvider = storageProvider,
                        masterBucketName = masterBucket.trim(),
                        cdnBaseUrl = cdnBaseUrl.trim(),
                        signedUploadEndpoint = signedUploadEndpoint.trim(),
                        backupReplicationEnabled = backupReplication,
                    ),
                )
            },
            testTag = "save_branding_storage_btn",
            modifier = Modifier.fillMaxWidth(),
        )

        // 4. Immutable Metadata Backup & Disaster Recovery Vault
        Card(
            shape = RoundedCornerShape(18.dp),
            colors = CardDefaults.cardColors(containerColor = HuntSurfaceCard),
            border = BorderStroke(1.dp, HuntRoyalGold.copy(alpha = 0.45f)),
            modifier = Modifier
                .fillMaxWidth()
                .testTag("admin_backup_vault_card"),
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text(
                    text = "Immutable Disaster Recovery Vault (${backupSnapshots.size})",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = HuntPlatinumWhite,
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = "Creates write-once, delete-locked recovery points in `/backup_snapshots` (`allow update, delete: if false`) capturing all catalog titles, episodes, Live TV channels, and EPG schedules.",
                    style = MaterialTheme.typography.bodySmall,
                    color = HuntMutedSilver,
                )
                Spacer(modifier = Modifier.height(10.dp))
                OutlinedTextField(
                    value = snapshotLabel,
                    onValueChange = { snapshotLabel = it },
                    label = { Text("Snapshot Label (e.g. Pre-Release Catalog Backup)") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth(),
                )
                Spacer(modifier = Modifier.height(8.dp))
                HuntPrimaryButton(
                    text = "Create Immutable Recovery Snapshot",
                    icon = Icons.Filled.Backup,
                    isLoading = isBusy,
                    onClick = {
                        onCreateBackupSnapshot(snapshotLabel)
                        snapshotLabel = ""
                    },
                    testTag = "create_backup_snapshot_btn",
                    modifier = Modifier.fillMaxWidth(),
                )

                if (backupSnapshots.isNotEmpty()) {
                    Spacer(modifier = Modifier.height(12.dp))
                    backupSnapshots.take(6).forEach { snap ->
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 4.dp)
                                .background(HuntObsidianBlack, RoundedCornerShape(10.dp))
                                .padding(10.dp),
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = snap.label,
                                    style = MaterialTheme.typography.labelLarge,
                                    fontWeight = FontWeight.Bold,
                                    color = HuntPlatinumWhite,
                                )
                                Text(
                                    text = "${snap.catalogCount} VOD • ${snap.episodesCount} Ep • ${snap.channelsCount} TV • ${snap.epgCount} EPG",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = HuntMutedSilver,
                                )
                            }
                            OutlinedButton(
                                onClick = { onRestoreBackupSnapshot(snap) },
                                enabled = !isBusy,
                                modifier = Modifier.testTag("restore_snapshot_${snap.id}"),
                            ) {
                                Icon(Icons.Filled.Restore, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("Restore")
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun AdminDeveloperHubPane() {
    Column(
        verticalArrangement = Arrangement.spacedBy(12.dp),
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp)
            .testTag("admin_developer_hub_pane"),
    ) {
        Card(
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = HuntSurfaceCard),
            border = BorderStroke(1.dp, HuntEmeraldGreen.copy(alpha = 0.4f)),
            modifier = Modifier.fillMaxWidth(),
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text("Developer Architecture & Maintenance Hub (Read-Only)", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                Spacer(modifier = Modifier.height(6.dp))
                Text(
                    text = "For security and Google Play compliance (zero Dynamic Code Loading), source code changes are never executed dynamically inside the viewer APK. Refer to /DEVELOPER_GUIDE.md, /storage.rules, and /storage-backup-lifecycle.json in the repository root.",
                    style = MaterialTheme.typography.bodySmall,
                    color = HuntMutedSilver,
                )
            }
        }

        DevInfoBlock(
            title = "1. Modular Package Structure",
            body = "• com.example.ui.theme — Centralized Color.kt, Type.kt (Bebas Neue & Montserrat), Theme.kt\n" +
                "• com.example.i18n — 12-language AppStrings.kt with automatic RTL layout switching (ur, ar)\n" +
                "• com.example.auth — Google Identity Credential Manager & FirebaseAuth flows\n" +
                "• com.example.data.storage — 2 MB chunked ResumableVideoUploadEngine (X-Goog-Upload-URL) + SHA-256\n" +
                "• com.example.data.repository — Named Cloud Firestore repository, analytics & /backup_snapshots\n" +
                "• com.example.ui.player — Media3 ExoPlayer HLS/DASH/MP4 adaptive player\n" +
                "• com.example.ui.screens — Home, Catalog, ContentDetail, LiveTV, Settings & Admin modules"
        )

        DevInfoBlock(
            title = "2. Single-Owner RBAC & Storage Security",
            body = "• Firestore Lock: Server-side firestore.rules enforces isVerifiedOwnerToken() matching $OWNER_ADMIN_EMAIL with email_verified == true.\n" +
                "• Cloud Storage Lock: /storage.rules restricts /masters/**, /hls/**, and /artwork/** uploads strictly to $OWNER_ADMIN_EMAIL and blocks client-side deletes.\n" +
                "• Backup & Recovery: /backup_snapshots provides immutable metadata recovery points; /storage-backup-lifecycle.json enables GCS Object Versioning + 30-day Soft Delete."
        )

        DevInfoBlock(
            title = "3. Google Play Release (.aab) Checklist",
            body = "1. Provision dedicated production signing upload key (.jks).\n" +
                "2. Register Play App Signing SHA-1 & SHA-256 in Firebase Console for Google Sign-In.\n" +
                "3. Activate Firebase Storage (Blaze plan) & publish /storage.rules.\n" +
                "4. Run `gradle bundleRelease` to generate signed Android App Bundle (.aab)."
        )
    }
}

@Composable
private fun DevInfoBlock(title: String, body: String) {
    Card(
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = HuntSurfaceCard),
        border = BorderStroke(1.dp, HuntBorderSubtle),
        modifier = Modifier.fillMaxWidth(),
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Text(title, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold, color = HuntRoyalGold)
            Spacer(modifier = Modifier.height(6.dp))
            Text(body, style = MaterialTheme.typography.bodySmall, color = HuntMetallicSilver)
        }
    }
}
