package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.i18n.SupportedLanguages
import com.example.i18n.getStringsForLanguage
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

    @Test
    fun `verify official app name and named firestore database id resource`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val appName = context.getString(R.string.app_name)
        val dbId = context.getString(R.string.firestore_database_id)
        assertEquals("HUNTXPROS", appName)
        assertTrue(dbId.isNotBlank())
    }

    @Test
    fun `verify 12 global languages and RTL support for Arabic and Urdu`() {
        assertEquals(12, SupportedLanguages.size)
        val urdu = SupportedLanguages.first { it.code == "ur" }
        val arabic = SupportedLanguages.first { it.code == "ar" }
        val hindi = SupportedLanguages.first { it.code == "hi" }
        assertTrue(urdu.isRtl)
        assertTrue(arabic.isRtl)
        assertEquals("लाइव टीवी", getStringsForLanguage(hindi.code).liveTv)
    }
}
