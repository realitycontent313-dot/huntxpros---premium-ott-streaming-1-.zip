package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.LiveTv
import androidx.compose.material.icons.filled.Schedule
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.SkipNext
import androidx.compose.material.icons.filled.SkipPrevious
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.data.local.LocalAppPreferences
import com.example.data.model.EpgProgram
import com.example.data.model.FavoriteChannelEntry
import com.example.data.model.PlatformConfig
import com.example.data.model.TvChannel
import com.example.data.model.UiState
import com.example.i18n.LocalStrings
import com.example.ui.components.ChannelRowCard
import com.example.ui.components.HuntCategoryChip
import com.example.ui.components.HuntPrimaryButton
import com.example.ui.components.LivePulseBadge
import com.example.ui.player.HuntExoPlayerView
import com.example.ui.theme.HuntBorderSubtle
import com.example.ui.theme.HuntCrimsonBright
import com.example.ui.theme.HuntCrimsonRed
import com.example.ui.theme.HuntMetallicSilver
import com.example.ui.theme.HuntMutedSilver
import com.example.ui.theme.HuntPlatinumWhite
import com.example.ui.theme.HuntSurfaceCard

@Composable
fun LiveTvScreen(
    channelsState: UiState<List<TvChannel>>,
    selectedChannelId: String?,
    epgPrograms: List<EpgProgram>,
    favoriteChannels: List<FavoriteChannelEntry>,
    prefs: LocalAppPreferences,
    brandingConfig: PlatformConfig?,
    isOwnerAdmin: Boolean,
    onSelectChannel: (TvChannel) -> Unit,
    onToggleFavoriteChannel: (TvChannel) -> Unit,
    onRecordChannelSession: (TvChannel, Long) -> Unit,
    onOpenAdminChannels: () -> Unit,
) {
    val strings = LocalStrings.current
    val channels = (channelsState as? UiState.Success)?.data.orEmpty()

    var selectedCategory by remember { mutableStateOf("ALL") }
    var searchVisible by remember { mutableStateOf(false) }
    var searchQuery by remember { mutableStateOf("") }
    var isFullscreen by remember { mutableStateOf(false) }
    var showEpgDialog by remember { mutableStateOf(false) }

    val activeChannel = remember(channels, selectedChannelId) {
        channels.firstOrNull { it.id == selectedChannelId } ?: channels.firstOrNull()
    }

    LaunchedEffect(activeChannel?.id) {
        if (activeChannel != null && activeChannel.id != selectedChannelId) {
            onSelectChannel(activeChannel)
        }
    }

    BackHandler(enabled = isFullscreen) {
        isFullscreen = false
    }

    val currentIdx = channels.indexOfFirst { it.id == activeChannel?.id }
    val prevChannel = if (channels.size > 1 && currentIdx >= 0) {
        channels[(currentIdx - 1 + channels.size) % channels.size]
    } else null
    val nextChannel = if (channels.size > 1 && currentIdx >= 0) {
        channels[(currentIdx + 1) % channels.size]
    } else null

    if (isFullscreen && activeChannel != null) {
        HuntExoPlayerView(
            streamUrl = activeChannel.streamUrl,
            streamFormat = activeChannel.streamFormat,
            title = "${activeChannel.name} • ${activeChannel.currentProgramTitle}",
            isLiveStream = true,
            defaultQualityPref = prefs.defaultQuality,
            watermarkEnabled = brandingConfig?.watermarkEnabled ?: true,
            customLogoUrl = brandingConfig?.customLogoUrl.orEmpty(),
            isFullscreen = true,
            onToggleFullscreen = { isFullscreen = it },
            onBackClick = { isFullscreen = false },
            onPreviousItem = prevChannel?.let { ch -> { onSelectChannel(ch) } },
            onNextItem = nextChannel?.let { ch -> { onSelectChannel(ch) } },
            onSessionEnded = { secs, _ -> onRecordChannelSession(activeChannel, secs) },
            modifier = Modifier.fillMaxSize(),
        )
        return
    }

    val filteredChannels = remember(channels, selectedCategory, searchQuery, favoriteChannels) {
        val base = when (selectedCategory) {
            "ALL" -> channels
            "FAVORITES" -> {
                val favIds = favoriteChannels.filter { it.isFavorite }.map { it.channelId }.toSet()
                channels.filter { it.id in favIds }
            }
            "RECENT" -> {
                val recentIds = favoriteChannels.map { it.channelId }
                channels.filter { it.id in recentIds }.sortedBy { recentIds.indexOf(it.id) }
            }
            else -> channels.filter { it.category.equals(selectedCategory, ignoreCase = true) }
        }
        if (searchQuery.isBlank()) base
        else base.filter {
            it.name.contains(searchQuery, true) ||
                it.currentProgramTitle.contains(searchQuery, true) ||
                it.language.contains(searchQuery, true)
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .testTag("live_tv_screen"),
    ) {
        // Top Header matching Top-Right Reference Screen
        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 14.dp, vertical = 10.dp),
        ) {
            Icon(
                imageVector = Icons.Filled.LiveTv,
                contentDescription = null,
                tint = HuntCrimsonBright,
                modifier = Modifier.size(28.dp),
            )
            Spacer(modifier = Modifier.width(10.dp))
            Text(
                text = strings.liveTv,
                style = MaterialTheme.typography.headlineSmall,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.weight(1f),
            )
            IconButton(
                onClick = { searchVisible = !searchVisible },
                modifier = Modifier.testTag("live_tv_search_btn"),
            ) {
                Icon(Icons.Filled.Search, contentDescription = "Search Channels")
            }
            if (activeChannel != null) {
                IconButton(
                    onClick = { showEpgDialog = true },
                    modifier = Modifier.testTag("live_tv_epg_header_btn"),
                ) {
                    Icon(Icons.Filled.Schedule, contentDescription = strings.epgSchedule)
                }
            }
        }

        if (searchVisible) {
            OutlinedTextField(
                value = searchQuery,
                onValueChange = { searchQuery = it },
                placeholder = { Text("Search Live TV channels or programs...") },
                singleLine = true,
                trailingIcon = {
                    if (searchQuery.isNotEmpty()) {
                        IconButton(onClick = { searchQuery = "" }) {
                            Icon(Icons.Filled.Clear, contentDescription = "Clear")
                        }
                    }
                },
                shape = RoundedCornerShape(50),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 4.dp),
            )
        }

        if (channelsState is UiState.Loading) {
            Box(
                contentAlignment = Alignment.Center,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(220.dp),
            ) {
                CircularProgressIndicator(color = HuntCrimsonRed)
            }
        } else if (activeChannel != null) {
            // Embedded Live TV Player + Program Info Bar matching Top-Right Reference
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = HuntSurfaceCard),
                border = BorderStroke(1.dp, HuntBorderSubtle),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 14.dp),
            ) {
                Column {
                    HuntExoPlayerView(
                        streamUrl = activeChannel.streamUrl,
                        streamFormat = activeChannel.streamFormat,
                        title = activeChannel.name,
                        isLiveStream = true,
                        defaultQualityPref = prefs.defaultQuality,
                        watermarkEnabled = brandingConfig?.watermarkEnabled ?: true,
                        customLogoUrl = brandingConfig?.customLogoUrl.orEmpty(),
                        isFullscreen = false,
                        onToggleFullscreen = { isFullscreen = it },
                        onPreviousItem = prevChannel?.let { ch -> { onSelectChannel(ch) } },
                        onNextItem = nextChannel?.let { ch -> { onSelectChannel(ch) } },
                        onSessionEnded = { secs, _ -> onRecordChannelSession(activeChannel, secs) },
                    )

                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 12.dp, vertical = 10.dp),
                    ) {
                        LivePulseBadge()
                        Spacer(modifier = Modifier.width(10.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = activeChannel.currentProgramTitle.ifBlank { activeChannel.name },
                                style = MaterialTheme.typography.titleSmall,
                                color = HuntPlatinumWhite,
                                fontWeight = FontWeight.Bold,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis,
                            )
                            Text(
                                text = listOfNotNull(
                                    activeChannel.currentProgramTime.takeIf { it.isNotBlank() },
                                    activeChannel.upcomingProgramTitle.takeIf { it.isNotBlank() }?.let { "Up Next: $it" },
                                ).joinToString(" • ").ifBlank { "${activeChannel.category} • ${activeChannel.language}" },
                                style = MaterialTheme.typography.labelSmall,
                                color = HuntMetallicSilver,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis,
                            )
                        }

                        if (prevChannel != null) {
                            IconButton(onClick = { onSelectChannel(prevChannel) }) {
                                Icon(Icons.Filled.SkipPrevious, contentDescription = strings.previousChannel, tint = HuntPlatinumWhite)
                            }
                        }
                        if (nextChannel != null) {
                            IconButton(onClick = { onSelectChannel(nextChannel) }) {
                                Icon(Icons.Filled.SkipNext, contentDescription = strings.nextChannel, tint = HuntPlatinumWhite)
                            }
                        }
                    }
                }
            }
        } else {
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = HuntSurfaceCard),
                border = BorderStroke(1.dp, HuntBorderSubtle),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
            ) {
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    modifier = Modifier.padding(24.dp),
                ) {
                    Text(
                        text = "No authorized Live TV streams published yet.",
                        style = MaterialTheme.typography.titleMedium,
                        color = HuntPlatinumWhite,
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = "HUNTXPROS never invents unauthorized channels. Add company-authorized HLS/DASH stream URLs in the Channel Admin Panel.",
                        style = MaterialTheme.typography.bodySmall,
                        color = HuntMutedSilver,
                    )
                    if (isOwnerAdmin) {
                        Spacer(modifier = Modifier.height(14.dp))
                        HuntPrimaryButton(
                            text = "Manage TV Channels",
                            onClick = onOpenAdminChannels,
                        )
                    }
                }
            }
        }

        // Category Filter Row
        val categories = listOf(
            "ALL" to strings.allChannels,
            "FAVORITES" to strings.favorites,
            "RECENT" to strings.recentlyWatched,
            "SPORTS" to strings.sports,
            "NEWS" to strings.news,
            "ENTERTAINMENT" to strings.entertainment,
            "MOVIES" to strings.movies,
            "MUSIC" to strings.music,
            "EDUCATIONAL" to strings.educational,
        )
        LazyRow(
            contentPadding = PaddingValues(horizontal = 14.dp, vertical = 10.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            items(categories) { (key, label) ->
                HuntCategoryChip(
                    label = label,
                    selected = selectedCategory == key,
                    onClick = { selectedCategory = key },
                )
            }
        }

        // Channel List
        LazyColumn(
            contentPadding = PaddingValues(horizontal = 14.dp, vertical = 4.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp),
            modifier = Modifier.fillMaxSize(),
        ) {
            items(filteredChannels, key = { it.id }) { channel ->
                val isFav = favoriteChannels.firstOrNull { it.channelId == channel.id }?.isFavorite == true
                ChannelRowCard(
                    channel = channel,
                    isSelected = activeChannel?.id == channel.id,
                    isFavorite = isFav,
                    onPlayClick = { onSelectChannel(channel) },
                    onFavoriteClick = { onToggleFavoriteChannel(channel) },
                    onEpgClick = {
                        onSelectChannel(channel)
                        showEpgDialog = true
                    },
                )
            }
        }
    }

    if (showEpgDialog && activeChannel != null) {
        AlertDialog(
            onDismissRequest = { showEpgDialog = false },
            title = { Text("${strings.epgSchedule} — ${activeChannel.name}") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    if (epgPrograms.isEmpty()) {
                        Text(
                            text = "${strings.currentProgram}: ${activeChannel.currentProgramTitle.ifBlank { "Live Broadcast" }} (${activeChannel.currentProgramTime})",
                            style = MaterialTheme.typography.bodyMedium,
                            fontWeight = FontWeight.SemiBold,
                        )
                        if (activeChannel.upcomingProgramTitle.isNotBlank()) {
                            Text(
                                text = "${strings.upcomingProgram}: ${activeChannel.upcomingProgramTitle} (${activeChannel.upcomingProgramTime})",
                                style = MaterialTheme.typography.bodySmall,
                                color = HuntMutedSilver,
                            )
                        }
                    } else {
                        epgPrograms.forEach { prog ->
                            Surface(
                                shape = RoundedCornerShape(10.dp),
                                color = HuntSurfaceCard,
                                border = BorderStroke(
                                    1.dp,
                                    if (prog.isLiveNow) HuntCrimsonRed else HuntBorderSubtle,
                                ),
                                modifier = Modifier.fillMaxWidth(),
                            ) {
                                Column(modifier = Modifier.padding(10.dp)) {
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        modifier = Modifier.fillMaxWidth(),
                                    ) {
                                        Text(
                                            text = "${prog.startTimeLabel} - ${prog.endTimeLabel}",
                                            style = MaterialTheme.typography.labelSmall,
                                            color = HuntCrimsonBright,
                                        )
                                        if (prog.isLiveNow) {
                                            LivePulseBadge()
                                        }
                                    }
                                    Text(
                                        text = prog.programTitle,
                                        style = MaterialTheme.typography.titleSmall,
                                        fontWeight = FontWeight.Bold,
                                    )
                                    if (prog.synopsis.isNotBlank()) {
                                        Text(
                                            text = prog.synopsis,
                                            style = MaterialTheme.typography.bodySmall,
                                            color = HuntMutedSilver,
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { showEpgDialog = false }) { Text("Close") }
            },
        )
    }
}
