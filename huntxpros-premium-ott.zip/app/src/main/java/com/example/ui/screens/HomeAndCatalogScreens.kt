package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.AdminPanelSettings
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material.icons.filled.Movie
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import com.example.data.model.CatalogItem
import com.example.data.model.PlatformConfig
import com.example.data.model.TvChannel
import com.example.data.model.UiState
import com.example.data.model.WatchHistoryEntry
import com.example.data.model.WatchlistEntry
import com.example.i18n.LocalStrings
import com.example.ui.components.ContinueWatchingCard
import com.example.ui.components.HuntBrandHeaderLogo
import com.example.ui.components.HuntCategoryChip
import com.example.ui.components.HuntGlassButton
import com.example.ui.components.HuntPrimaryButton
import com.example.ui.components.LivePulseBadge
import com.example.ui.components.PosterContentCard
import com.example.ui.components.SectionHeaderRow
import com.example.ui.theme.HuntBorderSubtle
import com.example.ui.theme.HuntCrimsonBright
import com.example.ui.theme.HuntCrimsonRed
import com.example.ui.theme.HuntElevatedCard
import com.example.ui.theme.HuntMetallicSilver
import com.example.ui.theme.HuntMutedSilver
import com.example.ui.theme.HuntObsidianBlack
import com.example.ui.theme.HuntPlatinumWhite
import com.example.ui.theme.HuntSurfaceCard

@Composable
fun HomeScreen(
    catalogState: UiState<List<CatalogItem>>,
    channelsState: UiState<List<TvChannel>>,
    watchHistory: List<WatchHistoryEntry>,
    watchlist: List<WatchlistEntry>,
    brandingConfig: PlatformConfig?,
    userDisplayName: String,
    userAvatarUrl: String?,
    isOwnerAdmin: Boolean,
    isBusy: Boolean,
    onOpenSearch: () -> Unit,
    onOpenSettings: () -> Unit,
    onOpenAdminPanel: () -> Unit,
    onOpenContentDetail: (String) -> Unit,
    onOpenCategorySection: (String) -> Unit,
    onOpenLiveTvChannel: (String) -> Unit,
    onToggleWatchlist: (CatalogItem) -> Unit,
    onSeedAuthorizedStreams: () -> Unit,
) {
    val strings = LocalStrings.current
    var showMenuDropdown by remember { mutableStateOf(false) }
    var showNotificationsDialog by remember { mutableStateOf(false) }
    var selectedGenreFilter by remember { mutableStateOf("ALL") }

    val catalog = (catalogState as? UiState.Success)?.data.orEmpty()
    val channels = (channelsState as? UiState.Success)?.data.orEmpty()

    val filteredCatalog = remember(catalog, selectedGenreFilter) {
        if (selectedGenreFilter == "ALL") catalog
        else catalog.filter {
            it.genre.contains(selectedGenreFilter, ignoreCase = true) ||
                it.contentType.equals(selectedGenreFilter, ignoreCase = true)
        }
    }

    val heroItems = remember(filteredCatalog) {
        filteredCatalog.filter { it.isFeaturedHero }.ifEmpty { filteredCatalog.take(4) }
    }
    val trendingItems = remember(filteredCatalog) {
        filteredCatalog.filter { it.isTrending }.ifEmpty { filteredCatalog.take(8) }
    }
    val popularItems = remember(filteredCatalog) {
        filteredCatalog.filter { it.isPopular }.sortedByDescending { it.viewsCount }.ifEmpty { filteredCatalog.take(8) }
    }
    val latestReleases = remember(filteredCatalog) {
        filteredCatalog.sortedByDescending { it.releaseYear }
    }
    val recommendedItems = remember(filteredCatalog, watchHistory) {
        val watchedGenres = watchHistory.mapNotNull { h ->
            catalog.firstOrNull { it.id == h.contentId }?.genre?.split("•")?.firstOrNull()?.trim()
        }.toSet()
        if (watchedGenres.isEmpty()) filteredCatalog.shuffled().take(8)
        else filteredCatalog.sortedByDescending { item -> watchedGenres.any { g -> item.genre.contains(g, true) } }
    }
    val moviesList = remember(filteredCatalog) { filteredCatalog.filter { it.contentType == "MOVIE" } }
    val seriesList = remember(filteredCatalog) { filteredCatalog.filter { it.contentType == "SERIES" } }
    val showsAndShorts = remember(filteredCatalog) {
        filteredCatalog.filter { it.contentType in listOf("SHOW", "SHORT_FILM") }
    }
    val docsSportsEduNews = remember(filteredCatalog) {
        filteredCatalog.filter { it.contentType in listOf("DOCUMENTARY", "SPORTS", "EDUCATIONAL", "NEWS") }
    }

    LazyColumn(
        contentPadding = PaddingValues(bottom = 28.dp),
        modifier = Modifier
            .fillMaxSize()
            .testTag("home_screen_list"),
    ) {
        // 1. Top App Header matching HUNTXPROS Reference
        item {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 12.dp, vertical = 10.dp),
            ) {
                Box {
                    IconButton(
                        onClick = { showMenuDropdown = true },
                        modifier = Modifier.testTag("home_menu_button"),
                    ) {
                        Icon(
                            imageVector = Icons.Filled.Menu,
                            contentDescription = "Categories Menu",
                            tint = MaterialTheme.colorScheme.onBackground,
                        )
                    }
                    DropdownMenu(
                        expanded = showMenuDropdown,
                        onDismissRequest = { showMenuDropdown = false },
                    ) {
                        val sections = listOf(
                            "MOVIE" to strings.movies,
                            "SERIES" to strings.series,
                            "SHORT_FILM" to strings.shortFilms,
                            "SHOW" to strings.shows,
                            "DOCUMENTARY" to strings.documentaries,
                            "NEWS" to strings.news,
                            "SPORTS" to strings.sports,
                            "EDUCATIONAL" to strings.educational,
                        )
                        sections.forEach { (type, label) ->
                            DropdownMenuItem(
                                text = { Text(label) },
                                onClick = {
                                    showMenuDropdown = false
                                    onOpenCategorySection(type)
                                },
                            )
                        }
                        DropdownMenuItem(
                            text = { Text(strings.settings) },
                            leadingIcon = { Icon(Icons.Filled.Settings, contentDescription = null) },
                            onClick = {
                                showMenuDropdown = false
                                onOpenSettings()
                            },
                        )
                        if (isOwnerAdmin) {
                            DropdownMenuItem(
                                text = { Text(strings.adminPanel, color = HuntCrimsonBright, fontWeight = FontWeight.Bold) },
                                leadingIcon = {
                                    Icon(Icons.Filled.AdminPanelSettings, contentDescription = null, tint = HuntCrimsonBright)
                                },
                                onClick = {
                                    showMenuDropdown = false
                                    onOpenAdminPanel()
                                },
                            )
                        }
                    }
                }

                HuntBrandHeaderLogo(
                    customLogoUrl = brandingConfig?.customLogoUrl.orEmpty(),
                    tagline = brandingConfig?.tagline?.ifBlank { strings.brandTagline } ?: strings.brandTagline,
                    modifier = Modifier.weight(1f),
                )

                IconButton(
                    onClick = onOpenSearch,
                    modifier = Modifier.testTag("home_search_button"),
                ) {
                    Icon(
                        imageVector = Icons.Filled.Search,
                        contentDescription = "Search",
                        tint = MaterialTheme.colorScheme.onBackground,
                    )
                }

                IconButton(
                    onClick = { showNotificationsDialog = true },
                    modifier = Modifier.testTag("home_notifications_button"),
                ) {
                    Icon(
                        imageVector = Icons.Filled.Notifications,
                        contentDescription = strings.notifications,
                        tint = MaterialTheme.colorScheme.onBackground,
                    )
                }

                if (isOwnerAdmin) {
                    IconButton(
                        onClick = onOpenAdminPanel,
                        modifier = Modifier.testTag("home_admin_button"),
                    ) {
                        Icon(
                            imageVector = Icons.Filled.AdminPanelSettings,
                            contentDescription = strings.adminPanel,
                            tint = HuntCrimsonBright,
                        )
                    }
                }

                // Viewer Profile Avatar Badge ('M' badge in reference UI)
                Surface(
                    onClick = onOpenSettings,
                    shape = CircleShape,
                    color = HuntCrimsonRed,
                    modifier = Modifier
                        .size(34.dp)
                        .testTag("home_profile_avatar"),
                ) {
                    Box(contentAlignment = Alignment.Center) {
                        if (!userAvatarUrl.isNullOrBlank()) {
                            AsyncImage(
                                model = userAvatarUrl,
                                contentDescription = userDisplayName,
                                contentScale = ContentScale.Crop,
                                modifier = Modifier.fillMaxSize(),
                            )
                        } else {
                            Text(
                                text = userDisplayName.firstOrNull()?.uppercase() ?: "V",
                                style = MaterialTheme.typography.labelLarge,
                                color = HuntPlatinumWhite,
                                fontWeight = FontWeight.ExtraBold,
                            )
                        }
                    }
                }
            }
        }

        // 2. Categories & Genres Quick Row
        item {
            val genres = listOf(
                "ALL" to strings.allCategories,
                "Action" to "Action",
                "Sci-Fi" to "Sci-Fi",
                "Drama" to "Drama",
                "Thriller" to "Thriller",
                "Fantasy" to "Fantasy",
                "Documentary" to strings.documentaries,
                "SHORT_FILM" to strings.shortFilms,
                "SPORTS" to strings.sports,
                "EDUCATIONAL" to strings.educational,
            )
            LazyRow(
                contentPadding = PaddingValues(horizontal = 16.dp, vertical = 4.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                items(genres) { (key, label) ->
                    HuntCategoryChip(
                        label = label,
                        selected = selectedGenreFilter == key,
                        onClick = { selectedGenreFilter = key },
                    )
                }
            }
        }

        // 3. Loading / Empty Catalog Handling
        if (catalogState is UiState.Loading) {
            item {
                Box(
                    contentAlignment = Alignment.Center,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(260.dp),
                ) {
                    CircularProgressIndicator(color = HuntCrimsonRed)
                }
            }
        } else if (catalog.isEmpty()) {
            item {
                Card(
                    shape = RoundedCornerShape(18.dp),
                    colors = CardDefaults.cardColors(containerColor = HuntSurfaceCard),
                    border = BorderStroke(1.dp, HuntBorderSubtle),
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                ) {
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        modifier = Modifier.padding(24.dp),
                    ) {
                        Icon(
                            imageVector = Icons.Filled.Movie,
                            contentDescription = null,
                            tint = HuntCrimsonBright,
                            modifier = Modifier.size(44.dp),
                        )
                        Spacer(modifier = Modifier.height(10.dp))
                        Text(
                            text = if (isOwnerAdmin) strings.emptyCatalogOwnerHint else strings.emptyCatalogViewerHint,
                            style = MaterialTheme.typography.bodyMedium,
                            color = HuntMetallicSilver,
                        )
                        if (isOwnerAdmin) {
                            Spacer(modifier = Modifier.height(16.dp))
                            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                                HuntPrimaryButton(
                                    text = "Load Open-License Test Streams",
                                    isLoading = isBusy,
                                    onClick = onSeedAuthorizedStreams,
                                    testTag = "seed_open_streams_btn",
                                )
                                HuntGlassButton(
                                    text = strings.adminPanel,
                                    onClick = onOpenAdminPanel,
                                )
                            }
                        }
                    }
                }
            }
        }

        // 4. Featured Cinematic Hero Banner Carousel
        if (heroItems.isNotEmpty()) {
            item {
                val pagerState = rememberPagerState(pageCount = { heroItems.size })
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    HorizontalPager(
                        state = pagerState,
                        contentPadding = PaddingValues(horizontal = 16.dp),
                        pageSpacing = 12.dp,
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(top = 8.dp),
                    ) { page ->
                        val hero = heroItems[page]
                        val inMyList = watchlist.any { it.contentId == hero.id }
                        HeroBannerCard(
                            item = hero,
                            inMyList = inMyList,
                            onPlayClick = { onOpenContentDetail(hero.id) },
                            onToggleMyList = { onToggleWatchlist(hero) },
                        )
                    }

                    if (heroItems.size > 1) {
                        Spacer(modifier = Modifier.height(10.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            repeat(heroItems.size) { idx ->
                                Box(
                                    modifier = Modifier
                                        .size(if (pagerState.currentPage == idx) 8.dp else 6.dp)
                                        .clip(CircleShape)
                                        .background(
                                            if (pagerState.currentPage == idx) HuntCrimsonRed
                                            else HuntMutedSilver.copy(alpha = 0.45f)
                                        )
                                )
                            }
                        }
                    }
                }
            }
        }

        // 5. Continue Watching Row
        val activeContinue = watchHistory.filter { !it.completed }
        if (activeContinue.isNotEmpty()) {
            item {
                Spacer(modifier = Modifier.height(12.dp))
                SectionHeaderRow(title = strings.continueWatching)
                LazyRow(
                    contentPadding = PaddingValues(horizontal = 16.dp),
                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                ) {
                    items(activeContinue, key = { it.id }) { history ->
                        ContinueWatchingCard(
                            entry = history,
                            onClick = { onOpenContentDetail(history.contentId) },
                        )
                    }
                }
            }
        }

        // 6. Trending Now
        if (trendingItems.isNotEmpty()) {
            item {
                Spacer(modifier = Modifier.height(10.dp))
                SectionHeaderRow(
                    title = strings.trendingNow,
                    onSeeAll = { onOpenCategorySection("MOVIE") },
                )
                HorizontalPosterRow(items = trendingItems, onItemClick = onOpenContentDetail)
            }
        }

        // 7. Featured TV Channels Row
        if (channels.isNotEmpty()) {
            item {
                Spacer(modifier = Modifier.height(10.dp))
                SectionHeaderRow(title = strings.featuredTvChannels)
                LazyRow(
                    contentPadding = PaddingValues(horizontal = 16.dp),
                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                ) {
                    items(channels, key = { it.id }) { ch ->
                        FeaturedChannelMiniCard(
                            channel = ch,
                            onClick = { onOpenLiveTvChannel(ch.id) },
                        )
                    }
                }
            }
        }

        // 8. Most Popular
        if (popularItems.isNotEmpty()) {
            item {
                Spacer(modifier = Modifier.height(10.dp))
                SectionHeaderRow(title = strings.mostPopular)
                HorizontalPosterRow(items = popularItems, onItemClick = onOpenContentDetail)
            }
        }

        // 9. Latest Releases
        if (latestReleases.isNotEmpty()) {
            item {
                Spacer(modifier = Modifier.height(10.dp))
                SectionHeaderRow(title = strings.latestReleases)
                HorizontalPosterRow(items = latestReleases, onItemClick = onOpenContentDetail)
            }
        }

        // 10. Recommended for You
        if (recommendedItems.isNotEmpty()) {
            item {
                Spacer(modifier = Modifier.height(10.dp))
                SectionHeaderRow(title = strings.recommendedForYou)
                HorizontalPosterRow(items = recommendedItems, onItemClick = onOpenContentDetail)
            }
        }

        // 11. Popular Movies
        if (moviesList.isNotEmpty()) {
            item {
                Spacer(modifier = Modifier.height(10.dp))
                SectionHeaderRow(
                    title = strings.popularMovies,
                    onSeeAll = { onOpenCategorySection("MOVIE") },
                )
                HorizontalPosterRow(items = moviesList, onItemClick = onOpenContentDetail)
            }
        }

        // 12. Popular Web Series
        if (seriesList.isNotEmpty()) {
            item {
                Spacer(modifier = Modifier.height(10.dp))
                SectionHeaderRow(
                    title = strings.popularWebSeries,
                    onSeeAll = { onOpenCategorySection("SERIES") },
                )
                HorizontalPosterRow(items = seriesList, onItemClick = onOpenContentDetail)
            }
        }

        // 13. Latest Shows & Short Films
        if (showsAndShorts.isNotEmpty()) {
            item {
                Spacer(modifier = Modifier.height(10.dp))
                SectionHeaderRow(
                    title = strings.latestShows,
                    onSeeAll = { onOpenCategorySection("SHORT_FILM") },
                )
                HorizontalPosterRow(items = showsAndShorts, onItemClick = onOpenContentDetail)
            }
        }

        // 14. Documentaries, Sports, News & Educational Videos
        if (docsSportsEduNews.isNotEmpty()) {
            item {
                Spacer(modifier = Modifier.height(10.dp))
                SectionHeaderRow(
                    title = strings.latestNewsSportsEdu,
                    onSeeAll = { onOpenCategorySection("NEWS") },
                )
                HorizontalPosterRow(items = docsSportsEduNews, onItemClick = onOpenContentDetail)
            }
        }
    }

    if (showNotificationsDialog) {
        AlertDialog(
            onDismissRequest = { showNotificationsDialog = false },
            title = { Text(strings.notifications) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        text = if (latestReleases.isNotEmpty()) {
                            "New on HUNTXPROS: ${latestReleases.take(3).joinToString { it.title }}"
                        } else {
                            "You're all caught up! New releases and live broadcasts appear here."
                        },
                        style = MaterialTheme.typography.bodyMedium,
                    )
                }
            },
            confirmButton = {
                TextButton(onClick = { showNotificationsDialog = false }) { Text("OK") }
            },
        )
    }
}

@Composable
private fun HeroBannerCard(
    item: CatalogItem,
    inMyList: Boolean,
    onPlayClick: () -> Unit,
    onToggleMyList: () -> Unit,
) {
    val strings = LocalStrings.current
    Card(
        onClick = onPlayClick,
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = HuntSurfaceCard),
        border = BorderStroke(1.dp, HuntBorderSubtle),
        modifier = Modifier
            .fillMaxWidth()
            .height(320.dp)
            .testTag("hero_banner_${item.id}"),
    ) {
        Box(modifier = Modifier.fillMaxSize()) {
            val imgUrl = item.bannerUrl.ifBlank { item.posterUrl }
            if (imgUrl.isNotBlank()) {
                AsyncImage(
                    model = imgUrl,
                    contentDescription = item.title,
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.fillMaxSize(),
                )
            }
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(
                        Brush.verticalGradient(
                            colors = listOf(
                                Color.Transparent,
                                HuntObsidianBlack.copy(alpha = 0.45f),
                                HuntObsidianBlack.copy(alpha = 0.96f),
                            )
                        )
                    )
            )
            Column(
                modifier = Modifier
                    .align(Alignment.BottomStart)
                    .padding(18.dp),
            ) {
                Text(
                    text = item.title.uppercase(),
                    style = MaterialTheme.typography.displayMedium,
                    color = HuntPlatinumWhite,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis,
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = "${item.genre} • ${item.releaseYear} • ${item.ageRating}",
                    style = MaterialTheme.typography.bodySmall,
                    color = HuntMetallicSilver,
                )
                Spacer(modifier = Modifier.height(14.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    HuntPrimaryButton(
                        text = strings.playNow,
                        icon = Icons.Filled.PlayArrow,
                        onClick = onPlayClick,
                        testTag = "hero_play_now_btn",
                    )
                    HuntGlassButton(
                        text = if (inMyList) strings.inMyList else strings.addToMyList,
                        icon = if (inMyList) Icons.Filled.Check else Icons.Filled.Add,
                        onClick = onToggleMyList,
                        testTag = "hero_my_list_btn",
                    )
                }
            }
        }
    }
}

@Composable
private fun HorizontalPosterRow(
    items: List<CatalogItem>,
    onItemClick: (String) -> Unit,
) {
    LazyRow(
        contentPadding = PaddingValues(horizontal = 16.dp),
        horizontalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        items(items, key = { it.id }) { item ->
            PosterContentCard(
                item = item,
                onClick = { onItemClick(item.id) },
            )
        }
    }
}

@Composable
private fun FeaturedChannelMiniCard(
    channel: TvChannel,
    onClick: () -> Unit,
) {
    Card(
        onClick = onClick,
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = HuntSurfaceCard),
        border = BorderStroke(1.dp, HuntBorderSubtle),
        modifier = Modifier
            .width(175.dp)
            .testTag("featured_ch_${channel.id}"),
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
                modifier = Modifier.fillMaxWidth(),
            ) {
                Box(
                    contentAlignment = Alignment.Center,
                    modifier = Modifier
                        .size(40.dp)
                        .clip(RoundedCornerShape(8.dp))
                        .background(HuntObsidianBlack),
                ) {
                    if (channel.logoUrl.isNotBlank()) {
                        AsyncImage(
                            model = channel.logoUrl,
                            contentDescription = channel.name,
                            contentScale = ContentScale.Crop,
                            modifier = Modifier.fillMaxSize(),
                        )
                    } else {
                        Text(
                            text = channel.name.take(3).uppercase(),
                            style = MaterialTheme.typography.labelLarge,
                            color = HuntCrimsonBright,
                        )
                    }
                }
                if (channel.isLive) {
                    LivePulseBadge()
                }
            }
            Spacer(modifier = Modifier.height(10.dp))
            Text(
                text = channel.name,
                style = MaterialTheme.typography.titleSmall,
                color = HuntPlatinumWhite,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
            )
            Text(
                text = channel.currentProgramTitle.ifBlank { channel.category },
                style = MaterialTheme.typography.bodySmall,
                color = HuntMutedSilver,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
            )
        }
    }
}

@Composable
fun CategoryCatalogGridScreen(
    sectionType: String, // MOVIE, SERIES, NEWS, SHORT_FILM, SHOW, DOCUMENTARY, SPORTS, EDUCATIONAL, ALL
    catalog: List<CatalogItem>,
    onBack: (() -> Unit)?,
    onOpenSearch: () -> Unit,
    onSelectContent: (String) -> Unit,
) {
    val strings = LocalStrings.current
    var activeSubFilter by remember(sectionType) { mutableStateOf("ALL") }

    if (onBack != null) {
        BackHandler(onBack = onBack)
    }

    val sectionTitle = when (sectionType) {
        "MOVIE" -> strings.movies
        "SERIES" -> strings.series
        "SHORT_FILM" -> strings.shortFilms
        "SHOW" -> strings.shows
        "DOCUMENTARY" -> strings.documentaries
        "SPORTS" -> strings.sports
        "EDUCATIONAL" -> strings.educational
        "NEWS" -> strings.news
        else -> strings.allCategories
    }

    val baseItems = remember(catalog, sectionType) {
        when (sectionType) {
            "ALL" -> catalog
            "NEWS" -> catalog.filter { it.contentType in listOf("NEWS", "DOCUMENTARY", "SPORTS", "EDUCATIONAL") }
            else -> catalog.filter { it.contentType == sectionType }
        }
    }

    val filteredItems = remember(baseItems, activeSubFilter) {
        if (activeSubFilter == "ALL") baseItems
        else baseItems.filter {
            it.genre.contains(activeSubFilter, ignoreCase = true) ||
                it.contentType.equals(activeSubFilter, ignoreCase = true)
        }
    }

    val filterChips = if (sectionType == "NEWS") {
        listOf("ALL" to strings.allCategories, "NEWS" to strings.news, "DOCUMENTARY" to strings.documentaries, "SPORTS" to strings.sports, "EDUCATIONAL" to strings.educational)
    } else {
        listOf("ALL" to strings.allCategories, "Action" to "Action", "Comedy" to "Comedy", "Drama" to "Drama", "Thriller" to "Thriller", "Sci-Fi" to "Sci-Fi", "Fantasy" to "Fantasy")
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .testTag("category_grid_screen_$sectionType"),
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 8.dp, vertical = 10.dp),
        ) {
            if (onBack != null) {
                IconButton(onClick = onBack) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                        contentDescription = "Back",
                        tint = MaterialTheme.colorScheme.onBackground,
                    )
                }
            } else {
                Spacer(modifier = Modifier.width(8.dp))
            }
            Text(
                text = sectionTitle,
                style = MaterialTheme.typography.headlineSmall,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.weight(1f),
            )
            IconButton(onClick = onOpenSearch) {
                Icon(
                    imageVector = Icons.Filled.Search,
                    contentDescription = "Search",
                    tint = MaterialTheme.colorScheme.onBackground,
                )
            }
        }

        LazyRow(
            contentPadding = PaddingValues(horizontal = 16.dp, vertical = 6.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            items(filterChips) { (code, label) ->
                HuntCategoryChip(
                    label = label,
                    selected = activeSubFilter == code,
                    onClick = { activeSubFilter = code },
                )
            }
        }

        if (filteredItems.isEmpty()) {
            Box(
                contentAlignment = Alignment.Center,
                modifier = Modifier
                    .fillMaxSize()
                    .padding(32.dp),
            ) {
                Text(
                    text = "No published titles in this category yet.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = HuntMutedSilver,
                )
            }
        } else {
            BoxWithConstraints(modifier = Modifier.fillMaxSize()) {
                val columns = when {
                    maxWidth >= 840.dp -> 5
                    maxWidth >= 600.dp -> 4
                    else -> 3
                }
                LazyVerticalGrid(
                    columns = GridCells.Fixed(columns),
                    contentPadding = PaddingValues(16.dp),
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp),
                    modifier = Modifier.fillMaxSize(),
                ) {
                    items(filteredItems, key = { it.id }) { item ->
                        PosterContentCard(
                            item = item,
                            onClick = { onSelectContent(item.id) },
                            modifier = Modifier.fillMaxWidth(),
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun GlobalSearchScreen(
    catalog: List<CatalogItem>,
    channels: List<TvChannel>,
    onBack: () -> Unit,
    onSelectContent: (String) -> Unit,
    onSelectChannel: (String) -> Unit,
) {
    val strings = LocalStrings.current
    var query by remember { mutableStateOf("") }

    BackHandler(onBack = onBack)

    val matchingContent = remember(catalog, query) {
        if (query.isBlank()) catalog
        else catalog.filter {
            it.title.contains(query, true) ||
                it.genre.contains(query, true) ||
                it.language.contains(query, true) ||
                it.contentType.contains(query, true) ||
                it.castCrew.any { c -> c.contains(query, true) }
        }
    }

    val matchingChannels = remember(channels, query) {
        if (query.isBlank()) emptyList()
        else channels.filter {
            it.name.contains(query, true) ||
                it.category.contains(query, true) ||
                it.currentProgramTitle.contains(query, true)
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp, vertical = 10.dp),
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack) {
                Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
            }
            OutlinedTextField(
                value = query,
                onValueChange = { query = it },
                placeholder = { Text(strings.searchPlaceholder, maxLines = 1) },
                leadingIcon = { Icon(Icons.Filled.Search, contentDescription = null) },
                trailingIcon = {
                    if (query.isNotEmpty()) {
                        IconButton(onClick = { query = "" }) {
                            Icon(Icons.Filled.Clear, contentDescription = "Clear")
                        }
                    }
                },
                singleLine = true,
                shape = RoundedCornerShape(50),
                modifier = Modifier
                    .weight(1f)
                    .testTag("global_search_input"),
            )
        }

        Spacer(modifier = Modifier.height(12.dp))

        if (matchingChannels.isNotEmpty()) {
            Text(
                text = strings.liveTv,
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
            )
            Spacer(modifier = Modifier.height(8.dp))
            LazyRow(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                items(matchingChannels, key = { it.id }) { ch ->
                    FeaturedChannelMiniCard(channel = ch, onClick = { onSelectChannel(ch.id) })
                }
            }
            Spacer(modifier = Modifier.height(14.dp))
        }

        BoxWithConstraints(modifier = Modifier.fillMaxSize()) {
            val cols = if (maxWidth >= 600.dp) 4 else 3
            LazyVerticalGrid(
                columns = GridCells.Fixed(cols),
                horizontalArrangement = Arrangement.spacedBy(10.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp),
            ) {
                items(matchingContent, key = { it.id }) { item ->
                    PosterContentCard(
                        item = item,
                        onClick = { onSelectContent(item.id) },
                        modifier = Modifier.fillMaxWidth(),
                    )
                }
            }
        }
    }
}
