package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// HUNTXPROS Official Brand Palette: Obsidian Black, Charcoal, Metallic Silver & Crimson Red
val HuntObsidianBlack = Color(0xFF07070A)
val HuntDeepCharcoal = Color(0xFF101218)
val HuntSurfaceCard = Color(0xFF181B24)
val HuntElevatedCard = Color(0xFF222633)
val HuntCrimsonRed = Color(0xFFE50914)
val HuntCrimsonBright = Color(0xFFFF1F2D)
val HuntCrimsonDark = Color(0xFF8C060E)
val HuntMetallicSilver = Color(0xFFD2D7E0)
val HuntPlatinumWhite = Color(0xFFF6F7FB)
val HuntMutedSilver = Color(0xFF9198A6)
val HuntRoyalGold = Color(0xFFF5B82E)
val HuntEmeraldGreen = Color(0xFF1DB954)
val HuntAmberWarning = Color(0xFFF59E0B)
val HuntBorderSubtle = Color(0xFF2C3142)

// Light mode alternative when user toggles Dark Mode OFF in Settings
val HuntLightBackground = Color(0xFFF4F5F8)
val HuntLightSurface = Color(0xFFFFFFFF)
val HuntLightSurfaceVariant = Color(0xFFE8EBF2)
val HuntLightOnSurface = Color(0xFF11131A)
