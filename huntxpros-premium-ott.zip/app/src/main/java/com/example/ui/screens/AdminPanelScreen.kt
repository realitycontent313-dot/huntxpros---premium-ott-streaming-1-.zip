package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.defaultMinSize
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.Logout
import androidx.compose.material.icons.filled.BarChart
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.CloudDownload
import androidx.compose.material.icons.filled.CloudUpload
import androidx.compose.material.icons.filled.Code
import androidx.compose.material.icons.filled.LiveTv
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.VerifiedUser
import androidx.compose.material.icons.filled.VideoLibrary
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import com.example.data.model.OWNER_ADMIN_EMAIL
import com.example.i18n.LocalStrings
import com.example.ui.components.HuntPrimaryButton
import com.example.ui.theme.HuntAmberWarning
import com.example.ui.theme.HuntBorderSubtle
import com.example.ui.theme.HuntCrimsonBright
import com.example.ui.theme.HuntCrimsonRed
import com.example.ui.theme.HuntDeepCharcoal
import com.example.ui.theme.HuntElevatedCard
import com.example.ui.theme.HuntEmeraldGreen
import com.example.ui.theme.HuntMetallicSilver
import com.example.ui.theme.HuntMutedSilver
import com.example.ui.theme.HuntObsidianBlack
import com.example.ui.theme.HuntPlatinumWhite
import com.example.ui.theme.HuntSurfaceCard
import com.example.ui.viewmodel.HuntXProsViewModel

enum class AdminModule(val title: String) {
    UPLOAD("Upload Videos"),
    CONTENT("Manage Content"),
    CHANNELS("TV Channels"),
    ANALYTICS("Analytics"),
    SETTINGS("Settings"),
    DEV_TOOLS("Developer Tools"),
}

@Composable
fun AdminPanelScreen(
    viewModel: HuntXProsViewModel,
    initialModule: AdminModule? = null,
    onBackToApp: () -> Unit,
    onPreviewContent: (String) -> Unit,
    onLogout: () -> Unit,
) {
    val strings = LocalStrings.current

    if (!viewModel.isOwnerAdmin) {
        BackHandler(onBack = onBackToApp)
        Box(
            contentAlignment = Alignment.Center,
            modifier = Modifier
                .fillMaxSize()
                .background(HuntObsidianBlack)
                .padding(24.dp)
                .testTag("admin_unauthorized_guard"),
        ) {
            Card(
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = HuntSurfaceCard),
                border = BorderStroke(1.dp, HuntCrimsonRed),
                modifier = Modifier.widthIn(max = 420.dp),
            ) {
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    modifier = Modifier.padding(24.dp),
                ) {
                    Icon(
                        imageVector = Icons.Filled.Lock,
                        contentDescription = null,
                        tint = HuntCrimsonBright,
                        modifier = Modifier.size(48.dp),
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                    Text(
                        text = strings.secureOwnerAccess,
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Bold,
                        color = HuntPlatinumWhite,
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "Administrator operations are strictly restricted to the verified platform owner account ($OWNER_ADMIN_EMAIL) and enforced server-side by Cloud Firestore Security Rules.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = HuntMutedSilver,
                        textAlign = TextAlign.Center,
                    )
                    Spacer(modifier = Modifier.height(20.dp))
                    HuntPrimaryButton(
                        text = "Return to Viewer Mode",
                        onClick = onBackToApp,
                        testTag = "admin_return_viewer_btn",
                    )
                }
            }
        }
        return
    }

    var activeModuleName by rememberSaveable(initialModule) {
        mutableStateOf(initialModule?.name)
    }
    val activeModule = activeModuleName?.let { runCatching { AdminModule.valueOf(it) }.getOrNull() }

    val ownerCatalog by viewModel.ownerCatalog.collectAsState()
    val ownerEpisodes by viewModel.ownerEpisodes.collectAsState()
    val ownerChannels by viewModel.ownerChannels.collectAsState()
    val ownerEpg by viewModel.ownerEpg.collectAsState()
    val ownerUploadJobs by viewModel.ownerUploadJobs.collectAsState()
    val ownerBackupSnapshots by viewModel.ownerBackupSnapshots.collectAsState()
    val storageHealthStatus by viewModel.storageHealthStatus.collectAsState()
    val analyticsState by viewModel.analyticsState.collectAsState()
    val brandingConfig by viewModel.brandingConfig.collectAsState()
    val storageConfig by viewModel.storageConfig.collectAsState()
    val isBusy by viewModel.isBusy.collectAsState()

    BoxWithConstraints(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .testTag("admin_panel_screen"),
    ) {
        val isExpandedLayout = maxWidth >= 780.dp

        if (isExpandedLayout) {
            BackHandler(onBack = onBackToApp)
            val currentTab = activeModule ?: AdminModule.UPLOAD
            Row(modifier = Modifier.fillMaxSize()) {
                // Tablet / Desktop Side Admin Rail
                Column(
                    modifier = Modifier
                        .width(270.dp)
                        .fillMaxHeight()
                        .background(HuntDeepCharcoal)
                        .padding(16.dp)
                        .verticalScroll(rememberScrollState()),
                ) {
                    AdminHeaderBar(
                        avatarUrl = viewModel.currentUserPhotoUrl,
                        displayName = viewModel.currentUserDisplayName ?: "Owner",
                        onBack = onBackToApp,
                    )
                    Spacer(modifier = Modifier.height(16.dp))
                    AdminModule.entries.forEach { mod ->
                        val selected = currentTab == mod
                        Surface(
                            onClick = { activeModuleName = mod.name },
                            shape = RoundedCornerShape(12.dp),
                            color = if (selected) HuntCrimsonRed else HuntSurfaceCard,
                            border = BorderStroke(1.dp, if (selected) HuntCrimsonBright else HuntBorderSubtle),
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 4.dp)
                                .testTag("admin_rail_${mod.name}"),
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier.padding(horizontal = 14.dp, vertical = 12.dp),
                            ) {
                                Icon(
                                    imageVector = iconForModule(mod),
                                    contentDescription = null,
                                    tint = if (selected) HuntPlatinumWhite else tintForModule(mod),
                                    modifier = Modifier.size(22.dp),
                                )
                                Spacer(modifier = Modifier.width(10.dp))
                                Text(
                                    text = mod.title,
                                    style = MaterialTheme.typography.labelLarge,
                                    color = HuntPlatinumWhite,
                                    fontWeight = FontWeight.Bold,
                                )
                            }
                        }
                    }
                    Spacer(modifier = Modifier.height(16.dp))
                    AdminSystemStatusCard(
                        publishedMoviesCount = ownerCatalog.count { it.publicationStatus == "PUBLISHED" },
                        publishedChannelsCount = ownerChannels.count { it.publicationStatus == "PUBLISHED" },
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                    OutlinedButton(
                        onClick = onLogout,
                        shape = RoundedCornerShape(12.dp),
                        border = BorderStroke(1.dp, HuntBorderSubtle),
                        modifier = Modifier.fillMaxWidth(),
                    ) {
                        Icon(Icons.AutoMirrored.Filled.Logout, contentDescription = null, tint = HuntPlatinumWhite)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(strings.logout, color = HuntPlatinumWhite)
                    }
                }

                // Right Workspace Pane
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxHeight(),
                ) {
                    RenderAdminModuleWorkspace(
                        module = currentTab,
                        viewModel = viewModel,
                        ownerCatalog = ownerCatalog,
                        ownerEpisodes = ownerEpisodes,
                        ownerChannels = ownerChannels,
                        ownerEpg = ownerEpg,
                        ownerUploadJobs = ownerUploadJobs,
                        ownerBackupSnapshots = ownerBackupSnapshots,
                        storageHealthStatus = storageHealthStatus,
                        analyticsState = analyticsState,
                        brandingConfig = brandingConfig,
                        storageConfig = storageConfig,
                        isBusy = isBusy,
                        showBackHeader = false,
                        onBackToDashboard = { activeModuleName = null },
                        onPreviewContent = onPreviewContent,
                    )
                }
            }
        } else {
            // Compact Mobile Layout matching bottom-center reference mockup
            if (activeModule == null) {
                BackHandler(onBack = onBackToApp)
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .verticalScroll(rememberScrollState())
                        .padding(horizontal = 16.dp, vertical = 12.dp),
                ) {
                    AdminHeaderBar(
                        avatarUrl = viewModel.currentUserPhotoUrl,
                        displayName = viewModel.currentUserDisplayName ?: "Owner",
                        onBack = onBackToApp,
                    )

                    Spacer(modifier = Modifier.height(18.dp))

                    // 3x2 Module Grid matching reference image
                    val rows = AdminModule.entries.chunked(3)
                    rows.forEach { rowModules ->
                        Row(
                            horizontalArrangement = Arrangement.spacedBy(10.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(bottom = 10.dp),
                        ) {
                            rowModules.forEach { mod ->
                                AdminModuleGridTile(
                                    module = mod,
                                    onClick = { activeModuleName = mod.name },
                                    modifier = Modifier.weight(1f),
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    AdminSystemStatusCard(
                        publishedMoviesCount = ownerCatalog.count { it.publicationStatus == "PUBLISHED" },
                        publishedChannelsCount = ownerChannels.count { it.publicationStatus == "PUBLISHED" },
                    )

                    Spacer(modifier = Modifier.height(14.dp))

                    // Quick Action: Seed Authorized Open-License Test Catalog
                    Card(
                        shape = RoundedCornerShape(16.dp),
                        colors = CardDefaults.cardColors(containerColor = HuntSurfaceCard),
                        border = BorderStroke(1.dp, HuntBorderSubtle),
                        modifier = Modifier.fillMaxWidth(),
                    ) {
                        Column(modifier = Modifier.padding(14.dp)) {
                            Text(
                                text = "Authorized Open-License HLS Stream Bootstrap",
                                style = MaterialTheme.typography.titleSmall,
                                fontWeight = FontWeight.Bold,
                                color = HuntPlatinumWhite,
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = "Populate or refresh open-licensed Creative Commons cinema titles (Blender Studio / Sintel / Tears of Steel), series episodes, HLS test channels, and EPG schedules for instant verification.",
                                style = MaterialTheme.typography.bodySmall,
                                color = HuntMutedSilver,
                            )
                            Spacer(modifier = Modifier.height(10.dp))
                            HuntPrimaryButton(
                                text = "Load Open-License Test Catalog",
                                icon = Icons.Filled.CloudDownload,
                                isLoading = isBusy,
                                onClick = { viewModel.seedOpenLicenseTestCatalog() },
                                testTag = "admin_seed_catalog_btn",
                                modifier = Modifier.fillMaxWidth(),
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(18.dp))

                    OutlinedButton(
                        onClick = onLogout,
                        shape = RoundedCornerShape(14.dp),
                        border = BorderStroke(1.dp, HuntBorderSubtle),
                        modifier = Modifier
                            .fillMaxWidth()
                            .defaultMinSize(minHeight = 50.dp)
                            .testTag("admin_logout_button"),
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.Logout,
                            contentDescription = null,
                            tint = HuntPlatinumWhite,
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = strings.logout,
                            style = MaterialTheme.typography.titleSmall,
                            color = HuntPlatinumWhite,
                            fontWeight = FontWeight.Bold,
                        )
                    }

                    Spacer(modifier = Modifier.height(24.dp))
                }
            } else {
                BackHandler { activeModuleName = null }
                RenderAdminModuleWorkspace(
                    module = activeModule,
                    viewModel = viewModel,
                    ownerCatalog = ownerCatalog,
                    ownerEpisodes = ownerEpisodes,
                    ownerChannels = ownerChannels,
                    ownerEpg = ownerEpg,
                    ownerUploadJobs = ownerUploadJobs,
                    ownerBackupSnapshots = ownerBackupSnapshots,
                    storageHealthStatus = storageHealthStatus,
                    analyticsState = analyticsState,
                    brandingConfig = brandingConfig,
                    storageConfig = storageConfig,
                    isBusy = isBusy,
                    showBackHeader = true,
                    onBackToDashboard = { activeModuleName = null },
                    onPreviewContent = onPreviewContent,
                )
            }
        }
    }
}

@Composable
private fun AdminHeaderBar(
    avatarUrl: String?,
    displayName: String,
    onBack: () -> Unit,
) {
    val strings = LocalStrings.current
    Row(
        verticalAlignment = Alignment.CenterVertically,
        modifier = Modifier.fillMaxWidth(),
    ) {
        IconButton(
            onClick = onBack,
            modifier = Modifier.testTag("admin_back_to_viewer_btn"),
        ) {
            Icon(
                imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                contentDescription = "Back to Viewer App",
                tint = HuntPlatinumWhite,
            )
        }
        // Crimson security shield matching reference image
        Box(
            contentAlignment = Alignment.Center,
            modifier = Modifier
                .size(44.dp)
                .clip(CircleShape)
                .background(HuntCrimsonRed.copy(alpha = 0.2f)),
        ) {
            Icon(
                imageVector = Icons.Filled.VerifiedUser,
                contentDescription = strings.secureOwnerAccess,
                tint = HuntCrimsonBright,
                modifier = Modifier.size(28.dp),
            )
        }
        Spacer(modifier = Modifier.width(10.dp))
        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = strings.adminPanel,
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.ExtraBold,
                color = HuntPlatinumWhite,
            )
            Text(
                text = strings.secureOwnerAccess,
                style = MaterialTheme.typography.labelSmall,
                color = HuntMetallicSilver,
            )
        }
        Box(
            contentAlignment = Alignment.Center,
            modifier = Modifier
                .size(38.dp)
                .clip(CircleShape)
                .background(HuntElevatedCard),
        ) {
            if (!avatarUrl.isNullOrBlank()) {
                AsyncImage(
                    model = avatarUrl,
                    contentDescription = displayName,
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.fillMaxSize(),
                )
            } else {
                Text(
                    text = displayName.firstOrNull()?.uppercase() ?: "O",
                    style = MaterialTheme.typography.titleSmall,
                    color = HuntPlatinumWhite,
                    fontWeight = FontWeight.Bold,
                )
            }
        }
    }
}

@Composable
private fun AdminModuleGridTile(
    module: AdminModule,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val accent = tintForModule(module)
    Card(
        onClick = onClick,
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = HuntSurfaceCard),
        border = BorderStroke(1.dp, accent.copy(alpha = 0.35f)),
        modifier = modifier
            .height(114.dp)
            .testTag("admin_tile_${module.name}"),
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center,
            modifier = Modifier
                .fillMaxSize()
                .padding(8.dp),
        ) {
            Box(
                contentAlignment = Alignment.Center,
                modifier = Modifier
                    .size(44.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .background(accent.copy(alpha = 0.16f)),
            ) {
                Icon(
                    imageVector = iconForModule(module),
                    contentDescription = module.title,
                    tint = accent,
                    modifier = Modifier.size(26.dp),
                )
            }
            Spacer(modifier = Modifier.height(10.dp))
            Text(
                text = module.title,
                style = MaterialTheme.typography.labelMedium,
                color = HuntPlatinumWhite,
                fontWeight = FontWeight.SemiBold,
                textAlign = TextAlign.Center,
                maxLines = 2,
            )
        }
    }
}

@Composable
private fun AdminSystemStatusCard(
    publishedMoviesCount: Int,
    publishedChannelsCount: Int,
) {
    val strings = LocalStrings.current
    Card(
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = HuntSurfaceCard),
        border = BorderStroke(1.dp, HuntEmeraldGreen.copy(alpha = 0.4f)),
        modifier = Modifier
            .fillMaxWidth()
            .testTag("admin_system_status_card"),
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.padding(16.dp),
        ) {
            Icon(
                imageVector = Icons.Filled.CheckCircle,
                contentDescription = null,
                tint = HuntEmeraldGreen,
                modifier = Modifier.size(38.dp),
            )
            Spacer(modifier = Modifier.width(12.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = strings.systemStatus,
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.Bold,
                    color = HuntPlatinumWhite,
                )
                Text(
                    text = strings.allSystemsRunning,
                    style = MaterialTheme.typography.labelMedium,
                    color = HuntEmeraldGreen,
                    fontWeight = FontWeight.SemiBold,
                )
                Text(
                    text = "$publishedMoviesCount Published VOD • $publishedChannelsCount Live TV",
                    style = MaterialTheme.typography.labelSmall,
                    color = HuntMutedSilver,
                )
            }
            // Live green telemetry waveform matching reference mockup
            Canvas(
                modifier = Modifier
                    .width(74.dp)
                    .height(34.dp),
            ) {
                val points = listOf(0.75f, 0.65f, 0.8f, 0.35f, 0.85f, 0.18f, 0.9f, 0.45f, 0.7f, 0.55f, 0.72f)
                val path = Path()
                val stepX = size.width / (points.size - 1)
                points.forEachIndexed { idx, normY ->
                    val x = idx * stepX
                    val y = normY * size.height
                    if (idx == 0) path.moveTo(x, y) else path.lineTo(x, y)
                }
                drawPath(
                    path = path,
                    color = HuntEmeraldGreen,
                    style = Stroke(width = 2.4.dp.toPx(), cap = StrokeCap.Round, join = StrokeJoin.Round),
                )
                drawLine(
                    color = HuntEmeraldGreen.copy(alpha = 0.25f),
                    start = Offset(0f, size.height),
                    end = Offset(size.width, size.height),
                    strokeWidth = 1.dp.toPx(),
                )
            }
        }
    }
}

private fun iconForModule(module: AdminModule): ImageVector = when (module) {
    AdminModule.UPLOAD -> Icons.Filled.CloudUpload
    AdminModule.CONTENT -> Icons.Filled.VideoLibrary
    AdminModule.CHANNELS -> Icons.Filled.LiveTv
    AdminModule.ANALYTICS -> Icons.Filled.BarChart
    AdminModule.SETTINGS -> Icons.Filled.Settings
    AdminModule.DEV_TOOLS -> Icons.Filled.Code
}

private fun tintForModule(module: AdminModule): Color = when (module) {
    AdminModule.UPLOAD -> Color(0xFF29B6F6) // Sky Cyan
    AdminModule.CONTENT -> Color(0xFFAB47BC) // Violet
    AdminModule.CHANNELS -> HuntEmeraldGreen // Emerald
    AdminModule.ANALYTICS -> HuntAmberWarning // Amber Gold
    AdminModule.SETTINGS -> Color(0xFF5C6BC0) // Indigo Blue
    AdminModule.DEV_TOOLS -> Color(0xFF66BB6A) // Code Green
}

@Composable
private fun RenderAdminModuleWorkspace(
    module: AdminModule,
    viewModel: HuntXProsViewModel,
    ownerCatalog: List<com.example.data.model.CatalogItem>,
    ownerEpisodes: List<com.example.data.model.EpisodeItem>,
    ownerChannels: List<com.example.data.model.TvChannel>,
    ownerEpg: List<com.example.data.model.EpgProgram>,
    ownerUploadJobs: List<com.example.data.model.UploadJob>,
    ownerBackupSnapshots: List<com.example.data.model.BackupSnapshot>,
    storageHealthStatus: com.example.data.model.StorageHealthStatus?,
    analyticsState: com.example.data.model.UiState<com.example.data.model.AnalyticsSummary>,
    brandingConfig: com.example.data.model.PlatformConfig?,
    storageConfig: com.example.data.model.PlatformConfig?,
    isBusy: Boolean,
    showBackHeader: Boolean,
    onBackToDashboard: () -> Unit,
    onPreviewContent: (String) -> Unit,
) {
    Column(modifier = Modifier.fillMaxSize()) {
        if (showBackHeader) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier
                    .fillMaxWidth()
                    .background(HuntDeepCharcoal)
                    .padding(horizontal = 8.dp, vertical = 8.dp),
            ) {
                IconButton(
                    onClick = onBackToDashboard,
                    modifier = Modifier.testTag("admin_module_back_btn"),
                ) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                        contentDescription = "Back to Admin Dashboard",
                        tint = HuntPlatinumWhite,
                    )
                }
                Text(
                    text = module.title,
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = HuntPlatinumWhite,
                )
            }
        }

        when (module) {
            AdminModule.UPLOAD -> AdminUploadVideosPane(
                viewModel = viewModel,
                uploadJobs = ownerUploadJobs,
                isBusy = isBusy,
            )

            AdminModule.CONTENT -> AdminManageContentPane(
                viewModel = viewModel,
                catalog = ownerCatalog,
                episodes = ownerEpisodes,
                onPreviewContent = onPreviewContent,
            )

            AdminModule.CHANNELS -> AdminTvChannelsPane(
                viewModel = viewModel,
                channels = ownerChannels,
                epgPrograms = ownerEpg,
            )

            AdminModule.ANALYTICS -> AdminAnalyticsPane(
                analyticsState = analyticsState,
                onRefresh = { viewModel.refreshAnalytics() },
            )

            AdminModule.SETTINGS -> AdminStorageAndBrandingPane(
                brandingConfig = brandingConfig,
                storageConfig = storageConfig,
                defaultFirebaseBucket = viewModel.defaultFirebaseBucket,
                storageHealthStatus = storageHealthStatus,
                backupSnapshots = ownerBackupSnapshots,
                isBusy = isBusy,
                onVerifyStorageHealth = { viewModel.verifyCloudStorageHealth() },
                onCreateBackupSnapshot = { label -> viewModel.createRecoveryBackupSnapshot(label) },
                onRestoreBackupSnapshot = { snap -> viewModel.restoreRecoverySnapshot(snap) },
                onSave = { branding, storage -> viewModel.saveBrandingAndStorage(branding, storage) },
            )

            AdminModule.DEV_TOOLS -> AdminDeveloperHubPane()
        }
    }
}
