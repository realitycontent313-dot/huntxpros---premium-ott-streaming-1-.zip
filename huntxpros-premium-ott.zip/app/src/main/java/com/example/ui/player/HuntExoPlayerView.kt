package com.example.ui.player

import android.content.pm.ActivityInfo
import android.net.Uri
import android.view.ViewGroup
import android.widget.FrameLayout
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.VolumeOff
import androidx.compose.material.icons.automirrored.filled.VolumeUp
import androidx.compose.material.icons.filled.ClosedCaption
import androidx.compose.material.icons.filled.ErrorOutline
import androidx.compose.material.icons.filled.Forward10
import androidx.compose.material.icons.filled.Fullscreen
import androidx.compose.material.icons.filled.FullscreenExit
import androidx.compose.material.icons.filled.HighQuality
import androidx.compose.material.icons.filled.Language
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Replay10
import androidx.compose.material.icons.filled.SkipNext
import androidx.compose.material.icons.filled.SkipPrevious
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.MimeTypes
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.common.util.UnstableApi
import androidx.media3.exoplayer.DefaultLoadControl
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.trackselection.DefaultTrackSelector
import androidx.media3.ui.AspectRatioFrameLayout
import androidx.media3.ui.PlayerView
import coil.compose.AsyncImage
import com.example.R
import com.example.auth.findActivity
import com.example.i18n.LocalStrings
import com.example.ui.components.HuntPrimaryButton
import com.example.ui.components.LivePulseBadge
import com.example.ui.theme.HuntCrimsonBright
import com.example.ui.theme.HuntCrimsonRed
import com.example.ui.theme.HuntMetallicSilver
import com.example.ui.theme.HuntObsidianBlack
import com.example.ui.theme.HuntPlatinumWhite
import kotlinx.coroutines.delay

@androidx.annotation.OptIn(UnstableApi::class)
@Composable
fun HuntExoPlayerView(
    streamUrl: String,
    streamFormat: String = "HLS",
    title: String = "",
    isLiveStream: Boolean = false,
    initialPositionMs: Long = 0L,
    defaultQualityPref: String = "AUTO",
    watermarkEnabled: Boolean = true,
    customLogoUrl: String = "",
    isFullscreen: Boolean = false,
    onToggleFullscreen: (Boolean) -> Unit = {},
    onBackClick: (() -> Unit)? = null,
    onPreviousItem: (() -> Unit)? = null,
    onNextItem: (() -> Unit)? = null,
    autoPlayNext: Boolean = true,
    onProgressUpdate: (positionMs: Long, durationMs: Long) -> Unit = { _, _ -> },
    onSessionEnded: (watchedSeconds: Long, completed: Boolean) -> Unit = { _, _ -> },
    modifier: Modifier = Modifier,
) {
    val context = LocalContext.current
    val strings = LocalStrings.current

    var isPlaying by remember { mutableStateOf(true) }
    var isBuffering by remember { mutableStateOf(true) }
    var errorMessage by remember { mutableStateOf<String?>(null) }
    var currentPosMs by remember { mutableLongStateOf(initialPositionMs.coerceAtLeast(0L)) }
    var durationMs by remember { mutableLongStateOf(0L) }
    var showControls by remember { mutableStateOf(true) }
    var isMuted by remember { mutableStateOf(false) }
    var volumeLevel by remember { mutableFloatStateOf(1f) }
    var playbackSpeed by remember { mutableFloatStateOf(1f) }
    var selectedQuality by remember { mutableStateOf(defaultQualityPref) }
    var subtitlesEnabled by remember { mutableStateOf(false) }

    var showSpeedDialog by remember { mutableStateOf(false) }
    var showQualityDialog by remember { mutableStateOf(false) }
    var showAudioSubDialog by remember { mutableStateOf(false) }
    var availableAudioTracks by remember { mutableStateOf<List<String>>(emptyList()) }
    var availableSubtitleTracks by remember { mutableStateOf<List<String>>(emptyList()) }
    var watchedSecondsAccum by remember { mutableLongStateOf(0L) }

    val trackSelector = remember(context) {
        DefaultTrackSelector(context).apply {
            parameters = buildUponParameters()
                .setForceLowestBitrate(defaultQualityPref == "DATA_SAVER")
                .build()
        }
    }

    // Mobile-resilient buffer tuning for unstable 3G/4G/5G networks
    val exoPlayer = remember(context) {
        val loadControl = DefaultLoadControl.Builder()
            .setBufferDurationsMs(
                12_000, // minBufferMs
                45_000, // maxBufferMs
                2_000,  // bufferForPlaybackMs (fast start)
                4_500,  // bufferForPlaybackAfterRebufferMs
            )
            .build()

        ExoPlayer.Builder(context)
            .setTrackSelector(trackSelector)
            .setLoadControl(loadControl)
            .build()
            .apply {
                playWhenReady = true
            }
    }

    // Handle fullscreen landscape orientation + immersive system bars
    LaunchedEffect(isFullscreen) {
        val activity = context.findActivity() ?: return@LaunchedEffect
        val window = activity.window
        val insetsController = WindowCompat.getInsetsController(window, window.decorView)
        if (isFullscreen) {
            activity.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
            insetsController.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
            insetsController.hide(WindowInsetsCompat.Type.systemBars())
        } else {
            activity.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
            insetsController.show(WindowInsetsCompat.Type.systemBars())
        }
    }

    // Load MediaItem whenever streamUrl changes
    LaunchedEffect(streamUrl, streamFormat) {
        errorMessage = null
        if (streamUrl.isBlank()) {
            isBuffering = false
            errorMessage = strings.streamUnavailable
            exoPlayer.stop()
            return@LaunchedEffect
        }
        isBuffering = true
        val uri = Uri.parse(streamUrl.trim())
        val mimeType = when {
            streamFormat.equals("HLS", ignoreCase = true) || streamUrl.contains(".m3u8", ignoreCase = true) ->
                MimeTypes.APPLICATION_M3U8
            streamFormat.equals("DASH", ignoreCase = true) || streamUrl.contains(".mpd", ignoreCase = true) ->
                MimeTypes.APPLICATION_MPD
            else -> null
        }
        val mediaItemBuilder = MediaItem.Builder().setUri(uri)
        if (mimeType != null) mediaItemBuilder.setMimeType(mimeType)

        exoPlayer.setMediaItem(mediaItemBuilder.build())
        exoPlayer.prepare()
        if (!isLiveStream && initialPositionMs > 1000L) {
            exoPlayer.seekTo(initialPositionMs)
        }
        exoPlayer.playWhenReady = true
    }

    // Apply quality constraints dynamically
    LaunchedEffect(selectedQuality) {
        val builder = trackSelector.buildUponParameters()
        when (selectedQuality) {
            "1080P" -> builder.setMaxVideoSize(1920, 1080).setForceLowestBitrate(false)
            "720P" -> builder.setMaxVideoSize(1280, 720).setForceLowestBitrate(false)
            "480P" -> builder.setMaxVideoSize(854, 480).setForceLowestBitrate(false)
            "DATA_SAVER" -> builder.setMaxVideoSizeSd().setForceLowestBitrate(true)
            else -> builder.clearVideoSizeConstraints().setForceLowestBitrate(false)
        }
        trackSelector.parameters = builder.build()
    }

    // Apply subtitle visibility
    LaunchedEffect(subtitlesEnabled) {
        trackSelector.parameters = trackSelector.buildUponParameters()
            .setTrackTypeDisabled(C.TRACK_TYPE_TEXT, !subtitlesEnabled)
            .build()
    }

    // Poll playback position & persist resume checkpoints
    LaunchedEffect(exoPlayer, isLiveStream) {
        var tick = 0
        while (true) {
            delay(1000L)
            isPlaying = exoPlayer.isPlaying
            currentPosMs = exoPlayer.currentPosition.coerceAtLeast(0L)
            durationMs = exoPlayer.duration.takeIf { it > 0L } ?: 0L
            if (exoPlayer.isPlaying) {
                watchedSecondsAccum += 1L
                tick++
                if (!isLiveStream && tick % 5 == 0 && durationMs > 0L) {
                    onProgressUpdate(currentPosMs, durationMs)
                }
            }
        }
    }

    DisposableEffect(exoPlayer) {
        val listener = object : Player.Listener {
            override fun onPlaybackStateChanged(playbackState: Int) {
                isBuffering = playbackState == Player.STATE_BUFFERING
                if (playbackState == Player.STATE_READY) {
                    errorMessage = null
                    durationMs = exoPlayer.duration.takeIf { it > 0L } ?: 0L
                    // Inspect audio & subtitle tracks
                    val groups = exoPlayer.currentTracks.groups
                    val audioNames = mutableListOf<String>()
                    val subNames = mutableListOf<String>()
                    for (group in groups) {
                        val format = group.mediaTrackGroup.getFormat(0)
                        val langLabel = format.label ?: format.language ?: "Default"
                        if (group.type == C.TRACK_TYPE_AUDIO) audioNames.add(langLabel)
                        if (group.type == C.TRACK_TYPE_TEXT) subNames.add(langLabel)
                    }
                    availableAudioTracks = audioNames.distinct()
                    availableSubtitleTracks = subNames.distinct()
                } else if (playbackState == Player.STATE_ENDED) {
                    if (!isLiveStream && durationMs > 0L) {
                        onProgressUpdate(durationMs, durationMs)
                    }
                    onSessionEnded(watchedSecondsAccum, true)
                    if (autoPlayNext && onNextItem != null) {
                        onNextItem()
                    }
                }
            }

            override fun onIsPlayingChanged(playing: Boolean) {
                isPlaying = playing
            }

            override fun onPlayerError(error: PlaybackException) {
                isBuffering = false
                errorMessage = "${strings.streamUnavailable} (${error.errorCodeName})"
            }
        }
        exoPlayer.addListener(listener)

        onDispose {
            val finalPos = exoPlayer.currentPosition.coerceAtLeast(0L)
            val finalDur = exoPlayer.duration.takeIf { it > 0L } ?: 0L
            if (!isLiveStream && finalPos > 1000L && finalDur > 0L) {
                onProgressUpdate(finalPos, finalDur)
            }
            if (watchedSecondsAccum >= 2L) {
                val completed = finalDur > 0L && finalPos >= (finalDur * 0.90).toLong()
                onSessionEnded(watchedSecondsAccum, completed)
            }
            val activity = context.findActivity()
            if (activity != null && isFullscreen) {
                activity.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
                val insetsController = WindowCompat.getInsetsController(activity.window, activity.window.decorView)
                insetsController.show(WindowInsetsCompat.Type.systemBars())
            }
            exoPlayer.removeListener(listener)
            exoPlayer.release()
        }
    }

    val containerModifier = if (isFullscreen) {
        modifier.fillMaxSize().background(HuntObsidianBlack)
    } else {
        modifier.fillMaxWidth().aspectRatio(16f / 9f).background(HuntObsidianBlack)
    }

    Box(
        modifier = containerModifier
            .clickable(
                interactionSource = remember { MutableInteractionSource() },
                indication = null,
            ) { showControls = !showControls }
            .testTag("hunt_video_player_box"),
    ) {
        AndroidView(
            factory = { ctx ->
                PlayerView(ctx).apply {
                    useController = false
                    resizeMode = AspectRatioFrameLayout.RESIZE_MODE_FIT
                    layoutParams = FrameLayout.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT,
                        ViewGroup.LayoutParams.MATCH_PARENT,
                    )
                    player = exoPlayer
                }
            },
            update = { view ->
                if (view.player !== exoPlayer) {
                    view.player = exoPlayer
                }
            },
            modifier = Modifier.fillMaxSize(),
        )

        // Official HUNTXPROS Watermark in Top-Right (scales cleanly, never distorts)
        if (watermarkEnabled) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier
                    .align(Alignment.TopEnd)
                    .padding(top = 12.dp, end = 14.dp)
                    .alpha(0.84f)
                    .clip(RoundedCornerShape(8.dp))
                    .background(HuntObsidianBlack.copy(alpha = 0.52f))
                    .padding(horizontal = 8.dp, vertical = 4.dp),
            ) {
                if (isLiveStream) {
                    LivePulseBadge(modifier = Modifier.padding(end = 6.dp))
                }
                if (customLogoUrl.isNotBlank()) {
                    AsyncImage(
                        model = customLogoUrl,
                        contentDescription = "HUNTXPROS Watermark",
                        contentScale = ContentScale.Fit,
                        modifier = Modifier.size(20.dp),
                    )
                } else {
                    Image(
                        painter = painterResource(id = R.drawable.huntxpros_logo),
                        contentDescription = "HUNTXPROS Watermark",
                        contentScale = ContentScale.Fit,
                        modifier = Modifier.size(20.dp),
                    )
                }
                Spacer(modifier = Modifier.width(5.dp))
                Text(
                    text = "HUNTXPROS",
                    style = MaterialTheme.typography.labelSmall,
                    color = HuntPlatinumWhite,
                    fontWeight = FontWeight.Bold,
                )
            }
        }

        // Buffering Indicator
        if (isBuffering && errorMessage == null) {
            CircularProgressIndicator(
                color = HuntCrimsonRed,
                strokeWidth = 3.dp,
                modifier = Modifier
                    .size(44.dp)
                    .align(Alignment.Center),
            )
        }

        // Network / Stream Error Overlay with Retry Playback
        if (errorMessage != null) {
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center,
                modifier = Modifier
                    .fillMaxSize()
                    .background(HuntObsidianBlack.copy(alpha = 0.88f))
                    .padding(20.dp),
            ) {
                Icon(
                    imageVector = Icons.Filled.ErrorOutline,
                    contentDescription = "Stream Error",
                    tint = HuntCrimsonBright,
                    modifier = Modifier.size(38.dp),
                )
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = errorMessage ?: strings.streamUnavailable,
                    style = MaterialTheme.typography.bodySmall,
                    color = HuntPlatinumWhite,
                    textAlign = TextAlign.Center,
                )
                Spacer(modifier = Modifier.height(12.dp))
                HuntPrimaryButton(
                    text = strings.retryPlayback,
                    onClick = {
                        errorMessage = null
                        isBuffering = true
                        exoPlayer.prepare()
                        exoPlayer.play()
                    },
                    testTag = "player_retry_button",
                )
            }
        }

        // Interactive Controls Overlay
        AnimatedVisibility(
            visible = showControls && errorMessage == null,
            enter = fadeIn(),
            exit = fadeOut(),
            modifier = Modifier.fillMaxSize(),
        ) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(
                        Brush.verticalGradient(
                            listOf(
                                HuntObsidianBlack.copy(alpha = 0.68f),
                                Color.Transparent,
                                HuntObsidianBlack.copy(alpha = 0.84f),
                            )
                        )
                    )
            ) {
                // Top Bar: Back + Title + Speed / Quality / Audio-Subtitle Actions
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier
                        .fillMaxWidth()
                        .align(Alignment.TopStart)
                        .padding(horizontal = 8.dp, vertical = 4.dp),
                ) {
                    if (onBackClick != null) {
                        IconButton(
                            onClick = onBackClick,
                            modifier = Modifier.testTag("player_back_btn"),
                        ) {
                            Icon(
                                imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                                contentDescription = "Back",
                                tint = HuntPlatinumWhite,
                            )
                        }
                    }
                    Text(
                        text = title,
                        style = MaterialTheme.typography.titleSmall,
                        color = HuntPlatinumWhite,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.weight(1f),
                    )
                    if (!isLiveStream) {
                        IconButton(onClick = { showSpeedDialog = true }) {
                            Icon(
                                imageVector = Icons.Filled.Speed,
                                contentDescription = strings.playbackSpeed,
                                tint = HuntPlatinumWhite,
                            )
                        }
                    }
                    IconButton(onClick = { showQualityDialog = true }) {
                        Icon(
                            imageVector = Icons.Filled.HighQuality,
                            contentDescription = strings.videoQuality,
                            tint = HuntPlatinumWhite,
                        )
                    }
                    IconButton(onClick = { showAudioSubDialog = true }) {
                        Icon(
                            imageVector = if (subtitlesEnabled) Icons.Filled.ClosedCaption else Icons.Filled.Language,
                            contentDescription = strings.subtitles,
                            tint = if (subtitlesEnabled) HuntCrimsonBright else HuntPlatinumWhite,
                        )
                    }
                }

                // Center Transport Controls
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(18.dp),
                    modifier = Modifier.align(Alignment.Center),
                ) {
                    if (onPreviousItem != null) {
                        IconButton(onClick = onPreviousItem) {
                            Icon(
                                imageVector = Icons.Filled.SkipPrevious,
                                contentDescription = strings.prevEpisode,
                                tint = HuntPlatinumWhite,
                                modifier = Modifier.size(30.dp),
                            )
                        }
                    }
                    if (!isLiveStream) {
                        IconButton(
                            onClick = { exoPlayer.seekTo((exoPlayer.currentPosition - 10_000L).coerceAtLeast(0L)) }
                        ) {
                            Icon(
                                imageVector = Icons.Filled.Replay10,
                                contentDescription = "Rewind 10 seconds",
                                tint = HuntPlatinumWhite,
                                modifier = Modifier.size(30.dp),
                            )
                        }
                    }

                    Surface(
                        onClick = {
                            if (exoPlayer.isPlaying) exoPlayer.pause() else exoPlayer.play()
                        },
                        shape = CircleShape,
                        color = HuntCrimsonRed,
                        modifier = Modifier
                            .size(54.dp)
                            .testTag("player_play_pause_btn"),
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Icon(
                                imageVector = if (isPlaying) Icons.Filled.Pause else Icons.Filled.PlayArrow,
                                contentDescription = if (isPlaying) "Pause" else "Play",
                                tint = HuntPlatinumWhite,
                                modifier = Modifier.size(30.dp),
                            )
                        }
                    }

                    if (!isLiveStream) {
                        IconButton(
                            onClick = { exoPlayer.seekTo(exoPlayer.currentPosition + 10_000L) }
                        ) {
                            Icon(
                                imageVector = Icons.Filled.Forward10,
                                contentDescription = "Forward 10 seconds",
                                tint = HuntPlatinumWhite,
                                modifier = Modifier.size(30.dp),
                            )
                        }
                    }
                    if (onNextItem != null) {
                        IconButton(onClick = onNextItem) {
                            Icon(
                                imageVector = Icons.Filled.SkipNext,
                                contentDescription = strings.nextEpisode,
                                tint = HuntPlatinumWhite,
                                modifier = Modifier.size(30.dp),
                            )
                        }
                    }
                }

                // Bottom Bar: Mute/Volume + SeekBar + Time + Fullscreen
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .align(Alignment.BottomCenter)
                        .padding(horizontal = 12.dp, vertical = 6.dp),
                ) {
                    if (!isLiveStream && durationMs > 0L) {
                        Slider(
                            value = currentPosMs.toFloat().coerceIn(0f, durationMs.toFloat()),
                            onValueChange = { newPos ->
                                currentPosMs = newPos.toLong()
                                exoPlayer.seekTo(currentPosMs)
                            },
                            valueRange = 0f..durationMs.toFloat(),
                            colors = SliderDefaults.colors(
                                thumbColor = HuntCrimsonBright,
                                activeTrackColor = HuntCrimsonRed,
                                inactiveTrackColor = HuntPlatinumWhite.copy(alpha = 0.3f),
                            ),
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(22.dp),
                        )
                    }

                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.fillMaxWidth(),
                    ) {
                        IconButton(
                            onClick = {
                                isMuted = !isMuted
                                exoPlayer.volume = if (isMuted) 0f else volumeLevel
                            },
                            modifier = Modifier.size(36.dp),
                        ) {
                            Icon(
                                imageVector = if (isMuted) Icons.AutoMirrored.Filled.VolumeOff else Icons.AutoMirrored.Filled.VolumeUp,
                                contentDescription = "Mute or Unmute",
                                tint = HuntPlatinumWhite,
                                modifier = Modifier.size(20.dp),
                            )
                        }

                        if (isLiveStream) {
                            LivePulseBadge()
                        } else {
                            Text(
                                text = "${formatPlayerTime(currentPosMs)} / ${formatPlayerTime(durationMs)}",
                                style = MaterialTheme.typography.labelSmall,
                                color = HuntMetallicSilver,
                            )
                        }

                        Spacer(modifier = Modifier.weight(1f))

                        Text(
                            text = if (isLiveStream) selectedQuality else "${playbackSpeed}x • $selectedQuality",
                            style = MaterialTheme.typography.labelSmall,
                            color = HuntMetallicSilver,
                        )

                        IconButton(
                            onClick = { onToggleFullscreen(!isFullscreen) },
                            modifier = Modifier
                                .size(38.dp)
                                .testTag("player_fullscreen_btn"),
                        ) {
                            Icon(
                                imageVector = if (isFullscreen) Icons.Filled.FullscreenExit else Icons.Filled.Fullscreen,
                                contentDescription = "Toggle Fullscreen",
                                tint = HuntPlatinumWhite,
                                modifier = Modifier.size(22.dp),
                            )
                        }
                    }
                }
            }
        }
    }

    if (showSpeedDialog) {
        val speeds = listOf(0.5f, 0.75f, 1.0f, 1.25f, 1.5f, 2.0f)
        AlertDialog(
            onDismissRequest = { showSpeedDialog = false },
            title = { Text(strings.playbackSpeed) },
            text = {
                Column {
                    speeds.forEach { spd ->
                        TextButton(
                            onClick = {
                                playbackSpeed = spd
                                exoPlayer.setPlaybackSpeed(spd)
                                showSpeedDialog = false
                            },
                            modifier = Modifier.fillMaxWidth(),
                        ) {
                            Text(
                                text = "${spd}x" + if (playbackSpeed == spd) " ✓" else "",
                                color = if (playbackSpeed == spd) HuntCrimsonBright else MaterialTheme.colorScheme.onSurface,
                            )
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { showSpeedDialog = false }) { Text("Close") }
            },
        )
    }

    if (showQualityDialog) {
        val qualities = listOf(
            "AUTO" to "Auto (Adaptive HLS/DASH)",
            "1080P" to "1080p Full HD",
            "720P" to "720p HD",
            "480P" to "480p Standard",
            "DATA_SAVER" to "Data Saver (Slow Mobile Internet)",
        )
        AlertDialog(
            onDismissRequest = { showQualityDialog = false },
            title = { Text(strings.videoQuality) },
            text = {
                Column {
                    qualities.forEach { (code, label) ->
                        TextButton(
                            onClick = {
                                selectedQuality = code
                                showQualityDialog = false
                            },
                            modifier = Modifier.fillMaxWidth(),
                        ) {
                            Text(
                                text = label + if (selectedQuality == code) " ✓" else "",
                                color = if (selectedQuality == code) HuntCrimsonBright else MaterialTheme.colorScheme.onSurface,
                            )
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { showQualityDialog = false }) { Text("Close") }
            },
        )
    }

    if (showAudioSubDialog) {
        AlertDialog(
            onDismissRequest = { showAudioSubDialog = false },
            title = { Text("${strings.audioTrack} & ${strings.subtitles}") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        text = "${strings.audioTrack}: ${availableAudioTracks.ifEmpty { listOf("Primary Stream Audio") }.joinToString(", ")}",
                        style = MaterialTheme.typography.bodySmall,
                    )
                    Text(
                        text = "${strings.subtitles}: ${if (subtitlesEnabled) "Enabled" else "Off"}",
                        style = MaterialTheme.typography.bodyMedium,
                        fontWeight = FontWeight.SemiBold,
                    )
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        TextButton(onClick = { subtitlesEnabled = false; showAudioSubDialog = false }) {
                            Text("Subtitles Off")
                        }
                        TextButton(onClick = { subtitlesEnabled = true; showAudioSubDialog = false }) {
                            Text("Enable Stream Captions")
                        }
                    }
                    if (availableSubtitleTracks.isNotEmpty()) {
                        Text(
                            text = "Available caption tracks: ${availableSubtitleTracks.joinToString(", ")}",
                            style = MaterialTheme.typography.labelSmall,
                            color = HuntMetallicSilver,
                        )
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { showAudioSubDialog = false }) { Text("Done") }
            },
        )
    }
}

private fun formatPlayerTime(ms: Long): String {
    val totalSec = (ms.coerceAtLeast(0L)) / 1000L
    val hrs = totalSec / 3600L
    val mins = (totalSec % 3600L) / 60L
    val secs = totalSec % 60L
    return if (hrs > 0L) {
        String.format("%d:%02d:%02d", hrs, mins, secs)
    } else {
        String.format("%02d:%02d", mins, secs)
    }
}
