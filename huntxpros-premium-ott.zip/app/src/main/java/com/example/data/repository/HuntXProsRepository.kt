package com.example.data.repository

import android.content.Context
import com.example.R
import com.example.data.error.OperationType
import com.example.data.error.handleFirestoreError
import com.example.data.model.AnalyticsSummary
import com.example.data.model.BackupSnapshot
import com.example.data.model.CatalogItem
import com.example.data.model.ContentComment
import com.example.data.model.ContentLike
import com.example.data.model.EpgProgram
import com.example.data.model.EpisodeItem
import com.example.data.model.FavoriteChannelEntry
import com.example.data.model.OWNER_ADMIN_EMAIL
import com.example.data.model.PlatformConfig
import com.example.data.model.PlaybackAnalyticsEvent
import com.example.data.model.TvChannel
import com.example.data.model.UploadJob
import com.example.data.model.UserProfile
import com.example.data.model.WatchHistoryEntry
import com.example.data.model.WatchlistEntry
import com.google.firebase.Firebase
import com.google.firebase.Timestamp
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.auth
import com.google.firebase.firestore.DocumentSnapshot
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.snapshots
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.UUID
import kotlin.coroutines.cancellation.CancellationException
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.tasks.await
import org.json.JSONArray
import org.json.JSONObject

class HuntXProsRepository(
    private val db: FirebaseFirestore,
    private val auth: FirebaseAuth = Firebase.auth,
) {
    constructor(context: Context) : this(
        FirebaseFirestore.getInstance(
            context.applicationContext.getString(R.string.firestore_database_id)
        ),
        Firebase.auth,
    )

    private fun requireUserId(): String {
        return auth.currentUser?.uid
            ?: throw IllegalStateException("User must be signed in with Google before accessing Firestore.")
    }

    fun isCurrentUserOwner(): Boolean {
        val user = auth.currentUser ?: return false
        return user.email?.equals(OWNER_ADMIN_EMAIL, ignoreCase = true) == true && user.isEmailVerified
    }

    // -------------------------------------------------------------------------
    // 1. Viewer Profile & Personalization Preferences
    // -------------------------------------------------------------------------
    fun observeUserProfile(userId: String): Flow<UserProfile?> {
        val path = "users/$userId"
        return db.collection("users").document(userId)
            .snapshots()
            .map { snap ->
                if (snap.exists()) {
                    snap.toObject(UserProfile::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                } else {
                    null
                }
            }
            .catch { err ->
                if (err is Exception) handleFirestoreError(err, OperationType.GET, path)
                throw err
            }
    }

    suspend fun ensureOrUpdateUserProfile(profile: UserProfile): Result<Unit> = runCatching {
        val uid = requireUserId()
        val docRef = db.collection("users").document(uid)
        try {
            val snap = docRef.get().await()
            if (!snap.exists()) {
                docRef.set(profile.toCreateMap(uid)).await()
            } else {
                val updates = mutableMapOf<String, Any>(
                    "displayName" to profile.displayName.ifBlank { "Viewer" }.take(80),
                    "preferredLanguage" to profile.preferredLanguage.ifBlank { "en" },
                    "darkMode" to profile.darkMode,
                    "autoPlay" to profile.autoPlay,
                    "defaultQuality" to profile.defaultQuality.ifBlank { "AUTO" },
                    "subtitleLanguage" to profile.subtitleLanguage.ifBlank { "OFF" },
                    "notificationsEnabled" to profile.notificationsEnabled,
                    "updatedAt" to FieldValue.serverTimestamp(),
                )
                profile.avatarUrl?.takeIf { it.isNotBlank() }?.let { updates["avatarUrl"] = it.take(1000) }
                docRef.update(updates).await()
            }
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.WRITE, docRef.path)
            throw e
        }
    }

    // -------------------------------------------------------------------------
    // 2. Watchlist (My List)
    // -------------------------------------------------------------------------
    fun observeWatchlist(userId: String): Flow<List<WatchlistEntry>> {
        val path = "users/$userId/watchlist"
        return db.collection("users").document(userId).collection("watchlist")
            .snapshots()
            .map { snap ->
                snap.toObjects(WatchlistEntry::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                    .sortedByDescending { it.createdAt ?: Timestamp(0, 0) }
            }
            .catch { err ->
                if (err is Exception) handleFirestoreError(err, OperationType.LIST, path)
                throw err
            }
    }

    suspend fun toggleWatchlist(item: CatalogItem, currentlySaved: Boolean): Result<Unit> = runCatching {
        val uid = requireUserId()
        val safeDocId = item.id.ifBlank { error("Content ID missing") }
        val docRef = db.collection("users").document(uid).collection("watchlist").document(safeDocId)
        try {
            if (currentlySaved) {
                docRef.delete().await()
            } else {
                val payload = mapOf(
                    "userId" to uid,
                    "contentId" to safeDocId,
                    "contentType" to item.contentType,
                    "title" to item.title.take(200),
                    "posterUrl" to item.posterUrl.take(1000),
                    "genre" to item.genre.take(100),
                    "createdAt" to FieldValue.serverTimestamp(),
                )
                docRef.set(payload).await()
            }
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, if (currentlySaved) OperationType.DELETE else OperationType.CREATE, docRef.path)
            throw e
        }
    }

    // -------------------------------------------------------------------------
    // 3. Watch History & Continue Watching
    // -------------------------------------------------------------------------
    fun observeWatchHistory(userId: String): Flow<List<WatchHistoryEntry>> {
        val path = "users/$userId/watch_history"
        return db.collection("users").document(userId).collection("watch_history")
            .snapshots()
            .map { snap ->
                snap.toObjects(WatchHistoryEntry::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                    .sortedByDescending { it.updatedAt ?: it.createdAt ?: Timestamp(0, 0) }
            }
            .catch { err ->
                if (err is Exception) handleFirestoreError(err, OperationType.LIST, path)
                throw err
            }
    }

    suspend fun saveWatchProgress(
        contentId: String,
        episodeId: String?,
        contentType: String,
        title: String,
        subtitle: String?,
        thumbnailUrl: String,
        streamUrl: String,
        positionMs: Long,
        durationMs: Long,
    ): Result<Unit> = runCatching {
        val uid = requireUserId()
        val historyId = if (!episodeId.isNullOrBlank()) "${contentId}_$episodeId" else contentId
        val docRef = db.collection("users").document(uid).collection("watch_history").document(historyId)
        val completed = durationMs > 0 && positionMs >= (durationMs * 0.92).toLong()
        try {
            val existing = docRef.get().await()
            if (!existing.exists()) {
                val payload = mutableMapOf<String, Any>(
                    "userId" to uid,
                    "contentId" to contentId,
                    "contentType" to contentType,
                    "title" to title.take(200),
                    "thumbnailUrl" to thumbnailUrl.take(1000),
                    "streamUrl" to streamUrl.take(1500),
                    "positionMs" to positionMs.coerceAtLeast(0L),
                    "durationMs" to durationMs.coerceAtLeast(0L),
                    "completed" to completed,
                    "createdAt" to FieldValue.serverTimestamp(),
                    "updatedAt" to FieldValue.serverTimestamp(),
                )
                episodeId?.takeIf { it.isNotBlank() }?.let { payload["episodeId"] = it }
                subtitle?.takeIf { it.isNotBlank() }?.let { payload["subtitle"] = it.take(200) }
                docRef.set(payload).await()
            } else {
                val updates = mutableMapOf<String, Any>(
                    "title" to title.take(200),
                    "thumbnailUrl" to thumbnailUrl.take(1000),
                    "streamUrl" to streamUrl.take(1500),
                    "positionMs" to positionMs.coerceAtLeast(0L),
                    "durationMs" to durationMs.coerceAtLeast(0L),
                    "completed" to completed,
                    "updatedAt" to FieldValue.serverTimestamp(),
                )
                episodeId?.takeIf { it.isNotBlank() }?.let { updates["episodeId"] = it }
                subtitle?.takeIf { it.isNotBlank() }?.let { updates["subtitle"] = it.take(200) }
                docRef.update(updates).await()
            }
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.WRITE, docRef.path)
            throw e
        }
    }

    // -------------------------------------------------------------------------
    // 4. Favorite & Recently Watched Live TV Channels
    // -------------------------------------------------------------------------
    fun observeFavoriteChannels(userId: String): Flow<List<FavoriteChannelEntry>> {
        val path = "users/$userId/favorite_channels"
        return db.collection("users").document(userId).collection("favorite_channels")
            .snapshots()
            .map { snap ->
                snap.toObjects(FavoriteChannelEntry::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                    .sortedByDescending { it.updatedAt ?: it.createdAt ?: Timestamp(0, 0) }
            }
            .catch { err ->
                if (err is Exception) handleFirestoreError(err, OperationType.LIST, path)
                throw err
            }
    }

    suspend fun recordChannelInteraction(channel: TvChannel, isFavorite: Boolean): Result<Unit> = runCatching {
        val uid = requireUserId()
        val docRef = db.collection("users").document(uid).collection("favorite_channels").document(channel.id)
        try {
            val snap = docRef.get().await()
            if (!snap.exists()) {
                docRef.set(
                    mapOf(
                        "userId" to uid,
                        "channelId" to channel.id,
                        "channelName" to channel.name.take(150),
                        "logoUrl" to channel.logoUrl.take(1000),
                        "category" to channel.category.take(50),
                        "isFavorite" to isFavorite,
                        "createdAt" to FieldValue.serverTimestamp(),
                        "updatedAt" to FieldValue.serverTimestamp(),
                    )
                ).await()
            } else {
                docRef.update(
                    mapOf(
                        "channelName" to channel.name.take(150),
                        "logoUrl" to channel.logoUrl.take(1000),
                        "category" to channel.category.take(50),
                        "isFavorite" to isFavorite,
                        "updatedAt" to FieldValue.serverTimestamp(),
                    )
                ).await()
            }
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.WRITE, docRef.path)
            throw e
        }
    }

    // -------------------------------------------------------------------------
    // 5. OTT VOD Catalog & Episodes (Query-Aligned with firestore.rules)
    // -------------------------------------------------------------------------
    fun observePublishedCatalog(): Flow<List<CatalogItem>> {
        val path = "catalog_items"
        return db.collection(path)
            .whereEqualTo("publicationStatus", "PUBLISHED")
            .snapshots()
            .map { snap ->
                snap.toObjects(CatalogItem::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                    .sortedByDescending { it.createdAt ?: Timestamp(0, 0) }
            }
            .catch { err ->
                if (err is Exception) handleFirestoreError(err, OperationType.LIST, path)
                throw err
            }
    }

    fun observeOwnerCatalog(ownerId: String): Flow<List<CatalogItem>> {
        val path = "catalog_items"
        return db.collection(path)
            .whereEqualTo("ownerId", ownerId)
            .snapshots()
            .map { snap ->
                snap.toObjects(CatalogItem::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                    .sortedByDescending { it.updatedAt ?: it.createdAt ?: Timestamp(0, 0) }
            }
            .catch { err ->
                if (err is Exception) handleFirestoreError(err, OperationType.LIST, path)
                throw err
            }
    }

    suspend fun getCatalogItemById(itemId: String): Result<CatalogItem?> = runCatching {
        val docRef = db.collection("catalog_items").document(itemId)
        try {
            docRef.get().await().toObject(CatalogItem::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.GET, docRef.path)
            throw e
        }
    }

    suspend fun saveCatalogItem(item: CatalogItem): Result<String> = runCatching {
        val uid = requireUserId()
        if (item.publicationStatus == "PUBLISHED" && item.streamUrl.trim().length < 8) {
            throw IllegalArgumentException("Cannot publish content until upload/processing provides a valid stream URL.")
        }
        val docId = item.id.ifBlank { "vod_${UUID.randomUUID().toString().replace("-", "").take(16)}" }
        val docRef = db.collection("catalog_items").document(docId)
        try {
            val existingSnap = if (item.id.isNotBlank()) docRef.get().await() else null
            val preservedCreated = existingSnap?.getTimestamp("createdAt") ?: item.createdAt
            docRef.set(item.toFirestoreMap(uid, preserveCreatedAt = preservedCreated)).await()
            docId
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, if (item.id.isBlank()) OperationType.CREATE else OperationType.UPDATE, docRef.path)
            throw e
        }
    }

    suspend fun deleteCatalogItem(itemId: String): Result<Unit> = runCatching {
        requireUserId()
        val docRef = db.collection("catalog_items").document(itemId)
        try {
            docRef.delete().await()
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.DELETE, docRef.path)
            throw e
        }
    }

    fun observePublishedEpisodes(seriesId: String): Flow<List<EpisodeItem>> {
        val path = "episodes"
        return db.collection(path)
            .whereEqualTo("publicationStatus", "PUBLISHED")
            .whereEqualTo("seriesId", seriesId)
            .snapshots()
            .map { snap ->
                snap.toObjects(EpisodeItem::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                    .sortedWith(compareBy<EpisodeItem> { it.seasonNumber }.thenBy { it.episodeNumber })
            }
            .catch { err ->
                if (err is Exception) handleFirestoreError(err, OperationType.LIST, path)
                throw err
            }
    }

    fun observeOwnerEpisodes(ownerId: String): Flow<List<EpisodeItem>> {
        val path = "episodes"
        return db.collection(path)
            .whereEqualTo("ownerId", ownerId)
            .snapshots()
            .map { snap ->
                snap.toObjects(EpisodeItem::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                    .sortedWith(compareBy<EpisodeItem>({ it.seriesId }, { it.seasonNumber }, { it.episodeNumber }))
            }
            .catch { err ->
                if (err is Exception) handleFirestoreError(err, OperationType.LIST, path)
                throw err
            }
    }

    suspend fun saveEpisode(episode: EpisodeItem): Result<String> = runCatching {
        val uid = requireUserId()
        if (episode.publicationStatus == "PUBLISHED" && episode.streamUrl.trim().length < 8) {
            throw IllegalArgumentException("Episode stream URL is required before publishing.")
        }
        val docId = episode.id.ifBlank { "ep_${UUID.randomUUID().toString().replace("-", "").take(16)}" }
        val docRef = db.collection("episodes").document(docId)
        try {
            val existingSnap = if (episode.id.isNotBlank()) docRef.get().await() else null
            val preservedCreated = existingSnap?.getTimestamp("createdAt") ?: episode.createdAt
            docRef.set(episode.toFirestoreMap(uid, preserveCreatedAt = preservedCreated)).await()
            docId
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, if (episode.id.isBlank()) OperationType.CREATE else OperationType.UPDATE, docRef.path)
            throw e
        }
    }

    suspend fun deleteEpisode(episodeId: String): Result<Unit> = runCatching {
        requireUserId()
        val docRef = db.collection("episodes").document(episodeId)
        try {
            docRef.delete().await()
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.DELETE, docRef.path)
            throw e
        }
    }

    // -------------------------------------------------------------------------
    // 6. Live TV Channels & EPG Schedules
    // -------------------------------------------------------------------------
    fun observePublishedChannels(): Flow<List<TvChannel>> {
        val path = "tv_channels"
        return db.collection(path)
            .whereEqualTo("publicationStatus", "PUBLISHED")
            .snapshots()
            .map { snap ->
                snap.toObjects(TvChannel::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                    .sortedWith(compareByDescending<TvChannel> { it.isFeatured }.thenBy { it.name })
            }
            .catch { err ->
                if (err is Exception) handleFirestoreError(err, OperationType.LIST, path)
                throw err
            }
    }

    fun observeOwnerChannels(ownerId: String): Flow<List<TvChannel>> {
        val path = "tv_channels"
        return db.collection(path)
            .whereEqualTo("ownerId", ownerId)
            .snapshots()
            .map { snap ->
                snap.toObjects(TvChannel::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                    .sortedBy { it.name }
            }
            .catch { err ->
                if (err is Exception) handleFirestoreError(err, OperationType.LIST, path)
                throw err
            }
    }

    suspend fun saveTvChannel(channel: TvChannel): Result<String> = runCatching {
        val uid = requireUserId()
        if (channel.publicationStatus == "PUBLISHED" && channel.streamUrl.trim().length < 8) {
            throw IllegalArgumentException("Authorized stream URL is required to publish a Live TV channel.")
        }
        val docId = channel.id.ifBlank { "ch_${UUID.randomUUID().toString().replace("-", "").take(16)}" }
        val docRef = db.collection("tv_channels").document(docId)
        try {
            val existingSnap = if (channel.id.isNotBlank()) docRef.get().await() else null
            val preservedCreated = existingSnap?.getTimestamp("createdAt") ?: channel.createdAt
            docRef.set(channel.toFirestoreMap(uid, preserveCreatedAt = preservedCreated)).await()
            docId
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, if (channel.id.isBlank()) OperationType.CREATE else OperationType.UPDATE, docRef.path)
            throw e
        }
    }

    suspend fun deleteTvChannel(channelId: String): Result<Unit> = runCatching {
        requireUserId()
        val docRef = db.collection("tv_channels").document(channelId)
        try {
            docRef.delete().await()
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.DELETE, docRef.path)
            throw e
        }
    }

    fun observePublishedEpg(channelId: String): Flow<List<EpgProgram>> {
        val path = "epg_programs"
        return db.collection(path)
            .whereEqualTo("publicationStatus", "PUBLISHED")
            .whereEqualTo("channelId", channelId)
            .snapshots()
            .map { snap ->
                snap.toObjects(EpgProgram::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                    .sortedBy { it.startTimeLabel }
            }
            .catch { err ->
                if (err is Exception) handleFirestoreError(err, OperationType.LIST, path)
                throw err
            }
    }

    fun observeOwnerEpg(ownerId: String): Flow<List<EpgProgram>> {
        val path = "epg_programs"
        return db.collection(path)
            .whereEqualTo("ownerId", ownerId)
            .snapshots()
            .map { snap ->
                snap.toObjects(EpgProgram::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                    .sortedWith(compareBy<EpgProgram> { it.channelName }.thenBy { it.startTimeLabel })
            }
            .catch { err ->
                if (err is Exception) handleFirestoreError(err, OperationType.LIST, path)
                throw err
            }
    }

    suspend fun saveEpgProgram(program: EpgProgram): Result<String> = runCatching {
        val uid = requireUserId()
        val docId = program.id.ifBlank { "epg_${UUID.randomUUID().toString().replace("-", "").take(16)}" }
        val docRef = db.collection("epg_programs").document(docId)
        try {
            val existingSnap = if (program.id.isNotBlank()) docRef.get().await() else null
            val preservedCreated = existingSnap?.getTimestamp("createdAt") ?: program.createdAt
            docRef.set(program.toFirestoreMap(uid, preserveCreatedAt = preservedCreated)).await()
            docId
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, if (program.id.isBlank()) OperationType.CREATE else OperationType.UPDATE, docRef.path)
            throw e
        }
    }

    suspend fun deleteEpgProgram(programId: String): Result<Unit> = runCatching {
        requireUserId()
        val docRef = db.collection("epg_programs").document(programId)
        try {
            docRef.delete().await()
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.DELETE, docRef.path)
            throw e
        }
    }

    // -------------------------------------------------------------------------
    // 7. Likes & Comments
    // -------------------------------------------------------------------------
    fun observeLikesForContent(contentId: String): Flow<List<ContentLike>> {
        val path = "likes"
        return db.collection(path)
            .whereEqualTo("visibility", "PUBLIC")
            .whereEqualTo("contentId", contentId)
            .snapshots()
            .map { snap -> snap.toObjects(ContentLike::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE) }
            .catch { err ->
                if (err is Exception) handleFirestoreError(err, OperationType.LIST, path)
                throw err
            }
    }

    suspend fun toggleLike(contentId: String, currentlyLiked: Boolean): Result<Unit> = runCatching {
        val uid = requireUserId()
        val likeId = "${uid}_$contentId"
        val docRef = db.collection("likes").document(likeId)
        val itemRef = db.collection("catalog_items").document(contentId)
        try {
            if (currentlyLiked) {
                docRef.delete().await()
                runCatching {
                    itemRef.update(
                        mapOf(
                            "likesCount" to FieldValue.increment(-1L),
                            "updatedAt" to FieldValue.serverTimestamp(),
                        )
                    ).await()
                }
            } else {
                docRef.set(
                    mapOf(
                        "contentId" to contentId,
                        "userId" to uid,
                        "visibility" to "PUBLIC",
                        "createdAt" to FieldValue.serverTimestamp(),
                    )
                ).await()
                runCatching {
                    itemRef.update(
                        mapOf(
                            "likesCount" to FieldValue.increment(1L),
                            "updatedAt" to FieldValue.serverTimestamp(),
                        )
                    ).await()
                }
            }
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, if (currentlyLiked) OperationType.DELETE else OperationType.CREATE, docRef.path)
            throw e
        }
    }

    fun observeCommentsForContent(contentId: String): Flow<List<ContentComment>> {
        val path = "comments"
        return db.collection(path)
            .whereEqualTo("visibility", "PUBLIC")
            .whereEqualTo("contentId", contentId)
            .snapshots()
            .map { snap ->
                snap.toObjects(ContentComment::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                    .sortedByDescending { it.createdAt ?: Timestamp(0, 0) }
            }
            .catch { err ->
                if (err is Exception) handleFirestoreError(err, OperationType.LIST, path)
                throw err
            }
    }

    suspend fun addComment(contentId: String, authorName: String, text: String): Result<String> = runCatching {
        val uid = requireUserId()
        val trimmed = text.trim()
        require(trimmed.isNotEmpty()) { "Comment cannot be empty" }
        val commentId = "cmt_${UUID.randomUUID().toString().replace("-", "").take(16)}"
        val docRef = db.collection("comments").document(commentId)
        try {
            docRef.set(
                mapOf(
                    "contentId" to contentId,
                    "userId" to uid,
                    "authorName" to authorName.ifBlank { "Viewer" }.take(80),
                    "text" to trimmed.take(1000),
                    "visibility" to "PUBLIC",
                    "createdAt" to FieldValue.serverTimestamp(),
                    "updatedAt" to FieldValue.serverTimestamp(),
                )
            ).await()
            commentId
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.CREATE, docRef.path)
            throw e
        }
    }

    suspend fun deleteComment(commentId: String): Result<Unit> = runCatching {
        requireUserId()
        val docRef = db.collection("comments").document(commentId)
        try {
            docRef.delete().await()
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.DELETE, docRef.path)
            throw e
        }
    }

    // -------------------------------------------------------------------------
    // 8. Playback Telemetry & Real Analytics Aggregation
    // -------------------------------------------------------------------------
    suspend fun recordPlaybackSession(
        contentId: String,
        contentTitle: String,
        contentType: String,
        category: String,
        watchedSeconds: Long,
        completed: Boolean,
        isLiveChannel: Boolean = false,
    ): Result<Unit> = runCatching {
        val uid = requireUserId()
        val eventId = "evt_${UUID.randomUUID().toString().replace("-", "").take(18)}"
        val dateStr = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date())
        val docRef = db.collection("playback_events").document(eventId)
        try {
            docRef.set(
                mapOf(
                    "userId" to uid,
                    "contentId" to contentId,
                    "contentTitle" to contentTitle.take(200),
                    "contentType" to contentType.take(32),
                    "category" to category.ifBlank { "General" }.take(60),
                    "watchedSeconds" to watchedSeconds.coerceIn(0L, 86400L),
                    "completed" to completed,
                    "eventDate" to dateStr,
                    "createdAt" to FieldValue.serverTimestamp(),
                )
            ).await()

            if (isLiveChannel) {
                runCatching {
                    db.collection("tv_channels").document(contentId).update(
                        mapOf(
                            "viewsCount" to FieldValue.increment(1L),
                            "watchTimeMinutes" to FieldValue.increment((watchedSeconds / 60L).coerceIn(1L, 720L)),
                            "updatedAt" to FieldValue.serverTimestamp(),
                        )
                    ).await()
                }
            } else {
                runCatching {
                    db.collection("catalog_items").document(contentId).update(
                        mapOf(
                            "viewsCount" to FieldValue.increment(1L),
                            "updatedAt" to FieldValue.serverTimestamp(),
                        )
                    ).await()
                }
            }
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.CREATE, docRef.path)
            throw e
        }
    }

    suspend fun loadOwnerAnalytics(ownerId: String): Result<AnalyticsSummary> = runCatching {
        requireUserId()
        try {
            val catalog = db.collection("catalog_items").whereEqualTo("ownerId", ownerId).get().await()
                .toObjects(CatalogItem::class.java)
            val channels = db.collection("tv_channels").whereEqualTo("ownerId", ownerId).get().await()
                .toObjects(TvChannel::class.java)
            val likesCount = db.collection("likes").whereEqualTo("visibility", "PUBLIC").get().await().size()
            val commentsCount = db.collection("comments").whereEqualTo("visibility", "PUBLIC").get().await().size()

            // Strictly owner-only playback_events list query enforced by isVerifiedOwnerToken()
            val events = runCatching {
                db.collection("playback_events").get().await().toObjects(PlaybackAnalyticsEvent::class.java)
            }.getOrDefault(emptyList())

            val totalEventViews = events.size.toLong()
            val catalogViews = catalog.sumOf { it.viewsCount }
            val channelViews = channels.sumOf { it.viewsCount }
            val totalViews = maxOf(totalEventViews, catalogViews + channelViews)
            val uniqueViewers = events.map { it.userId }.distinct().size
            val totalWatchedSecs = events.sumOf { it.watchedSeconds }
            val avgSeconds = if (events.isNotEmpty()) totalWatchedSecs / events.size else 0L
            val completedCount = events.count { it.completed }
            val completionPct = if (events.isNotEmpty()) ((completedCount * 100.0) / events.size).toInt() else 0

            val topVideos = events.groupBy { it.contentTitle }
                .mapValues { (_, list) -> list.size.toLong() }
                .entries
                .sortedByDescending { it.value }
                .take(8)
                .map { it.key to it.value }

            val dateWise = events.groupingBy { it.eventDate }.eachCount()
            val categoryWise = events.groupingBy { it.category }.eachCount()

            AnalyticsSummary(
                totalViews = totalViews,
                uniqueViewers = uniqueViewers,
                totalWatchTimeMinutes = (totalWatchedSecs / 60L) + channels.sumOf { it.watchTimeMinutes },
                averageWatchSeconds = avgSeconds,
                completionRatePercent = completionPct,
                totalLikes = maxOf(likesCount, catalog.sumOf { it.likesCount }.toInt()),
                totalComments = commentsCount,
                topVideos = topVideos,
                popularMovies = catalog.filter { it.contentType == "MOVIE" }.sortedByDescending { it.viewsCount }.take(5),
                popularSeries = catalog.filter { it.contentType == "SERIES" }.sortedByDescending { it.viewsCount }.take(5),
                channelStats = channels.sortedByDescending { it.viewsCount },
                dateWiseViews = dateWise,
                categoryWiseViews = categoryWise,
            )
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.LIST, "playback_events")
            throw e
        }
    }

    // -------------------------------------------------------------------------
    // 9. Upload Jobs & Permanent Cloud Storage Config (Owner Only)
    // -------------------------------------------------------------------------
    fun observeOwnerUploadJobs(ownerId: String): Flow<List<UploadJob>> {
        val path = "upload_jobs"
        return db.collection(path)
            .whereEqualTo("ownerId", ownerId)
            .snapshots()
            .map { snap ->
                snap.toObjects(UploadJob::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                    .sortedByDescending { it.updatedAt ?: it.createdAt ?: Timestamp(0, 0) }
            }
            .catch { err ->
                if (err is Exception) handleFirestoreError(err, OperationType.LIST, path)
                throw err
            }
    }

    suspend fun saveUploadJob(job: UploadJob): Result<String> = runCatching {
        val uid = requireUserId()
        val docId = job.id.ifBlank { "upl_${UUID.randomUUID().toString().replace("-", "").take(16)}" }
        val docRef = db.collection("upload_jobs").document(docId)
        try {
            val existingSnap = if (job.id.isNotBlank()) docRef.get().await() else null
            val preservedCreated = existingSnap?.getTimestamp("createdAt") ?: job.createdAt
            docRef.set(job.toFirestoreMap(uid, preserveCreatedAt = preservedCreated)).await()
            docId
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, if (job.id.isBlank()) OperationType.CREATE else OperationType.UPDATE, docRef.path)
            throw e
        }
    }

    suspend fun deleteUploadJob(jobId: String): Result<Unit> = runCatching {
        requireUserId()
        val docRef = db.collection("upload_jobs").document(jobId)
        try {
            docRef.delete().await()
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.DELETE, docRef.path)
            throw e
        }
    }

    fun observeBrandingConfig(): Flow<PlatformConfig?> {
        val path = "platform_config/branding"
        return db.collection("platform_config").document("branding")
            .snapshots()
            .map { snap ->
                if (snap.exists()) snap.toObject(PlatformConfig::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                else null
            }
            .catch { err ->
                if (err is Exception) handleFirestoreError(err, OperationType.GET, path)
                throw err
            }
    }

    suspend fun getStorageConfig(): Result<PlatformConfig?> = runCatching {
        requireUserId()
        val docRef = db.collection("platform_config").document("storage")
        try {
            val snap = docRef.get().await()
            if (snap.exists()) snap.toObject(PlatformConfig::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
            else null
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.GET, docRef.path)
            throw e
        }
    }

    suspend fun savePlatformConfig(configId: String, config: PlatformConfig): Result<Unit> = runCatching {
        val uid = requireUserId()
        val docRef = db.collection("platform_config").document(configId)
        try {
            val payload = mapOf(
                "configType" to config.configType,
                "brandName" to config.brandName.take(80),
                "tagline" to config.tagline.take(160),
                "customLogoUrl" to config.customLogoUrl.take(1500),
                "watermarkEnabled" to config.watermarkEnabled,
                "storageProvider" to config.storageProvider.take(100),
                "masterBucketName" to config.masterBucketName.take(200),
                "cdnBaseUrl" to config.cdnBaseUrl.take(500),
                "signedUploadEndpoint" to config.signedUploadEndpoint.take(500),
                "backupReplicationEnabled" to config.backupReplicationEnabled,
                "systemHealthy" to config.systemHealthy,
                "statusMessage" to config.statusMessage.take(300),
                "ownerId" to uid,
                "updatedAt" to FieldValue.serverTimestamp(),
            )
            docRef.set(payload).await()
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.WRITE, docRef.path)
            throw e
        }
    }

    // -------------------------------------------------------------------------
    // 10. Owner-Initiated Open-License Test Catalog Initialization
    // Uses ONLY Creative Commons (CC-BY) Blender Foundation / W3C / Mux open-license
    // HLS & MP4 streams for verified owner playback testing — zero unlicensed content.
    // -------------------------------------------------------------------------
    suspend fun initializeOpenLicensedCatalogForOwner(): Result<Int> = runCatching {
        val uid = requireUserId()
        var createdCount = 0

        val starterItems = listOf(
            CatalogItem(
                id = "hx_tears_of_steel",
                title = "Tears of Steel (4K Open Cinema)",
                description = "Licensed under Creative Commons Attribution 3.0 (Blender Foundation). In a cyberpunk Amsterdam, a group of warriors and scientists attempt to save the world from destructive robots.",
                contentType = "MOVIE",
                genre = "Sci-Fi • Action • Thriller",
                tags = listOf("Sci-Fi", "Action", "4K", "CC-BY"),
                language = "English",
                releaseYear = 2012L,
                durationMinutes = 12L,
                ageRating = "U/A 13+",
                posterUrl = "https://mango.blender.org/wp-content/uploads/2013/05/01_thom_celia_bridge.jpg",
                bannerUrl = "https://mango.blender.org/wp-content/uploads/2013/05/01_thom_celia_bridge.jpg",
                trailerUrl = "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/TearsOfSteel.mp4",
                streamUrl = "https://test-streams.mux.dev/x36xhzz/x36xhzz.m3u8",
                streamFormat = "HLS",
                castCrew = listOf("Derek de Lint", " Sergio Hasselbaink", "Ian Hubert (Director)"),
                isFeaturedHero = true,
                isTrending = true,
                isPopular = true,
                seasonsCount = 0L,
                publicationStatus = "PUBLISHED",
                ownerId = uid,
            ),
            CatalogItem(
                id = "hx_sintel_chronicles",
                title = "Sintel: Dragon Quest",
                description = "Licensed under Creative Commons Attribution 3.0 (Blender Institute). A lone warrior travels across perilous lands searching for Scales, a baby dragon she befriended.",
                contentType = "MOVIE",
                genre = "Fantasy • Adventure • Drama",
                tags = listOf("Fantasy", "Adventure", "CC-BY"),
                language = "English",
                releaseYear = 2010L,
                durationMinutes = 15L,
                ageRating = "U/A 13+",
                posterUrl = "https://durian.blender.org/wp-content/uploads/2010/06/05.8b_comp_000272.jpg",
                bannerUrl = "https://durian.blender.org/wp-content/uploads/2010/06/05.8b_comp_000272.jpg",
                trailerUrl = "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/Sintel.mp4",
                streamUrl = "https://bitdash-a.akamaihd.net/content/sintel/hls/playlist.m3u8",
                streamFormat = "HLS",
                castCrew = listOf("Halina Reijn", "Thom Hoffman", "Colin Levy (Director)"),
                isFeaturedHero = false,
                isTrending = true,
                isPopular = true,
                seasonsCount = 0L,
                publicationStatus = "PUBLISHED",
                ownerId = uid,
            ),
            CatalogItem(
                id = "hx_cosmos_laundromat_series",
                title = "Cosmos Laundromat: Open Series",
                description = "Creative Commons CC-BY open series by Blender Studio following Franck across surreal multiverse worlds.",
                contentType = "SERIES",
                genre = "Sci-Fi • Drama • Comedy",
                tags = listOf("Series", "Multiverse", "CC-BY"),
                language = "English",
                releaseYear = 2015L,
                durationMinutes = 12L,
                ageRating = "U/A 13+",
                posterUrl = "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/images/BigBuckBunny.jpg",
                bannerUrl = "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/images/ElephantsDream.jpg",
                streamUrl = "https://test-streams.mux.dev/x36xhzz/x36xhzz.m3u8",
                streamFormat = "HLS",
                castCrew = listOf("Pierre Bokma", "Reinout Scholten van Aschat", "Mathieu Auvray"),
                isFeaturedHero = false,
                isTrending = true,
                isPopular = true,
                seasonsCount = 2L,
                publicationStatus = "PUBLISHED",
                ownerId = uid,
            ),
            CatalogItem(
                id = "hx_elephants_dream_short",
                title = "Elephants Dream",
                description = "World's first open movie licensed under Creative Commons (Orange Open Movie Project).",
                contentType = "SHORT_FILM",
                genre = "Surreal • Sci-Fi",
                tags = listOf("Short Film", "Open Movie"),
                language = "English",
                releaseYear = 2006L,
                durationMinutes = 11L,
                ageRating = "U",
                posterUrl = "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/images/ElephantsDream.jpg",
                bannerUrl = "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/images/ElephantsDream.jpg",
                streamUrl = "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ElephantsDream.mp4",
                streamFormat = "MP4",
                castCrew = listOf("Tygo Gernandt", "Cas Jansen", "Bassam Kurdali"),
                isFeaturedHero = false,
                isTrending = false,
                isPopular = true,
                seasonsCount = 0L,
                publicationStatus = "PUBLISHED",
                ownerId = uid,
            ),
            CatalogItem(
                id = "hx_open_tech_doc",
                title = "Adaptive Streaming Engineering",
                description = "Authorized educational overview of HLS and DASH adaptive bitrate delivery for global OTT networks.",
                contentType = "EDUCATIONAL",
                genre = "Technology • Documentary",
                tags = listOf("HLS", "Engineering", "OTT"),
                language = "English",
                releaseYear = 2026L,
                durationMinutes = 10L,
                ageRating = "U",
                posterUrl = "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/images/ForBiggerBlazes.jpg",
                bannerUrl = "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/images/ForBiggerEscapes.jpg",
                streamUrl = "https://test-streams.mux.dev/x36xhzz/x36xhzz.m3u8",
                streamFormat = "HLS",
                castCrew = listOf("HUNTXPROS Engineering Team"),
                isFeaturedHero = false,
                isTrending = false,
                isPopular = false,
                seasonsCount = 0L,
                publicationStatus = "PUBLISHED",
                ownerId = uid,
            ),
        )

        for (item in starterItems) {
            saveCatalogItem(item).getOrThrow()
            createdCount++
        }

        val starterEpisodes = listOf(
            EpisodeItem(
                id = "ep_cosmos_s1e1",
                seriesId = "hx_cosmos_laundromat_series",
                seasonNumber = 1L,
                episodeNumber = 1L,
                title = "First Cycle",
                description = "Franck meets Victor on a windswept island and discovers a portal to infinite worlds.",
                thumbnailUrl = "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/images/BigBuckBunny.jpg",
                durationMinutes = 12L,
                streamUrl = "https://test-streams.mux.dev/x36xhzz/x36xhzz.m3u8",
                streamFormat = "HLS",
                publicationStatus = "PUBLISHED",
                ownerId = uid,
            ),
            EpisodeItem(
                id = "ep_cosmos_s1e2",
                seriesId = "hx_cosmos_laundromat_series",
                seasonNumber = 1L,
                episodeNumber = 2L,
                title = "Machine Awakening",
                description = "Journey into the surreal machine world in Season 1 Episode 2.",
                thumbnailUrl = "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/images/ElephantsDream.jpg",
                durationMinutes = 11L,
                streamUrl = "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ElephantsDream.mp4",
                streamFormat = "MP4",
                publicationStatus = "PUBLISHED",
                ownerId = uid,
            ),
            EpisodeItem(
                id = "ep_cosmos_s2e1",
                seriesId = "hx_cosmos_laundromat_series",
                seasonNumber = 2L,
                episodeNumber = 1L,
                title = "New Horizon (Season 2 Premiere)",
                description = "Season 2 opens with high-bitrate adaptive HLS test playback.",
                thumbnailUrl = "https://durian.blender.org/wp-content/uploads/2010/06/05.8b_comp_000272.jpg",
                durationMinutes = 15L,
                streamUrl = "https://bitdash-a.akamaihd.net/content/sintel/hls/playlist.m3u8",
                streamFormat = "HLS",
                publicationStatus = "PUBLISHED",
                ownerId = uid,
            ),
        )

        for (ep in starterEpisodes) {
            saveEpisode(ep).getOrThrow()
        }

        // Authorized Open-Test HLS Live Channels (Strictly official HLS test streams, never fake third-party commercial feeds)
        val starterChannels = listOf(
            TvChannel(
                id = "ch_huntxpros_cinema_hls",
                name = "HUNTXPROS Open Cinema HD (Test Stream)",
                logoUrl = "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/images/BigBuckBunny.jpg",
                description = "Official HUNTXPROS authorized HLS adaptive test broadcast using CC-BY open cinema feed.",
                category = "MOVIES",
                language = "English",
                streamUrl = "https://test-streams.mux.dev/x36xhzz/x36xhzz.m3u8",
                streamFormat = "HLS",
                currentProgramTitle = "Open Cinema Showcase (CC-BY)",
                currentProgramTime = "LIVE • 24/7 Test Feed",
                upcomingProgramTitle = "Sintel Remastered Showcase",
                upcomingProgramTime = "Next • Top of the Hour",
                isFeatured = true,
                isLive = true,
                publicationStatus = "PUBLISHED",
                ownerId = uid,
            ),
            TvChannel(
                id = "ch_huntxpros_scifi_hls",
                name = "HUNTXPROS Sci-Fi & Tech TV (Test Stream)",
                logoUrl = "https://durian.blender.org/wp-content/uploads/2010/06/05.8b_comp_000272.jpg",
                description = "Authorized multi-bitrate HLS verification channel for adaptive mobile streaming tests.",
                category = "ENTERTAINMENT",
                language = "English",
                streamUrl = "https://bitdash-a.akamaihd.net/content/sintel/hls/playlist.m3u8",
                streamFormat = "HLS",
                currentProgramTitle = "Sintel Adaptive Bitrate Feed",
                currentProgramTime = "LIVE • Multi-Audio / Subtitle Test",
                upcomingProgramTitle = "Open Studio Behind the Scenes",
                upcomingProgramTime = "Upcoming • +30 Min",
                isFeatured = true,
                isLive = true,
                publicationStatus = "PUBLISHED",
                ownerId = uid,
            ),
        )

        for (ch in starterChannels) {
            saveTvChannel(ch).getOrThrow()
        }

        saveEpgProgram(
            EpgProgram(
                id = "epg_cinema_1",
                channelId = "ch_huntxpros_cinema_hls",
                channelName = "HUNTXPROS Open Cinema HD (Test Stream)",
                programTitle = "Open Cinema Showcase (CC-BY)",
                synopsis = "Continuous adaptive HLS stream verifying 360p-1080p ABR switching.",
                category = "MOVIES",
                startTimeLabel = "00:00",
                endTimeLabel = "12:00",
                isLiveNow = true,
                publicationStatus = "PUBLISHED",
                ownerId = uid,
            )
        ).getOrThrow()

        saveEpgProgram(
            EpgProgram(
                id = "epg_cinema_2",
                channelId = "ch_huntxpros_cinema_hls",
                channelName = "HUNTXPROS Open Cinema HD (Test Stream)",
                programTitle = "Sintel Remastered Showcase",
                synopsis = "Open-source animated epic with multi-track subtitle verification.",
                category = "MOVIES",
                startTimeLabel = "12:00",
                endTimeLabel = "23:59",
                isLiveNow = false,
                publicationStatus = "PUBLISHED",
                ownerId = uid,
            )
        ).getOrThrow()

        createdCount
    }

    // -------------------------------------------------------------------------
    // 11. Immutable Disaster Recovery Snapshots (Strictly Owner-Only)
    // -------------------------------------------------------------------------
    fun observeBackupSnapshots(ownerId: String): Flow<List<BackupSnapshot>> {
        val path = "backup_snapshots"
        return db.collection(path)
            .whereEqualTo("ownerId", ownerId)
            .snapshots()
            .map { snap ->
                snap.toObjects(BackupSnapshot::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                    .sortedByDescending { it.createdAt ?: Timestamp(0, 0) }
            }
            .catch { err ->
                if (err is Exception) handleFirestoreError(err, OperationType.LIST, path)
                throw err
            }
    }

    suspend fun createBackupSnapshot(label: String): Result<String> = runCatching {
        val uid = requireUserId()
        val snapId = "snap_${UUID.randomUUID().toString().replace("-", "").take(16)}"
        val docRef = db.collection("backup_snapshots").document(snapId)
        try {
            val catalog = db.collection("catalog_items").whereEqualTo("ownerId", uid).get().await()
                .toObjects(CatalogItem::class.java)
            val episodes = db.collection("episodes").whereEqualTo("ownerId", uid).get().await()
                .toObjects(EpisodeItem::class.java)
            val channels = db.collection("tv_channels").whereEqualTo("ownerId", uid).get().await()
                .toObjects(TvChannel::class.java)
            val epg = db.collection("epg_programs").whereEqualTo("ownerId", uid).get().await()
                .toObjects(EpgProgram::class.java)

            val root = JSONObject().apply {
                put(
                    "catalog",
                    JSONArray().apply {
                        catalog.forEach { item ->
                            put(
                                JSONObject().apply {
                                    put("id", item.id)
                                    put("title", item.title)
                                    put("description", item.description.take(1200))
                                    put("contentType", item.contentType)
                                    put("genre", item.genre)
                                    put("language", item.language)
                                    put("releaseYear", item.releaseYear)
                                    put("durationMinutes", item.durationMinutes)
                                    put("ageRating", item.ageRating)
                                    put("posterUrl", item.posterUrl)
                                    put("bannerUrl", item.bannerUrl)
                                    put("trailerUrl", item.trailerUrl.orEmpty())
                                    put("streamUrl", item.streamUrl)
                                    put("streamFormat", item.streamFormat)
                                    put("isFeaturedHero", item.isFeaturedHero)
                                    put("isTrending", item.isTrending)
                                    put("isPopular", item.isPopular)
                                    put("seasonsCount", item.seasonsCount)
                                    put("publicationStatus", item.publicationStatus)
                                    put("storageObjectKey", item.storageObjectKey.orEmpty())
                                    put("masterChecksumSha256", item.masterChecksumSha256.orEmpty())
                                }
                            )
                        }
                    }
                )
                put(
                    "episodes",
                    JSONArray().apply {
                        episodes.forEach { ep ->
                            put(
                                JSONObject().apply {
                                    put("id", ep.id)
                                    put("seriesId", ep.seriesId)
                                    put("seasonNumber", ep.seasonNumber)
                                    put("episodeNumber", ep.episodeNumber)
                                    put("title", ep.title)
                                    put("description", ep.description.take(800))
                                    put("thumbnailUrl", ep.thumbnailUrl)
                                    put("durationMinutes", ep.durationMinutes)
                                    put("streamUrl", ep.streamUrl)
                                    put("streamFormat", ep.streamFormat)
                                    put("publicationStatus", ep.publicationStatus)
                                }
                            )
                        }
                    }
                )
                put(
                    "channels",
                    JSONArray().apply {
                        channels.forEach { ch ->
                            put(
                                JSONObject().apply {
                                    put("id", ch.id)
                                    put("name", ch.name)
                                    put("logoUrl", ch.logoUrl)
                                    put("description", ch.description.take(800))
                                    put("category", ch.category)
                                    put("language", ch.language)
                                    put("streamUrl", ch.streamUrl)
                                    put("streamFormat", ch.streamFormat)
                                    put("currentProgramTitle", ch.currentProgramTitle)
                                    put("currentProgramTime", ch.currentProgramTime)
                                    put("upcomingProgramTitle", ch.upcomingProgramTitle)
                                    put("upcomingProgramTime", ch.upcomingProgramTime)
                                    put("isFeatured", ch.isFeatured)
                                    put("isLive", ch.isLive)
                                    put("publicationStatus", ch.publicationStatus)
                                }
                            )
                        }
                    }
                )
                put(
                    "epg",
                    JSONArray().apply {
                        epg.forEach { p ->
                            put(
                                JSONObject().apply {
                                    put("id", p.id)
                                    put("channelId", p.channelId)
                                    put("channelName", p.channelName)
                                    put("programTitle", p.programTitle)
                                    put("synopsis", p.synopsis.take(400))
                                    put("category", p.category)
                                    put("startTimeLabel", p.startTimeLabel)
                                    put("endTimeLabel", p.endTimeLabel)
                                    put("isLiveNow", p.isLiveNow)
                                    put("publicationStatus", p.publicationStatus)
                                }
                            )
                        }
                    }
                )
            }

            val serialized = root.toString().take(850_000)
            val safeLabel = label.trim().ifBlank {
                "Recovery Point " + SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.US).format(Date())
            }.take(160)

            val payload = mapOf(
                "label" to safeLabel,
                "catalogCount" to catalog.size.toLong(),
                "episodesCount" to episodes.size.toLong(),
                "channelsCount" to channels.size.toLong(),
                "epgCount" to epg.size.toLong(),
                "payloadJson" to serialized,
                "ownerId" to uid,
                "createdAt" to FieldValue.serverTimestamp(),
            )
            docRef.set(payload).await()
            snapId
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.CREATE, docRef.path)
            throw e
        }
    }

    suspend fun restoreFromBackupSnapshot(snapshot: BackupSnapshot): Result<Int> = runCatching {
        val uid = requireUserId()
        var restoredDocs = 0
        val root = JSONObject(snapshot.payloadJson)

        val catalogArr = root.optJSONArray("catalog") ?: JSONArray()
        for (i in 0 until catalogArr.length()) {
            val obj = catalogArr.getJSONObject(i)
            val item = CatalogItem(
                id = obj.optString("id"),
                title = obj.optString("title"),
                description = obj.optString("description", "Restored item"),
                contentType = obj.optString("contentType", "MOVIE"),
                genre = obj.optString("genre", "Action"),
                language = obj.optString("language", "English"),
                releaseYear = obj.optLong("releaseYear", 2026L),
                durationMinutes = obj.optLong("durationMinutes", 60L),
                ageRating = obj.optString("ageRating", "U/A 13+"),
                posterUrl = obj.optString("posterUrl"),
                bannerUrl = obj.optString("bannerUrl"),
                trailerUrl = obj.optString("trailerUrl").takeIf { it.isNotBlank() },
                streamUrl = obj.optString("streamUrl"),
                streamFormat = obj.optString("streamFormat", "HLS"),
                isFeaturedHero = obj.optBoolean("isFeaturedHero", false),
                isTrending = obj.optBoolean("isTrending", false),
                isPopular = obj.optBoolean("isPopular", false),
                seasonsCount = obj.optLong("seasonsCount", 0L),
                publicationStatus = obj.optString("publicationStatus", "DRAFT"),
                storageObjectKey = obj.optString("storageObjectKey").takeIf { it.isNotBlank() },
                masterChecksumSha256 = obj.optString("masterChecksumSha256").takeIf { it.isNotBlank() },
                ownerId = uid,
            )
            saveCatalogItem(item).getOrThrow()
            restoredDocs++
        }

        val episodesArr = root.optJSONArray("episodes") ?: JSONArray()
        for (i in 0 until episodesArr.length()) {
            val obj = episodesArr.getJSONObject(i)
            val ep = EpisodeItem(
                id = obj.optString("id"),
                seriesId = obj.optString("seriesId"),
                seasonNumber = obj.optLong("seasonNumber", 1L),
                episodeNumber = obj.optLong("episodeNumber", 1L),
                title = obj.optString("title"),
                description = obj.optString("description", "Restored episode"),
                thumbnailUrl = obj.optString("thumbnailUrl"),
                durationMinutes = obj.optLong("durationMinutes", 45L),
                streamUrl = obj.optString("streamUrl"),
                streamFormat = obj.optString("streamFormat", "HLS"),
                publicationStatus = obj.optString("publicationStatus", "DRAFT"),
                ownerId = uid,
            )
            saveEpisode(ep).getOrThrow()
            restoredDocs++
        }

        val channelsArr = root.optJSONArray("channels") ?: JSONArray()
        for (i in 0 until channelsArr.length()) {
            val obj = channelsArr.getJSONObject(i)
            val ch = TvChannel(
                id = obj.optString("id"),
                name = obj.optString("name"),
                logoUrl = obj.optString("logoUrl"),
                description = obj.optString("description", "Restored channel"),
                category = obj.optString("category", "ENTERTAINMENT"),
                language = obj.optString("language", "English"),
                streamUrl = obj.optString("streamUrl"),
                streamFormat = obj.optString("streamFormat", "HLS"),
                currentProgramTitle = obj.optString("currentProgramTitle"),
                currentProgramTime = obj.optString("currentProgramTime"),
                upcomingProgramTitle = obj.optString("upcomingProgramTitle"),
                upcomingProgramTime = obj.optString("upcomingProgramTime"),
                isFeatured = obj.optBoolean("isFeatured", false),
                isLive = obj.optBoolean("isLive", true),
                publicationStatus = obj.optString("publicationStatus", "DRAFT"),
                ownerId = uid,
            )
            saveTvChannel(ch).getOrThrow()
            restoredDocs++
        }

        val epgArr = root.optJSONArray("epg") ?: JSONArray()
        for (i in 0 until epgArr.length()) {
            val obj = epgArr.getJSONObject(i)
            val p = EpgProgram(
                id = obj.optString("id"),
                channelId = obj.optString("channelId"),
                channelName = obj.optString("channelName"),
                programTitle = obj.optString("programTitle"),
                synopsis = obj.optString("synopsis"),
                category = obj.optString("category", "LIVE"),
                startTimeLabel = obj.optString("startTimeLabel", "00:00"),
                endTimeLabel = obj.optString("endTimeLabel", "01:00"),
                isLiveNow = obj.optBoolean("isLiveNow", false),
                publicationStatus = obj.optString("publicationStatus", "PUBLISHED"),
                ownerId = uid,
            )
            saveEpgProgram(p).getOrThrow()
            restoredDocs++
        }

        restoredDocs
    }
}
