package com.example.ui.theme

import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import com.example.i18n.LocalStrings
import com.example.i18n.SupportedLanguages
import com.example.i18n.getStringsForLanguage

private val HuntDarkColorScheme = darkColorScheme(
    primary = HuntCrimsonRed,
    onPrimary = HuntPlatinumWhite,
    primaryContainer = HuntCrimsonDark,
    onPrimaryContainer = HuntPlatinumWhite,
    secondary = HuntMetallicSilver,
    onSecondary = HuntObsidianBlack,
    secondaryContainer = HuntElevatedCard,
    onSecondaryContainer = HuntPlatinumWhite,
    tertiary = HuntRoyalGold,
    onTertiary = HuntObsidianBlack,
    background = HuntObsidianBlack,
    onBackground = HuntPlatinumWhite,
    surface = HuntDeepCharcoal,
    onSurface = HuntPlatinumWhite,
    surfaceVariant = HuntSurfaceCard,
    onSurfaceVariant = HuntMetallicSilver,
    outline = HuntBorderSubtle,
)

private val ColorLightRedContainer = androidx.compose.ui.graphics.Color(0xFFFFDAD6)

private val HuntLightColorScheme = lightColorScheme(
    primary = HuntCrimsonRed,
    onPrimary = HuntPlatinumWhite,
    primaryContainer = ColorLightRedContainer,
    onPrimaryContainer = HuntCrimsonDark,
    secondary = HuntDeepCharcoal,
    onSecondary = HuntPlatinumWhite,
    background = HuntLightBackground,
    onBackground = HuntLightOnSurface,
    surface = HuntLightSurface,
    onSurface = HuntLightOnSurface,
    surfaceVariant = HuntLightSurfaceVariant,
    onSurfaceVariant = HuntDeepCharcoal,
    outline = HuntMutedSilver,
)

val HuntShapes = Shapes(
    extraSmall = RoundedCornerShape(6.dp),
    small = RoundedCornerShape(10.dp),
    medium = RoundedCornerShape(14.dp),
    large = RoundedCornerShape(20.dp),
    extraLarge = RoundedCornerShape(28.dp),
)

@Composable
fun HuntXProsTheme(
    darkTheme: Boolean = true,
    languageCode: String = "en",
    content: @Composable () -> Unit,
) {
    val colorScheme = if (darkTheme) HuntDarkColorScheme else HuntLightColorScheme
    val isRtl = SupportedLanguages.firstOrNull { it.code == languageCode }?.isRtl == true
    val layoutDirection = if (isRtl) LayoutDirection.Rtl else LayoutDirection.Ltr
    val strings = getStringsForLanguage(languageCode)

    CompositionLocalProvider(
        LocalLayoutDirection provides layoutDirection,
        LocalStrings provides strings,
    ) {
        MaterialTheme(
            colorScheme = colorScheme,
            typography = Typography,
            shapes = HuntShapes,
            content = content,
        )
    }
}

// Keep alias for any template test references
@Composable
fun MyApplicationTheme(
    darkTheme: Boolean = true,
    content: @Composable () -> Unit,
) {
    HuntXProsTheme(darkTheme = darkTheme, content = content)
}
