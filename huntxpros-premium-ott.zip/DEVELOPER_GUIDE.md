# HUNTXPROS — Developer & Architecture Guide

Official engineering documentation for maintaining, extending, testing, and releasing the **HUNTXPROS** Android OTT + Live TV platform (`com.aistudio.huntxpros.ottxkp`).

---

## 1. Modular Package Architecture

- `com.example.ui.theme`
  - `Color.kt`: Centralized Obsidian Black (`#07070A`), Deep Charcoal (`#101218`), Crimson Red (`#E50914`), Metallic Silver (`#D2D7E0`), and Royal Gold (`#F5B82E`) palette.
  - `Type.kt`: Bundled local `.ttf` Google Fonts (`Bebas Neue` display headings + `Montserrat` UI typography).
  - `Theme.kt`: `HuntXProsTheme` providing Dark/Light color schemes, 12-language `LocalStrings`, and automatic `LayoutDirection.Rtl` switching for Urdu (`ur`) and Arabic (`ar`).
- `com.example.i18n`
  - `AppStrings.kt`: Complete UI string tables for English, Hindi, Urdu, Arabic, Bengali, Spanish, French, German, Portuguese, Japanese, Chinese, and Russian.
- `com.example.auth`
  - `AuthHelper.kt`: Google Sign-In via Jetpack `CredentialManager` (`GetSignInWithGoogleOption` for interactive sign-in, `GetGoogleIdOption` for silent startup session restore, and `ClearCredentialStateRequest` on logout).
- `com.example.data.model` & `com.example.data.repository`
  - `Models.kt`: Firestore-compatible data models (`CatalogItem`, `EpisodeItem`, `TvChannel`, `EpgProgram`, `WatchlistEntry`, `WatchHistoryEntry`, `FavoriteChannelEntry`, `ContentComment`, `ContentLike`, `PlaybackAnalyticsEvent`, `UploadJob`, `PlatformConfig`).
  - `HuntXProsRepository.kt`: Bound strictly to the named Cloud Firestore database (`R.string.firestore_database_id`).
- `com.example.data.storage`
  - `ResumableVideoUploadEngine.kt`: Streams mobile videos in 2 MB chunks (`chunkSizeBytes = 2_097_152`), computes cryptographic SHA-256 digests, supports pause/resume/retry, and performs `Content-Range` HTTP PUT uploads when a signed cloud endpoint is configured.
- `com.example.ui.player`
  - `HuntExoPlayerView.kt`: Media3 ExoPlayer (`1.5.1`) supporting HLS (`.m3u8`), DASH (`.mpd`), and progressive MP4 with speed control, quality caps, audio/subtitle track picker, fullscreen rotation, resume position, auto-play next episode, and HUNTXPROS watermark.
- `com.example.ui.screens`
  - `SplashAndAuthScreens.kt`, `HomeAndCatalogScreens.kt`, `ContentDetailScreen.kt`, `LiveTvScreen.kt`, `SettingsAndListsScreens.kt`, `AdminPanelScreen.kt`, `AdminUploadAndCatalogPanes.kt`, `AdminChannelsAnalyticsSettingsPanes.kt`.

---

## 2. Database Schema & Server-Side Security (`firestore.rules`)

All administrative mutations are protected server-side in `/firestore.rules` via `isVerifiedOwnerToken()`, which checks:
1. `request.auth != null`
2. `request.auth.token.email_verified == true`
3. `request.auth.token.email == "d92139816@gmail.com"`

### Extending Role-Based Access Control (Future Team Admins)
When you are ready to onboard sub-administrators (`Content Manager`, `Live TV Operator`, `Analytics Viewer`):
1. Add a top-level `/admin_roles/{userId}` collection in `firebase-blueprint.json` and `firestore.rules` writable **only** by `isVerifiedOwnerToken()`.
2. Add helper functions in `firestore.rules` (e.g., `hasRole(roleName)`) for single-document writes (`create`, `update`, `delete`), while keeping `allow list` zero-cost without cross-document `get()` calls.
3. Re-run `FIRESTORE_EMULATOR_HOST="127.0.0.1:8085" node --test firestore.test.js` and `gradle :app:testDebugUnitTest` before deploying rules.

---

## 3. How to Add New Categories, Pages, Icons & Buttons

- **Adding a New VOD Category**:
  1. Add the uppercase constant to `VOD_CONTENT_TYPES` in `AdminUploadAndCatalogPanes.kt` and update the allowed enum list in `firestore.rules` (`validCatalogItem`).
  2. Add localized title labels in `AppStrings.kt` and `CategoryCatalogGridScreen` (`HomeAndCatalogScreens.kt`).
- **Adding Icons & Reusable Buttons**:
  - Always import vector icons from `androidx.compose.material.icons.Icons` (use `Icons.AutoMirrored.Filled.*` for directional arrows so Urdu/Arabic RTL mirrors automatically).
  - Use `HuntPrimaryButton` (crimson pill CTA with loading spinner) or `HuntGlassButton` (charcoal bordered secondary CTA) from `DesignSystemComponents.kt`.
  - Assign a unique `Modifier.testTag("snake_case_name")` and non-null `contentDescription` to every interactive control, keeping touch targets `>= 48.dp`.

---

## 4. Cloud Object Storage, Resumable Uploads, Backup & CDN Integration

Never store full movies or episodes inside the Android APK or local device cache permanently, and never embed private service-account or S3 credentials in client code:
1. **Activate Firebase Cloud Storage (`gen-lang-client-0753326770.firebasestorage.app`)**:
   - Upgrade project `gen-lang-client-0753326770` to the **Google Cloud / Firebase Blaze (Pay-as-you-go)** billing plan in the Firebase Console (required by Firebase to initialize Storage buckets and serve large video egress).
   - Open **Firebase Console → Build → Storage → Get Started** to initialize `gen-lang-client-0753326770.firebasestorage.app`.
   - Open **Storage → Rules** and paste/publish `/storage.rules` from the repository root (`allow write` restricted strictly to `d92139816@gmail.com` with `email_verified == true`; `allow delete: if false` on `/masters/**` and `/hls/**`).
2. **Enable Object Versioning & 30-Day Soft Delete Recovery**:
   - Apply `/storage-backup-lifecycle.json` via Google Cloud CLI:
     ```bash
     gcloud storage buckets update gs://gen-lang-client-0753326770.firebasestorage.app \
       --versioning \
       --soft-delete-duration=30d \
       --lifecycle-file=storage-backup-lifecycle.json
     ```
3. **Resumable Mobile Uploads (`ResumableVideoUploadEngine.kt`)**:
   - Streams video in 2 MB chunks (`X-Goog-Upload-Protocol: resumable`), persists `resumableSessionUri` (`X-Goog-Upload-URL`) in Firestore `/upload_jobs/{jobId}`, queries `X-Goog-Upload-Size-Received` on resume after mobile network drops, and verifies end-to-end SHA-256 digests.
4. **Immutable Metadata Disaster Recovery (`/backup_snapshots`)**:
   - Open **Admin Panel → Settings → Immutable Disaster Recovery Vault** to create write-once (`allow update, delete: if false`) JSON snapshots of all catalog items, episodes, Live TV channels, and EPG schedules, and restore missing records with one tap.

---

## 5. Testing, Verification & Google Play Release

- **Run Firestore Security Rules Tests**:
  ```bash
  FIRESTORE_EMULATOR_HOST="127.0.0.1:8085" node --test firestore.test.js
  ```
- **Run Android JVM & Robolectric Tests**:
  ```bash
  gradle :app:testDebugUnitTest
  ```
- **Build Installable Debug APK**:
  ```bash
  gradle assembleDebug
  # Output: app/build/outputs/apk/debug/app-debug.apk
  ```
- **Build Signed Release App Bundle (`.aab`) for Google Play**:
  1. Generate a production upload keystore (`keytool -genkey -v -keystore upload-key.jks -keyalg RSA -keysize 2048 -validity 10000 -alias upload`).
  2. Register both the upload certificate and Google Play App Signing SHA-1 / SHA-256 fingerprints in your Firebase Project Settings (`gen-lang-client-0753326770`) so Google Sign-In works in production.
  3. Provide `KEYSTORE_PATH`, `STORE_PASSWORD`, and `KEY_PASSWORD` via secure CI environment variables and run `gradle bundleRelease`.
