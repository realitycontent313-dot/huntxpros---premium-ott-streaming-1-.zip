package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.defaultMinSize
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.HelpOutline
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowRight
import androidx.compose.material.icons.automirrored.filled.Logout
import androidx.compose.material.icons.filled.AdminPanelSettings
import androidx.compose.material.icons.filled.BookmarkRemove
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.ClosedCaption
import androidx.compose.material.icons.filled.DarkMode
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.HighQuality
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.Language
import androidx.compose.material.icons.filled.LiveTv
import androidx.compose.material.icons.filled.Movie
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.PrivacyTip
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Videocam
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.RadioButton
import androidx.compose.material3.RadioButtonDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import com.example.data.local.LocalAppPreferences
import com.example.data.model.CatalogItem
import com.example.data.model.FavoriteChannelEntry
import com.example.data.model.WatchHistoryEntry
import com.example.data.model.WatchlistEntry
import com.example.i18n.LocalStrings
import com.example.i18n.SupportedLanguages
import com.example.ui.components.ContinueWatchingCard
import com.example.ui.components.HuntCategoryChip
import com.example.ui.components.HuntPrimaryButton
import com.example.ui.theme.HuntBorderSubtle
import com.example.ui.theme.HuntCrimsonBright
import com.example.ui.theme.HuntCrimsonRed
import com.example.ui.theme.HuntElevatedCard
import com.example.ui.theme.HuntMetallicSilver
import com.example.ui.theme.HuntMutedSilver
import com.example.ui.theme.HuntObsidianBlack
import com.example.ui.theme.HuntPlatinumWhite
import com.example.ui.theme.HuntRoyalGold
import com.example.ui.theme.HuntSurfaceCard

@Composable
fun MyListAndHistoryScreen(
    watchlist: List<WatchlistEntry>,
    watchHistory: List<WatchHistoryEntry>,
    favoriteChannels: List<FavoriteChannelEntry>,
    catalog: List<CatalogItem>,
    initialTab: Int = 0,
    isOwnerAdmin: Boolean,
    onOpenContentDetail: (String) -> Unit,
    onRemoveWatchlistItem: (WatchlistEntry) -> Unit,
    onOpenLiveChannel: (String) -> Unit,
    onOpenSettings: () -> Unit,
    onOpenAdminPanel: () -> Unit,
) {
    val strings = LocalStrings.current
    var selectedTab by remember(initialTab) { mutableIntStateOf(initialTab) }
    val activeFavorites = remember(favoriteChannels) { favoriteChannels.filter { it.isFavorite } }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .testTag("my_list_and_history_screen"),
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 12.dp),
        ) {
            Text(
                text = strings.myList,
                style = MaterialTheme.typography.headlineSmall,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.weight(1f),
            )
            if (isOwnerAdmin) {
                IconButton(
                    onClick = onOpenAdminPanel,
                    modifier = Modifier.testTag("mylist_admin_btn"),
                ) {
                    Icon(
                        imageVector = Icons.Filled.AdminPanelSettings,
                        contentDescription = strings.adminPanel,
                        tint = HuntRoyalGold,
                    )
                }
            }
            IconButton(
                onClick = onOpenSettings,
                modifier = Modifier.testTag("mylist_settings_btn"),
            ) {
                Icon(
                    imageVector = Icons.Filled.Settings,
                    contentDescription = strings.settings,
                    tint = MaterialTheme.colorScheme.onBackground,
                )
            }
        }

        Row(
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 4.dp),
        ) {
            HuntCategoryChip(
                label = "${strings.myList} (${watchlist.size})",
                selected = selectedTab == 0,
                onClick = { selectedTab = 0 },
                testTag = "tab_watchlist",
            )
            HuntCategoryChip(
                label = "${strings.watchHistory} (${watchHistory.size})",
                selected = selectedTab == 1,
                onClick = { selectedTab = 1 },
                testTag = "tab_watch_history",
            )
            HuntCategoryChip(
                label = "${strings.favorites} (${activeFavorites.size})",
                selected = selectedTab == 2,
                onClick = { selectedTab = 2 },
                testTag = "tab_fav_channels",
            )
        }

        Spacer(modifier = Modifier.height(8.dp))

        when (selectedTab) {
            0 -> {
                if (watchlist.isEmpty()) {
                    EmptyCollectionPlaceholder(
                        title = strings.myList,
                        subtitle = "Movies, series, documentaries and shows you add to + My List will sync across your devices.",
                    )
                } else {
                    BoxWithConstraints(modifier = Modifier.fillMaxSize()) {
                        val cols = when {
                            maxWidth >= 840.dp -> 5
                            maxWidth >= 600.dp -> 4
                            else -> 3
                        }
                        LazyVerticalGrid(
                            columns = GridCells.Fixed(cols),
                            contentPadding = PaddingValues(16.dp),
                            horizontalArrangement = Arrangement.spacedBy(10.dp),
                            verticalArrangement = Arrangement.spacedBy(12.dp),
                            modifier = Modifier.fillMaxSize(),
                        ) {
                            items(watchlist, key = { it.id }) { entry ->
                                WatchlistGridCard(
                                    entry = entry,
                                    onClick = { onOpenContentDetail(entry.contentId) },
                                    onRemove = {
                                        val matched = catalog.firstOrNull { it.id == entry.contentId }
                                        if (matched != null) {
                                            onRemoveWatchlistItem(entry)
                                        } else {
                                            onRemoveWatchlistItem(entry)
                                        }
                                    },
                                )
                            }
                        }
                    }
                }
            }

            1 -> {
                if (watchHistory.isEmpty()) {
                    EmptyCollectionPlaceholder(
                        title = strings.watchHistory,
                        subtitle = "Titles and episodes you watch will save their exact playback position here for instant resume.",
                    )
                } else {
                    LazyColumn(
                        contentPadding = PaddingValues(16.dp),
                        verticalArrangement = Arrangement.spacedBy(14.dp),
                        modifier = Modifier.fillMaxSize(),
                    ) {
                        items(watchHistory, key = { it.id }) { entry ->
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(14.dp))
                                    .background(HuntSurfaceCard)
                                    .border(1.dp, HuntBorderSubtle, RoundedCornerShape(14.dp))
                                    .clickable { onOpenContentDetail(entry.contentId) }
                                    .padding(12.dp)
                                    .testTag("history_row_${entry.contentId}"),
                            ) {
                                ContinueWatchingCard(
                                    entry = entry,
                                    onClick = { onOpenContentDetail(entry.contentId) },
                                    modifier = Modifier.width(170.dp),
                                )
                                Spacer(modifier = Modifier.width(12.dp))
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = entry.title,
                                        style = MaterialTheme.typography.titleSmall,
                                        fontWeight = FontWeight.Bold,
                                        maxLines = 2,
                                        overflow = TextOverflow.Ellipsis,
                                    )
                                    entry.subtitle?.takeIf { it.isNotBlank() }?.let { sub ->
                                        Text(
                                            text = sub,
                                            style = MaterialTheme.typography.labelMedium,
                                            color = HuntCrimsonBright,
                                        )
                                    }
                                    Spacer(modifier = Modifier.height(6.dp))
                                    val posMin = (entry.positionMs / 60000L)
                                    val durMin = (entry.durationMs / 60000L).coerceAtLeast(1L)
                                    Text(
                                        text = if (entry.completed) "Completed" else "Watched ${posMin}m of ${durMin}m",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = HuntMutedSilver,
                                    )
                                }
                            }
                        }
                    }
                }
            }

            else -> {
                if (activeFavorites.isEmpty()) {
                    EmptyCollectionPlaceholder(
                        title = strings.favorites,
                        subtitle = "Tap the heart icon on any Live TV channel to pin it here for one-tap tuning.",
                    )
                } else {
                    LazyColumn(
                        contentPadding = PaddingValues(16.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp),
                        modifier = Modifier.fillMaxSize(),
                    ) {
                        items(activeFavorites, key = { it.id }) { fav ->
                            Card(
                                onClick = { onOpenLiveChannel(fav.channelId) },
                                shape = RoundedCornerShape(14.dp),
                                colors = CardDefaults.cardColors(containerColor = HuntSurfaceCard),
                                border = BorderStroke(1.dp, HuntBorderSubtle),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .testTag("fav_channel_item_${fav.channelId}"),
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    modifier = Modifier.padding(14.dp),
                                ) {
                                    Box(
                                        contentAlignment = Alignment.Center,
                                        modifier = Modifier
                                            .size(48.dp)
                                            .clip(RoundedCornerShape(10.dp))
                                            .background(HuntObsidianBlack),
                                    ) {
                                        if (fav.logoUrl.isNotBlank()) {
                                            AsyncImage(
                                                model = fav.logoUrl,
                                                contentDescription = fav.channelName,
                                                contentScale = ContentScale.Crop,
                                                modifier = Modifier.fillMaxSize(),
                                            )
                                        } else {
                                            Icon(
                                                imageVector = Icons.Filled.LiveTv,
                                                contentDescription = null,
                                                tint = HuntCrimsonBright,
                                            )
                                        }
                                    }
                                    Spacer(modifier = Modifier.width(12.dp))
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(
                                            text = fav.channelName,
                                            style = MaterialTheme.typography.titleSmall,
                                            fontWeight = FontWeight.Bold,
                                        )
                                        Text(
                                            text = fav.category,
                                            style = MaterialTheme.typography.labelSmall,
                                            color = HuntMutedSilver,
                                        )
                                    }
                                    Icon(
                                        imageVector = Icons.Filled.PlayArrow,
                                        contentDescription = "Tune Channel",
                                        tint = HuntCrimsonBright,
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun WatchlistGridCard(
    entry: WatchlistEntry,
    onClick: () -> Unit,
    onRemove: () -> Unit,
) {
    Card(
        onClick = onClick,
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = HuntSurfaceCard),
        border = BorderStroke(1.dp, HuntBorderSubtle),
        modifier = Modifier
            .fillMaxWidth()
            .aspectRatio(0.68f)
            .testTag("watchlist_card_${entry.contentId}"),
    ) {
        Box(modifier = Modifier.fillMaxSize()) {
            if (entry.posterUrl.isNotBlank()) {
                AsyncImage(
                    model = entry.posterUrl,
                    contentDescription = entry.title,
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.fillMaxSize(),
                )
            } else {
                Box(
                    contentAlignment = Alignment.Center,
                    modifier = Modifier
                        .fillMaxSize()
                        .background(HuntElevatedCard),
                ) {
                    Icon(Icons.Filled.Movie, contentDescription = null, tint = HuntCrimsonRed)
                }
            }
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(72.dp)
                    .align(Alignment.BottomCenter)
                    .background(
                        Brush.verticalGradient(listOf(Color.Transparent, HuntObsidianBlack.copy(alpha = 0.92f)))
                    ),
            )
            IconButton(
                onClick = onRemove,
                modifier = Modifier
                    .align(Alignment.TopEnd)
                    .padding(4.dp)
                    .size(36.dp)
                    .clip(CircleShape)
                    .background(HuntObsidianBlack.copy(alpha = 0.72f))
                    .testTag("remove_watchlist_${entry.contentId}"),
            ) {
                Icon(
                    imageVector = Icons.Filled.BookmarkRemove,
                    contentDescription = "Remove from My List",
                    tint = HuntPlatinumWhite,
                    modifier = Modifier.size(18.dp),
                )
            }
            Column(
                modifier = Modifier
                    .align(Alignment.BottomStart)
                    .padding(10.dp),
            ) {
                Text(
                    text = entry.title,
                    style = MaterialTheme.typography.labelLarge,
                    color = HuntPlatinumWhite,
                    fontWeight = FontWeight.Bold,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis,
                )
                Text(
                    text = entry.genre.ifBlank { entry.contentType },
                    style = MaterialTheme.typography.labelSmall,
                    color = HuntMetallicSilver,
                )
            }
        }
    }
}

@Composable
private fun EmptyCollectionPlaceholder(
    title: String,
    subtitle: String,
) {
    Box(
        contentAlignment = Alignment.Center,
        modifier = Modifier
            .fillMaxSize()
            .padding(32.dp),
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text(
                text = title,
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
            )
            Spacer(modifier = Modifier.height(6.dp))
            Text(
                text = subtitle,
                style = MaterialTheme.typography.bodyMedium,
                color = HuntMutedSilver,
            )
        }
    }
}

@Composable
fun SettingsScreen(
    prefs: LocalAppPreferences,
    displayName: String,
    email: String,
    avatarUrl: String?,
    isOwnerAdmin: Boolean,
    onBack: () -> Unit,
    onUpdateDisplayName: (String) -> Unit,
    onUpdateLanguage: (String) -> Unit,
    onUpdateDarkMode: (Boolean) -> Unit,
    onUpdateAutoPlay: (Boolean) -> Unit,
    onUpdateQuality: (String) -> Unit,
    onUpdateSubtitle: (String) -> Unit,
    onUpdateNotifications: (Boolean) -> Unit,
    onOpenWatchHistory: () -> Unit,
    onOpenAdminPanel: () -> Unit,
    onLogout: () -> Unit,
) {
    val strings = LocalStrings.current

    var showEditProfileDialog by remember { mutableStateOf(false) }
    var showLanguageDialog by remember { mutableStateOf(false) }
    var showQualityDialog by remember { mutableStateOf(false) }
    var showSubtitleDialog by remember { mutableStateOf(false) }
    var activeInfoDialog by remember { mutableStateOf<String?>(null) }

    BackHandler(onBack = onBack)

    val activeLang = SupportedLanguages.firstOrNull { it.code == prefs.languageCode }
    val qualityLabel = when (prefs.defaultQuality) {
        "1080P" -> "Full HD 1080p"
        "720P" -> "HD 720p"
        "480P" -> "SD 480p"
        "DATA_SAVER" -> "Data Saver"
        else -> "Auto"
    }
    val subtitleLabel = when (prefs.subtitleLanguage) {
        "en" -> "English"
        "hi" -> "Hindi (हिन्दी)"
        "ur" -> "Urdu (اردو)"
        "ar" -> "Arabic (العربية)"
        "es" -> "Spanish"
        "fr" -> "French"
        else -> "Off"
    }

    Box(
        contentAlignment = Alignment.TopCenter,
        modifier = Modifier
            .fillMaxSize()
            .testTag("settings_screen"),
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .widthIn(max = 680.dp)
                .verticalScroll(rememberScrollState())
                .padding(bottom = 32.dp),
        ) {
            // Top Header matching reference image
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 8.dp, vertical = 10.dp),
            ) {
                IconButton(
                    onClick = onBack,
                    modifier = Modifier.testTag("settings_back_button"),
                ) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                        contentDescription = "Back",
                        tint = MaterialTheme.colorScheme.onBackground,
                    )
                }
                Spacer(modifier = Modifier.width(4.dp))
                Text(
                    text = strings.settings,
                    style = MaterialTheme.typography.headlineSmall,
                    fontWeight = FontWeight.Bold,
                )
            }

            // Viewer Profile Card + Conditional Owner Admin Entry
            Card(
                shape = RoundedCornerShape(18.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 6.dp),
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            contentAlignment = Alignment.Center,
                            modifier = Modifier
                                .size(54.dp)
                                .clip(CircleShape)
                                .background(HuntCrimsonRed),
                        ) {
                            if (!avatarUrl.isNullOrBlank()) {
                                AsyncImage(
                                    model = avatarUrl,
                                    contentDescription = displayName,
                                    contentScale = ContentScale.Crop,
                                    modifier = Modifier.fillMaxSize(),
                                )
                            } else {
                                Text(
                                    text = displayName.firstOrNull()?.uppercase() ?: "H",
                                    style = MaterialTheme.typography.titleLarge,
                                    color = HuntPlatinumWhite,
                                    fontWeight = FontWeight.ExtraBold,
                                )
                            }
                        }
                        Spacer(modifier = Modifier.width(14.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = displayName,
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                            )
                            Text(
                                text = email,
                                style = MaterialTheme.typography.bodySmall,
                                color = HuntMutedSilver,
                            )
                        }
                        IconButton(
                            onClick = { showEditProfileDialog = true },
                            modifier = Modifier.testTag("edit_profile_button"),
                        ) {
                            Icon(
                                imageVector = Icons.Filled.Edit,
                                contentDescription = strings.editProfile,
                            )
                        }
                    }

                    if (isOwnerAdmin) {
                        Spacer(modifier = Modifier.height(14.dp))
                        HuntPrimaryButton(
                            text = "${strings.adminPanel} • ${strings.secureOwnerAccess}",
                            icon = Icons.Filled.AdminPanelSettings,
                            onClick = onOpenAdminPanel,
                            testTag = "settings_open_admin_panel_btn",
                            modifier = Modifier.fillMaxWidth(),
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            // Playback, Theme & Language Preferences Card (exact match to bottom-right mockup)
            Card(
                shape = RoundedCornerShape(18.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 6.dp),
            ) {
                Column {
                    SettingsSelectorRow(
                        icon = Icons.Filled.Language,
                        label = "${strings.languageLabel} / भाषा",
                        valueText = activeLang?.nativeName ?: "English",
                        onClick = { showLanguageDialog = true },
                        testTag = "settings_language_row",
                    )
                    SettingsDivider()
                    SettingsSwitchRow(
                        icon = Icons.Filled.DarkMode,
                        label = strings.darkMode,
                        checked = prefs.darkMode,
                        onCheckedChange = onUpdateDarkMode,
                        testTag = "settings_dark_mode_switch",
                    )
                    SettingsDivider()
                    SettingsSwitchRow(
                        icon = Icons.Filled.Videocam,
                        label = strings.autoPlay,
                        checked = prefs.autoPlay,
                        onCheckedChange = onUpdateAutoPlay,
                        testTag = "settings_autoplay_switch",
                    )
                    SettingsDivider()
                    SettingsSelectorRow(
                        icon = Icons.Filled.HighQuality,
                        label = strings.videoQuality,
                        valueText = qualityLabel,
                        onClick = { showQualityDialog = true },
                        testTag = "settings_quality_row",
                    )
                    SettingsDivider()
                    SettingsSelectorRow(
                        icon = Icons.Filled.ClosedCaption,
                        label = strings.subtitles,
                        valueText = subtitleLabel,
                        onClick = { showSubtitleDialog = true },
                        testTag = "settings_subtitle_row",
                    )
                    SettingsDivider()
                    SettingsSwitchRow(
                        icon = Icons.Filled.Notifications,
                        label = strings.notifications,
                        checked = prefs.notificationsEnabled,
                        onCheckedChange = onUpdateNotifications,
                        testTag = "settings_notifications_switch",
                    )
                    SettingsDivider()
                    SettingsLinkRow(
                        icon = Icons.Filled.History,
                        label = strings.watchHistory,
                        onClick = onOpenWatchHistory,
                        testTag = "settings_watch_history_row",
                    )
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            // About, Support & Legal Card
            Card(
                shape = RoundedCornerShape(18.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 6.dp),
            ) {
                Column {
                    SettingsLinkRow(
                        icon = Icons.Filled.Info,
                        label = "About HUNTXPROS",
                        onClick = { activeInfoDialog = "ABOUT" },
                        testTag = "settings_about_row",
                    )
                    SettingsDivider()
                    SettingsLinkRow(
                        icon = Icons.AutoMirrored.Filled.HelpOutline,
                        label = "Help & Support",
                        onClick = { activeInfoDialog = "HELP" },
                        testTag = "settings_help_row",
                    )
                    SettingsDivider()
                    SettingsLinkRow(
                        icon = Icons.Filled.PrivacyTip,
                        label = "Privacy Policy",
                        onClick = { activeInfoDialog = "PRIVACY" },
                        testTag = "settings_privacy_row",
                    )
                }
            }

            Spacer(modifier = Modifier.height(18.dp))

            OutlinedButton(
                onClick = onLogout,
                shape = RoundedCornerShape(14.dp),
                border = BorderStroke(1.dp, HuntCrimsonRed.copy(alpha = 0.7f)),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp)
                    .defaultMinSize(minHeight = 50.dp)
                    .testTag("settings_logout_button"),
            ) {
                Icon(
                    imageVector = Icons.AutoMirrored.Filled.Logout,
                    contentDescription = null,
                    tint = HuntCrimsonBright,
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = strings.logout,
                    style = MaterialTheme.typography.titleSmall,
                    color = HuntCrimsonBright,
                    fontWeight = FontWeight.Bold,
                )
            }
        }
    }

    if (showEditProfileDialog) {
        var draftName by remember(displayName) { mutableStateOf(displayName) }
        AlertDialog(
            onDismissRequest = { showEditProfileDialog = false },
            title = { Text(strings.editProfile) },
            text = {
                OutlinedTextField(
                    value = draftName,
                    onValueChange = { draftName = it },
                    label = { Text("Display Name") },
                    singleLine = true,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("edit_display_name_input"),
                )
            },
            confirmButton = {
                TextButton(
                    onClick = {
                        onUpdateDisplayName(draftName)
                        showEditProfileDialog = false
                    },
                ) {
                    Text("Save")
                }
            },
            dismissButton = {
                TextButton(onClick = { showEditProfileDialog = false }) {
                    Text("Cancel")
                }
            },
        )
    }

    if (showLanguageDialog) {
        AlertDialog(
            onDismissRequest = { showLanguageDialog = false },
            title = { Text("${strings.languageLabel} (12 Global Languages)") },
            text = {
                LazyColumn(modifier = Modifier.height(340.dp)) {
                    items(SupportedLanguages, key = { it.code }) { lang ->
                        val isSelected = lang.code == prefs.languageCode
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable {
                                    onUpdateLanguage(lang.code)
                                    showLanguageDialog = false
                                }
                                .padding(vertical = 10.dp, horizontal = 4.dp)
                                .testTag("lang_option_${lang.code}"),
                        ) {
                            RadioButton(
                                selected = isSelected,
                                onClick = {
                                    onUpdateLanguage(lang.code)
                                    showLanguageDialog = false
                                },
                                colors = RadioButtonDefaults.colors(selectedColor = HuntCrimsonRed),
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = lang.nativeName,
                                    style = MaterialTheme.typography.titleSmall,
                                    fontWeight = FontWeight.Bold,
                                )
                                Text(
                                    text = if (lang.isRtl) "${lang.englishName} • RTL Layout" else lang.englishName,
                                    style = MaterialTheme.typography.labelSmall,
                                    color = HuntMutedSilver,
                                )
                            }
                            if (isSelected) {
                                Icon(Icons.Filled.Check, contentDescription = null, tint = HuntCrimsonBright)
                            }
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { showLanguageDialog = false }) { Text("Close") }
            },
        )
    }

    if (showQualityDialog) {
        val qualities = listOf(
            "AUTO" to "Auto (Adaptive HLS/DASH)",
            "1080P" to "Full HD 1080p",
            "720P" to "HD 720p",
            "480P" to "SD 480p",
            "DATA_SAVER" to "Data Saver (360p Mobile)",
        )
        AlertDialog(
            onDismissRequest = { showQualityDialog = false },
            title = { Text(strings.videoQuality) },
            text = {
                Column {
                    qualities.forEach { (code, label) ->
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable {
                                    onUpdateQuality(code)
                                    showQualityDialog = false
                                }
                                .padding(vertical = 8.dp),
                        ) {
                            RadioButton(
                                selected = prefs.defaultQuality == code,
                                onClick = {
                                    onUpdateQuality(code)
                                    showQualityDialog = false
                                },
                                colors = RadioButtonDefaults.colors(selectedColor = HuntCrimsonRed),
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(label)
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { showQualityDialog = false }) { Text("Close") }
            },
        )
    }

    if (showSubtitleDialog) {
        val subtitleOptions = listOf(
            "OFF" to "Off",
            "en" to "English",
            "hi" to "Hindi (हिन्दी)",
            "ur" to "Urdu (اردو)",
            "ar" to "Arabic (العربية)",
            "es" to "Spanish (Español)",
            "fr" to "French (Français)",
        )
        AlertDialog(
            onDismissRequest = { showSubtitleDialog = false },
            title = { Text(strings.subtitles) },
            text = {
                Column {
                    subtitleOptions.forEach { (code, label) ->
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable {
                                    onUpdateSubtitle(code)
                                    showSubtitleDialog = false
                                }
                                .padding(vertical = 8.dp),
                        ) {
                            RadioButton(
                                selected = prefs.subtitleLanguage == code,
                                onClick = {
                                    onUpdateSubtitle(code)
                                    showSubtitleDialog = false
                                },
                                colors = RadioButtonDefaults.colors(selectedColor = HuntCrimsonRed),
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(label)
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { showSubtitleDialog = false }) { Text("Close") }
            },
        )
    }

    if (activeInfoDialog != null) {
        val (title, body) = when (activeInfoDialog) {
            "ABOUT" -> "About HUNTXPROS" to
                "HUNTXPROS Premium Entertainment Platform (v1.0)\n\n" +
                "Official OTT VOD & Live TV Android application engineered with Media3 ExoPlayer (HLS/DASH adaptive streaming), " +
                "Firebase Cloud Firestore real-time synchronization, Google Identity Credential Manager, and 12-language global RTL/LTR support."
            "HELP" -> "Help & Support" to
                "• Playback Buffering: Switch Video Quality to 'Auto' or 'Data Saver' on unstable mobile networks.\n" +
                "• Live TV Unavailable: Channels only stream verified company-authorized HLS/DASH manifests. Use the Retry button inside the player.\n" +
                "• Sync Across Devices: Sign in with the same Google account to restore Watch History and My List."
            else -> "Privacy & Authorized Content Policy" to
                "• Data Protection: Viewer profiles, watchlists, and playback history are isolated per user via server-side Firestore Security Rules.\n" +
                "• Authorized Media Only: HUNTXPROS strictly streams company-owned, licensed, or open-licensed media assets.\n" +
                "• Zero Broad Storage Access: Media selection uses the Android system Photo Picker without broad storage permissions."
        }
        AlertDialog(
            onDismissRequest = { activeInfoDialog = null },
            title = { Text(title, fontWeight = FontWeight.Bold) },
            text = { Text(body, style = MaterialTheme.typography.bodyMedium) },
            confirmButton = {
                TextButton(onClick = { activeInfoDialog = null }) { Text("OK") }
            },
        )
    }
}

@Composable
private fun SettingsDivider() {
    HorizontalDivider(
        color = MaterialTheme.colorScheme.outline.copy(alpha = 0.45f),
        modifier = Modifier.padding(horizontal = 16.dp),
    )
}

@Composable
private fun SettingsSelectorRow(
    icon: ImageVector,
    label: String,
    valueText: String,
    onClick: () -> Unit,
    testTag: String,
) {
    Row(
        verticalAlignment = Alignment.CenterVertically,
        modifier = Modifier
            .fillMaxWidth()
            .defaultMinSize(minHeight = 56.dp)
            .clickable(onClick = onClick)
            .padding(horizontal = 16.dp, vertical = 12.dp)
            .testTag(testTag),
    ) {
        Icon(
            imageVector = icon,
            contentDescription = null,
            tint = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.size(22.dp),
        )
        Spacer(modifier = Modifier.width(14.dp))
        Text(
            text = label,
            style = MaterialTheme.typography.bodyLarge,
            fontWeight = FontWeight.Medium,
            modifier = Modifier.weight(1f),
        )
        Text(
            text = valueText,
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
        Spacer(modifier = Modifier.width(4.dp))
        Icon(
            imageVector = Icons.Filled.KeyboardArrowDown,
            contentDescription = null,
            tint = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.size(18.dp),
        )
    }
}

@Composable
private fun SettingsSwitchRow(
    icon: ImageVector,
    label: String,
    checked: Boolean,
    onCheckedChange: (Boolean) -> Unit,
    testTag: String,
) {
    Row(
        verticalAlignment = Alignment.CenterVertically,
        modifier = Modifier
            .fillMaxWidth()
            .defaultMinSize(minHeight = 56.dp)
            .clickable { onCheckedChange(!checked) }
            .padding(horizontal = 16.dp, vertical = 8.dp),
    ) {
        Icon(
            imageVector = icon,
            contentDescription = null,
            tint = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.size(22.dp),
        )
        Spacer(modifier = Modifier.width(14.dp))
        Text(
            text = label,
            style = MaterialTheme.typography.bodyLarge,
            fontWeight = FontWeight.Medium,
            modifier = Modifier.weight(1f),
        )
        Switch(
            checked = checked,
            onCheckedChange = onCheckedChange,
            colors = SwitchDefaults.colors(
                checkedThumbColor = HuntPlatinumWhite,
                checkedTrackColor = HuntCrimsonRed,
                uncheckedThumbColor = HuntMetallicSilver,
                uncheckedTrackColor = HuntObsidianBlack,
            ),
            modifier = Modifier.testTag(testTag),
        )
    }
}

@Composable
private fun SettingsLinkRow(
    icon: ImageVector,
    label: String,
    onClick: () -> Unit,
    testTag: String,
) {
    Row(
        verticalAlignment = Alignment.CenterVertically,
        modifier = Modifier
            .fillMaxWidth()
            .defaultMinSize(minHeight = 54.dp)
            .clickable(onClick = onClick)
            .padding(horizontal = 16.dp, vertical = 12.dp)
            .testTag(testTag),
    ) {
        Icon(
            imageVector = icon,
            contentDescription = null,
            tint = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.size(22.dp),
        )
        Spacer(modifier = Modifier.width(14.dp))
        Text(
            text = label,
            style = MaterialTheme.typography.bodyLarge,
            fontWeight = FontWeight.Medium,
            modifier = Modifier.weight(1f),
        )
        Icon(
            imageVector = Icons.AutoMirrored.Filled.KeyboardArrowRight,
            contentDescription = null,
            tint = MaterialTheme.colorScheme.onSurfaceVariant,
        )
    }
}
