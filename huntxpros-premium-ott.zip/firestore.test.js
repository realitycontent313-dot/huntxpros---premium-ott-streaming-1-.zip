const {
  initializeTestEnvironment,
  assertFails,
  assertSucceeds,
} = require("@firebase/rules-unit-testing");
const { test, before, after, beforeEach } = require("node:test");
const fs = require("node:fs");

let testEnv;
const PROJECT_ID = process.env.GCP_PROJECT || "demo-no-project";
const DATABASE_ID = "ai-studio-android-huntxpro-f6c76b4a-176a-46dd-839d-ea3b3c60bb44";
const OWNER_UID = "owner_001";
const OWNER_EMAIL = "d92139816@gmail.com";
const ALICE_UID = "alice_123";
const BOB_UID = "bob_456";

const [emulatorHost, emulatorPortStr] = (process.env.FIRESTORE_EMULATOR_HOST || "127.0.0.1:8085").split(":");
const emulatorPort = parseInt(emulatorPortStr, 10);

function getDb(ctx) {
  return ctx.firestore(DATABASE_ID);
}

before(async () => {
  const rules = fs.readFileSync("./firestore.rules", "utf8");
  testEnv = await initializeTestEnvironment({
    projectId: PROJECT_ID,
    firestore: {
      rules,
      host: emulatorHost,
      port: emulatorPort,
    },
  });
});

after(async () => {
  if (testEnv) {
    await testEnv.cleanup();
  }
});

beforeEach(async () => {
  if (testEnv) {
    await testEnv.clearFirestore();
  }
});

test("1. Unauthenticated caller cannot query published catalog items", async () => {
  const unauthDb = getDb(testEnv.unauthenticatedContext());
  await assertFails(
    unauthDb.collection("catalog_items").where("publicationStatus", "==", "PUBLISHED").get()
  );
});

test("2. Query Trust Test: Viewer fails unfiltered catalog_items query, succeeds with publicationStatus == PUBLISHED", async () => {
  const now = new Date();
  await testEnv.withSecurityRulesDisabled(async (ctx) => {
    const db = getDb(ctx);
    await db.collection("catalog_items").doc("movie_1").set({
      title: "Authorized Cinema Feature",
      description: "Official studio release.",
      contentType: "MOVIE",
      genre: "Action",
      language: "English",
      releaseYear: 2026,
      durationMinutes: 120,
      ageRating: "U/A 13+",
      posterUrl: "https://example.com/poster.png",
      bannerUrl: "https://example.com/banner.png",
      streamUrl: "https://test-streams.mux.dev/x36xhzz/x36xhzz.m3u8",
      streamFormat: "HLS",
      isFeaturedHero: true,
      isTrending: true,
      isPopular: true,
      seasonsCount: 0,
      publicationStatus: "PUBLISHED",
      ownerId: OWNER_UID,
      viewsCount: 0,
      likesCount: 0,
      createdAt: now,
      updatedAt: now,
    });
    await db.collection("catalog_items").doc("draft_1").set({
      title: "Unreleased Draft",
      description: "Uploading in progress.",
      contentType: "MOVIE",
      genre: "Drama",
      language: "Hindi",
      releaseYear: 2026,
      durationMinutes: 90,
      ageRating: "U/A 13+",
      posterUrl: "https://example.com/p2.png",
      bannerUrl: "https://example.com/b2.png",
      streamUrl: "",
      streamFormat: "HLS",
      isFeaturedHero: false,
      isTrending: false,
      isPopular: false,
      seasonsCount: 0,
      publicationStatus: "DRAFT",
      ownerId: OWNER_UID,
      viewsCount: 0,
      likesCount: 0,
      createdAt: now,
      updatedAt: now,
    });
  });

  const aliceDb = getDb(testEnv.authenticatedContext(ALICE_UID));
  // Unfiltered query must fail because draft_1 is not PUBLISHED
  await assertFails(aliceDb.collection("catalog_items").get());
  // Aligned query succeeds
  await assertSucceeds(
    aliceDb.collection("catalog_items").where("publicationStatus", "==", "PUBLISHED").get()
  );
  // Direct read of draft fails
  await assertFails(aliceDb.collection("catalog_items").doc("draft_1").get());
});

test("3. Self-Admin Escalation Blocked: Viewer cannot write to /admins", async () => {
  const aliceDb = getDb(testEnv.authenticatedContext(ALICE_UID));
  await assertFails(
    aliceDb.collection("admins").doc(ALICE_UID).set({
      uid: ALICE_UID,
      role: "OWNER",
      createdAt: new Date(),
    })
  );
});

test("4. Email Spoofing Test: Unverified owner email is rejected from admin writes", async () => {
  const spoofDb = getDb(
    testEnv.authenticatedContext("spoof_uid", {
      email: OWNER_EMAIL,
      email_verified: false,
    })
  );
  const now = new Date();
  await assertFails(
    spoofDb.collection("catalog_items").doc("spoof_movie").set({
      title: "Spoofed",
      description: "Spoofed desc",
      contentType: "MOVIE",
      genre: "Action",
      language: "English",
      releaseYear: 2026,
      durationMinutes: 100,
      ageRating: "U",
      posterUrl: "https://example.com/p.png",
      bannerUrl: "https://example.com/b.png",
      streamUrl: "https://example.com/stream.m3u8",
      streamFormat: "HLS",
      isFeaturedHero: false,
      isTrending: false,
      isPopular: false,
      seasonsCount: 0,
      publicationStatus: "PUBLISHED",
      ownerId: "spoof_uid",
      viewsCount: 0,
      likesCount: 0,
      createdAt: now,
      updatedAt: now,
    })
  );
});

test("5. Verified Owner can create catalog item, but premature publish with empty streamUrl is rejected", async () => {
  const ownerDb = getDb(
    testEnv.authenticatedContext(OWNER_UID, {
      email: OWNER_EMAIL,
      email_verified: true,
    })
  );
  const now = new Date();
  const basePayload = {
    title: "Official Feature",
    description: "Official description",
    contentType: "MOVIE",
    genre: "Action",
    language: "Hindi",
    releaseYear: 2026,
    durationMinutes: 135,
    ageRating: "U/A 13+",
    posterUrl: "https://example.com/p.png",
    bannerUrl: "https://example.com/b.png",
    streamUrl: "",
    streamFormat: "HLS",
    isFeaturedHero: true,
    isTrending: true,
    isPopular: true,
    seasonsCount: 0,
    publicationStatus: "PUBLISHED",
    ownerId: OWNER_UID,
    viewsCount: 0,
    likesCount: 0,
    createdAt: now,
    updatedAt: now,
  };

  // Empty streamUrl while PUBLISHED must fail
  await assertFails(ownerDb.collection("catalog_items").doc("bad_pub").set(basePayload));

  // Valid streamUrl while PUBLISHED succeeds
  await assertSucceeds(
    ownerDb.collection("catalog_items").doc("good_pub").set({
      ...basePayload,
      streamUrl: "https://test-streams.mux.dev/x36xhzz/x36xhzz.m3u8",
    })
  );
});

test("6. Multi-User Isolation & Shadow Field Rejection on /users and subcollections", async () => {
  const now = new Date();
  const aliceDb = getDb(testEnv.authenticatedContext(ALICE_UID));
  const bobDb = getDb(testEnv.authenticatedContext(BOB_UID));

  await assertSucceeds(
    aliceDb.collection("users").doc(ALICE_UID).set({
      userId: ALICE_UID,
      displayName: "Alice Viewer",
      preferredLanguage: "hi",
      darkMode: true,
      autoPlay: true,
      defaultQuality: "AUTO",
      subtitleLanguage: "OFF",
      notificationsEnabled: true,
      createdAt: now,
      updatedAt: now,
    })
  );

  // Bob cannot read Alice's profile
  await assertFails(bobDb.collection("users").doc(ALICE_UID).get());

  // Shadow update with ghost field isAdmin must fail
  await assertFails(
    aliceDb.collection("users").doc(ALICE_UID).update({
      displayName: "Hacked",
      isAdmin: true,
      updatedAt: now,
    })
  );

  // Cross-user watch_history read fails
  await assertSucceeds(
    aliceDb.collection("users").doc(ALICE_UID).collection("watch_history").doc("h1").set({
      userId: ALICE_UID,
      contentId: "good_pub",
      contentType: "MOVIE",
      title: "Official Feature",
      thumbnailUrl: "https://example.com/t.png",
      streamUrl: "https://example.com/s.m3u8",
      positionMs: 42000,
      durationMs: 7200000,
      completed: false,
      createdAt: now,
      updatedAt: now,
    })
  );
  await assertFails(
    bobDb.collection("users").doc(ALICE_UID).collection("watch_history").doc("h1").get()
  );
});

test("7. Storage Config Privacy & Upload Deletion Protection", async () => {
  const now = new Date();
  const ownerDb = getDb(
    testEnv.authenticatedContext(OWNER_UID, {
      email: OWNER_EMAIL,
      email_verified: true,
    })
  );
  const aliceDb = getDb(testEnv.authenticatedContext(ALICE_UID));

  await assertSucceeds(
    ownerDb.collection("platform_config").doc("storage").set({
      configType: "STORAGE",
      storageProvider: "Cloud Object Storage + CDN",
      masterBucketName: "huntxpros-master-vault",
      ownerId: OWNER_UID,
      updatedAt: now,
    })
  );
  await assertSucceeds(
    ownerDb.collection("platform_config").doc("branding").set({
      configType: "BRANDING",
      brandName: "HUNTXPROS",
      tagline: "Premium Entertainment",
      watermarkEnabled: true,
      ownerId: OWNER_UID,
      updatedAt: now,
    })
  );

  // Viewer can read public branding, but CANNOT read private storage config
  await assertSucceeds(aliceDb.collection("platform_config").doc("branding").get());
  await assertFails(aliceDb.collection("platform_config").doc("storage").get());

  // Protected upload job cannot be deleted until deleteProtected == false
  await assertSucceeds(
    ownerDb.collection("upload_jobs").doc("job_1").set({
      fileName: "master_feature.mp4",
      mimeType: "video/mp4",
      fileSizeBytes: 104857600,
      sha256Checksum: "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855",
      chunkSizeBytes: 5242880,
      uploadedBytes: 104857600,
      totalChunks: 20,
      uploadedChunks: 20,
      status: "COMPLETED",
      storageProvider: "GCS_SIGNED_MULTIPART",
      masterStoragePath: "masters/2026/master_feature.mp4",
      hlsManifestUrl: "https://cdn.example.com/hls/master_feature/index.m3u8",
      thumbnailUrl: "https://cdn.example.com/thumbs/master_feature.jpg",
      linkedContentId: "good_pub",
      deleteProtected: true,
      errorMessage: "",
      ownerId: OWNER_UID,
      createdAt: now,
      updatedAt: now,
    })
  );
  await assertFails(ownerDb.collection("upload_jobs").doc("job_1").delete());
});

test("8. Strict Separation: Viewers cannot create/read/list upload_jobs or read/list playback_events", async () => {
  const now = new Date();
  const aliceDb = getDb(testEnv.authenticatedContext(ALICE_UID, { email: "viewer@example.com", email_verified: true }));

  // Viewer cannot create an upload job even with their own UID
  await assertFails(
    aliceDb.collection("upload_jobs").doc("rogue_upload").set({
      fileName: "viewer_pirated.mp4",
      mimeType: "video/mp4",
      fileSizeBytes: 5000000,
      sha256Checksum: "abc",
      chunkSizeBytes: 2097152,
      uploadedBytes: 0,
      totalChunks: 3,
      uploadedChunks: 0,
      status: "UPLOADING",
      storageProvider: "FIREBASE_STORAGE_RESUMABLE",
      masterStoragePath: "masters/rogue.mp4",
      hlsManifestUrl: "",
      thumbnailUrl: "",
      linkedContentId: "",
      deleteProtected: true,
      errorMessage: "",
      ownerId: ALICE_UID,
      createdAt: now,
      updatedAt: now,
    })
  );

  // Viewer cannot list upload_jobs even when filtering by their own UID
  await assertFails(aliceDb.collection("upload_jobs").where("ownerId", "==", ALICE_UID).get());

  // Viewer can append their own playback event, but CANNOT list or scrape global playback_events
  await assertSucceeds(
    aliceDb.collection("playback_events").doc("evt_alice_1").set({
      userId: ALICE_UID,
      contentId: "movie_1",
      contentTitle: "Authorized Feature",
      contentType: "MOVIE",
      category: "Action",
      watchedSeconds: 180,
      completed: false,
      eventDate: "2026-11-02",
      createdAt: now,
    })
  );
  await assertFails(aliceDb.collection("playback_events").get());
  await assertFails(aliceDb.collection("playback_events").doc("evt_alice_1").get());
});

test("9. Viewer Counter Tampering Blocked: Viewers can increment viewsCount by +1 only, never +500 or alter streamUrl", async () => {
  const now = new Date();
  await testEnv.withSecurityRulesDisabled(async (ctx) => {
    await getDb(ctx).collection("catalog_items").doc("pub_movie_9").set({
      title: "Protected Feature",
      description: "Official cinema.",
      contentType: "MOVIE",
      genre: "Thriller",
      language: "English",
      releaseYear: 2026,
      durationMinutes: 110,
      ageRating: "U/A 13+",
      posterUrl: "https://example.com/p.png",
      bannerUrl: "https://example.com/b.png",
      streamUrl: "https://test-streams.mux.dev/x36xhzz/x36xhzz.m3u8",
      streamFormat: "HLS",
      isFeaturedHero: false,
      isTrending: false,
      isPopular: false,
      seasonsCount: 0,
      publicationStatus: "PUBLISHED",
      ownerId: OWNER_UID,
      viewsCount: 10,
      likesCount: 5,
      createdAt: now,
      updatedAt: now,
    });
  });

  const aliceDb = getDb(testEnv.authenticatedContext(ALICE_UID));
  // Legitimate +1 view increment succeeds
  await assertSucceeds(
    aliceDb.collection("catalog_items").doc("pub_movie_9").update({
      viewsCount: 11,
      updatedAt: now,
    })
  );
  // Fraudulent +500 jump fails
  await assertFails(
    aliceDb.collection("catalog_items").doc("pub_movie_9").update({
      viewsCount: 511,
      updatedAt: now,
    })
  );
  // Attempting to overwrite streamUrl fails
  await assertFails(
    aliceDb.collection("catalog_items").doc("pub_movie_9").update({
      streamUrl: "https://malicious.example.com/hijack.m3u8",
      updatedAt: now,
    })
  );
});

test("10. Resumable Session Persistence & Immutable Owner Disaster Recovery Snapshots", async () => {
  const now = new Date();
  const ownerDb = getDb(
    testEnv.authenticatedContext(OWNER_UID, {
      email: OWNER_EMAIL,
      email_verified: true,
    })
  );
  const aliceDb = getDb(testEnv.authenticatedContext(ALICE_UID));

  // Owner can persist resumableSessionUri on upload_jobs
  await assertSucceeds(
    ownerDb.collection("upload_jobs").doc("resumable_job_1").set({
      fileName: "4k_master.mp4",
      mimeType: "video/mp4",
      fileSizeBytes: 524288000,
      sha256Checksum: "",
      chunkSizeBytes: 2097152,
      uploadedBytes: 4194304,
      totalChunks: 250,
      uploadedChunks: 2,
      status: "PAUSED",
      storageProvider: "FIREBASE_STORAGE_RESUMABLE",
      masterStoragePath: "masters/4k_master.mp4",
      hlsManifestUrl: "",
      resumableSessionUri: "https://firebasestorage.googleapis.com/v0/b/gen-lang-client-0753326770.firebasestorage.app/o?uploadType=resumable&upload_id=session123",
      thumbnailUrl: "",
      linkedContentId: "",
      deleteProtected: true,
      errorMessage: "",
      ownerId: OWNER_UID,
      createdAt: now,
      updatedAt: now,
    })
  );

  // Owner creates immutable backup snapshot
  await assertSucceeds(
    ownerDb.collection("backup_snapshots").doc("snap_1").set({
      label: "Pre-Release Recovery Point",
      catalogCount: 8,
      episodesCount: 3,
      channelsCount: 4,
      epgCount: 12,
      payloadJson: "{\"catalog\":[]}",
      ownerId: OWNER_UID,
      createdAt: now,
    })
  );

  // Viewer cannot read or list backup snapshots
  await assertFails(aliceDb.collection("backup_snapshots").doc("snap_1").get());
  await assertFails(aliceDb.collection("backup_snapshots").get());

  // Immutable recovery guarantee: even accidental delete on backup_snapshots is rejected
  await assertFails(ownerDb.collection("backup_snapshots").doc("snap_1").delete());
});

