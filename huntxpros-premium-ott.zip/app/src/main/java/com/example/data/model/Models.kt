package com.example.data.model

import com.google.firebase.Timestamp
import com.google.firebase.firestore.DocumentId
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.IgnoreExtraProperties
import com.google.firebase.firestore.ServerTimestamp

const val OWNER_ADMIN_EMAIL = "d92139816@gmail.com"

sealed interface UiState<out T> {
    data object Loading : UiState<Nothing>
    data class Success<T>(val data: T) : UiState<T>
    data class Error(val message: String) : UiState<Nothing>
}

@IgnoreExtraProperties
data class UserProfile(
    @DocumentId val id: String = "",
    val userId: String = "",
    val displayName: String = "",
    val avatarUrl: String? = null,
    val preferredLanguage: String = "en",
    val darkMode: Boolean = true,
    val autoPlay: Boolean = true,
    val defaultQuality: String = "AUTO",
    val subtitleLanguage: String = "OFF",
    val notificationsEnabled: Boolean = true,
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null,
) {
    fun toCreateMap(uid: String): Map<String, Any> = mapOf(
        "userId" to uid,
        "displayName" to displayName.ifBlank { "Viewer" }.take(80),
        "avatarUrl" to avatarUrl?.takeIf { it.isNotBlank() },
        "preferredLanguage" to preferredLanguage.ifBlank { "en" },
        "darkMode" to darkMode,
        "autoPlay" to autoPlay,
        "defaultQuality" to defaultQuality.ifBlank { "AUTO" },
        "subtitleLanguage" to subtitleLanguage.ifBlank { "OFF" },
        "notificationsEnabled" to notificationsEnabled,
        "createdAt" to FieldValue.serverTimestamp(),
        "updatedAt" to FieldValue.serverTimestamp(),
    ).filterValues { it != null }.mapValues { it.value!! }
}

@IgnoreExtraProperties
data class WatchlistEntry(
    @DocumentId val id: String = "",
    val userId: String = "",
    val contentId: String = "",
    val contentType: String = "MOVIE",
    val title: String = "",
    val posterUrl: String = "",
    val genre: String = "",
    @ServerTimestamp val createdAt: Timestamp? = null,
)

@IgnoreExtraProperties
data class WatchHistoryEntry(
    @DocumentId val id: String = "",
    val userId: String = "",
    val contentId: String = "",
    val episodeId: String? = null,
    val contentType: String = "MOVIE",
    val title: String = "",
    val subtitle: String? = null,
    val thumbnailUrl: String = "",
    val streamUrl: String = "",
    val positionMs: Long = 0L,
    val durationMs: Long = 0L,
    val completed: Boolean = false,
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null,
)

@IgnoreExtraProperties
data class FavoriteChannelEntry(
    @DocumentId val id: String = "",
    val userId: String = "",
    val channelId: String = "",
    val channelName: String = "",
    val logoUrl: String = "",
    val category: String = "ENTERTAINMENT",
    val isFavorite: Boolean = true,
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null,
)

@IgnoreExtraProperties
data class CatalogItem(
    @DocumentId val id: String = "",
    val title: String = "",
    val description: String = "",
    val contentType: String = "MOVIE", // MOVIE, SERIES, SHORT_FILM, SHOW, DOCUMENTARY, NEWS, SPORTS, EDUCATIONAL
    val genre: String = "Action",
    val tags: List<String> = emptyList(),
    val language: String = "English",
    val releaseYear: Long = 2026L,
    val durationMinutes: Long = 120L,
    val ageRating: String = "U/A 13+",
    val posterUrl: String = "",
    val bannerUrl: String = "",
    val trailerUrl: String? = null,
    val streamUrl: String = "",
    val streamFormat: String = "HLS", // HLS, DASH, MP4
    val castCrew: List<String> = emptyList(),
    val isFeaturedHero: Boolean = false,
    val isTrending: Boolean = false,
    val isPopular: Boolean = false,
    val seasonsCount: Long = 0L,
    val publicationStatus: String = "DRAFT", // DRAFT, UPLOADING, PROCESSING, PUBLISHED, UNPUBLISHED
    val storageObjectKey: String? = null,
    val masterChecksumSha256: String? = null,
    val fileSizeBytes: Long? = null,
    val ownerId: String = "",
    val viewsCount: Long = 0L,
    val likesCount: Long = 0L,
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null,
) {
    fun toFirestoreMap(ownerUid: String, preserveCreatedAt: Timestamp? = null): Map<String, Any> = mapOf(
        "title" to title.trim().take(200),
        "description" to description.trim().take(4000),
        "contentType" to contentType,
        "genre" to genre.trim().take(100),
        "tags" to tags.take(10).map { it.take(50) },
        "language" to language.trim().take(50),
        "releaseYear" to releaseYear.coerceIn(1900L, 2100L),
        "durationMinutes" to durationMinutes.coerceIn(0L, 10000L),
        "ageRating" to ageRating.trim().take(20),
        "posterUrl" to posterUrl.trim().take(1500),
        "bannerUrl" to bannerUrl.trim().take(1500),
        "trailerUrl" to trailerUrl?.trim()?.takeIf { it.isNotEmpty() }?.take(1500),
        "streamUrl" to streamUrl.trim().take(1500),
        "streamFormat" to streamFormat,
        "castCrew" to castCrew.take(15).map { it.take(100) },
        "isFeaturedHero" to isFeaturedHero,
        "isTrending" to isTrending,
        "isPopular" to isPopular,
        "seasonsCount" to seasonsCount.coerceIn(0L, 100L),
        "publicationStatus" to publicationStatus,
        "storageObjectKey" to storageObjectKey?.takeIf { it.isNotBlank() }?.take(500),
        "masterChecksumSha256" to masterChecksumSha256?.takeIf { it.isNotBlank() }?.take(128),
        "fileSizeBytes" to fileSizeBytes,
        "ownerId" to ownerUid,
        "viewsCount" to viewsCount.coerceAtLeast(0L),
        "likesCount" to likesCount.coerceAtLeast(0L),
        "createdAt" to (preserveCreatedAt ?: FieldValue.serverTimestamp()),
        "updatedAt" to FieldValue.serverTimestamp(),
    ).filterValues { it != null }.mapValues { it.value!! }
}

@IgnoreExtraProperties
data class EpisodeItem(
    @DocumentId val id: String = "",
    val seriesId: String = "",
    val seasonNumber: Long = 1L,
    val episodeNumber: Long = 1L,
    val title: String = "",
    val description: String = "",
    val thumbnailUrl: String = "",
    val durationMinutes: Long = 45L,
    val streamUrl: String = "",
    val streamFormat: String = "HLS",
    val publicationStatus: String = "PUBLISHED",
    val ownerId: String = "",
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null,
) {
    fun toFirestoreMap(ownerUid: String, preserveCreatedAt: Timestamp? = null): Map<String, Any> = mapOf(
        "seriesId" to seriesId.trim(),
        "seasonNumber" to seasonNumber.coerceIn(1L, 100L),
        "episodeNumber" to episodeNumber.coerceIn(1L, 2000L),
        "title" to title.trim().take(200),
        "description" to description.trim().take(2000),
        "thumbnailUrl" to thumbnailUrl.trim().take(1500),
        "durationMinutes" to durationMinutes.coerceIn(1L, 1000L),
        "streamUrl" to streamUrl.trim().take(1500),
        "streamFormat" to streamFormat,
        "publicationStatus" to publicationStatus,
        "ownerId" to ownerUid,
        "createdAt" to (preserveCreatedAt ?: FieldValue.serverTimestamp()),
        "updatedAt" to FieldValue.serverTimestamp(),
    )
}

@IgnoreExtraProperties
data class TvChannel(
    @DocumentId val id: String = "",
    val name: String = "",
    val logoUrl: String = "",
    val description: String = "",
    val category: String = "ENTERTAINMENT", // SPORTS, NEWS, ENTERTAINMENT, MOVIES, MUSIC, EDUCATIONAL
    val language: String = "English",
    val streamUrl: String = "",
    val streamFormat: String = "HLS",
    val currentProgramTitle: String = "",
    val currentProgramTime: String = "",
    val upcomingProgramTitle: String = "",
    val upcomingProgramTime: String = "",
    val isFeatured: Boolean = false,
    val isLive: Boolean = true,
    val publicationStatus: String = "PUBLISHED",
    val ownerId: String = "",
    val viewsCount: Long = 0L,
    val watchTimeMinutes: Long = 0L,
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null,
) {
    fun toFirestoreMap(ownerUid: String, preserveCreatedAt: Timestamp? = null): Map<String, Any> = mapOf(
        "name" to name.trim().take(150),
        "logoUrl" to logoUrl.trim().take(1500),
        "description" to description.trim().take(2000),
        "category" to category,
        "language" to language.trim().take(50),
        "streamUrl" to streamUrl.trim().take(1500),
        "streamFormat" to streamFormat,
        "currentProgramTitle" to currentProgramTitle.trim().take(200),
        "currentProgramTime" to currentProgramTime.trim().take(80),
        "upcomingProgramTitle" to upcomingProgramTitle.trim().take(200),
        "upcomingProgramTime" to upcomingProgramTime.trim().take(80),
        "isFeatured" to isFeatured,
        "isLive" to isLive,
        "publicationStatus" to publicationStatus,
        "ownerId" to ownerUid,
        "viewsCount" to viewsCount.coerceAtLeast(0L),
        "watchTimeMinutes" to watchTimeMinutes.coerceAtLeast(0L),
        "createdAt" to (preserveCreatedAt ?: FieldValue.serverTimestamp()),
        "updatedAt" to FieldValue.serverTimestamp(),
    )
}

@IgnoreExtraProperties
data class EpgProgram(
    @DocumentId val id: String = "",
    val channelId: String = "",
    val channelName: String = "",
    val programTitle: String = "",
    val synopsis: String = "",
    val category: String = "LIVE",
    val startTimeLabel: String = "",
    val endTimeLabel: String = "",
    val isLiveNow: Boolean = false,
    val publicationStatus: String = "PUBLISHED",
    val ownerId: String = "",
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null,
) {
    fun toFirestoreMap(ownerUid: String, preserveCreatedAt: Timestamp? = null): Map<String, Any> = mapOf(
        "channelId" to channelId.trim(),
        "channelName" to channelName.trim().take(150),
        "programTitle" to programTitle.trim().take(200),
        "synopsis" to synopsis.trim().take(1000),
        "category" to category.trim().take(60),
        "startTimeLabel" to startTimeLabel.trim().take(60),
        "endTimeLabel" to endTimeLabel.trim().take(60),
        "isLiveNow" to isLiveNow,
        "publicationStatus" to publicationStatus,
        "ownerId" to ownerUid,
        "createdAt" to (preserveCreatedAt ?: FieldValue.serverTimestamp()),
        "updatedAt" to FieldValue.serverTimestamp(),
    )
}

@IgnoreExtraProperties
data class ContentComment(
    @DocumentId val id: String = "",
    val contentId: String = "",
    val userId: String = "",
    val authorName: String = "",
    val text: String = "",
    val visibility: String = "PUBLIC",
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null,
)

@IgnoreExtraProperties
data class ContentLike(
    @DocumentId val id: String = "",
    val contentId: String = "",
    val userId: String = "",
    val visibility: String = "PUBLIC",
    @ServerTimestamp val createdAt: Timestamp? = null,
)

@IgnoreExtraProperties
data class PlaybackAnalyticsEvent(
    @DocumentId val id: String = "",
    val userId: String = "",
    val contentId: String = "",
    val contentTitle: String = "",
    val contentType: String = "MOVIE",
    val category: String = "Action",
    val watchedSeconds: Long = 0L,
    val completed: Boolean = false,
    val eventDate: String = "2026-11-02",
    @ServerTimestamp val createdAt: Timestamp? = null,
)

@IgnoreExtraProperties
data class UploadJob(
    @DocumentId val id: String = "",
    val fileName: String = "",
    val mimeType: String = "video/mp4",
    val fileSizeBytes: Long = 0L,
    val sha256Checksum: String = "",
    val chunkSizeBytes: Long = 2_097_152L,
    val uploadedBytes: Long = 0L,
    val totalChunks: Long = 1L,
    val uploadedChunks: Long = 0L,
    val status: String = "QUEUED",
    val storageProvider: String = "AWAITING_CONFIGURATION",
    val masterStoragePath: String = "",
    val hlsManifestUrl: String = "",
    val resumableSessionUri: String = "",
    val thumbnailUrl: String = "",
    val linkedContentId: String = "",
    val deleteProtected: Boolean = true,
    val errorMessage: String = "",
    val ownerId: String = "",
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null,
) {
    fun toFirestoreMap(ownerUid: String, preserveCreatedAt: Timestamp? = null): Map<String, Any> = mapOf(
        "fileName" to fileName.trim().ifBlank { "video.mp4" }.take(255),
        "mimeType" to mimeType.trim().ifBlank { "video/mp4" }.take(100),
        "fileSizeBytes" to fileSizeBytes.coerceAtLeast(0L),
        "sha256Checksum" to sha256Checksum.take(128),
        "chunkSizeBytes" to chunkSizeBytes.coerceAtLeast(1024L),
        "uploadedBytes" to uploadedBytes.coerceIn(0L, fileSizeBytes.coerceAtLeast(0L)),
        "totalChunks" to totalChunks.coerceAtLeast(1L),
        "uploadedChunks" to uploadedChunks.coerceIn(0L, totalChunks.coerceAtLeast(1L)),
        "status" to status,
        "storageProvider" to storageProvider.take(100),
        "masterStoragePath" to masterStoragePath.take(500),
        "hlsManifestUrl" to hlsManifestUrl.take(1500),
        "resumableSessionUri" to resumableSessionUri.take(2000),
        "thumbnailUrl" to thumbnailUrl.take(1500),
        "linkedContentId" to linkedContentId.take(128),
        "deleteProtected" to deleteProtected,
        "errorMessage" to errorMessage.take(1000),
        "ownerId" to ownerUid,
        "createdAt" to (preserveCreatedAt ?: FieldValue.serverTimestamp()),
        "updatedAt" to FieldValue.serverTimestamp(),
    )
}

@IgnoreExtraProperties
data class PlatformConfig(
    @DocumentId val id: String = "",
    val configType: String = "BRANDING", // BRANDING, STORAGE, SYSTEM_STATUS
    val brandName: String = "HUNTXPROS",
    val tagline: String = "Premium Entertainment",
    val customLogoUrl: String = "",
    val watermarkEnabled: Boolean = true,
    val storageProvider: String = "",
    val masterBucketName: String = "",
    val cdnBaseUrl: String = "",
    val signedUploadEndpoint: String = "",
    val backupReplicationEnabled: Boolean = false,
    val systemHealthy: Boolean = true,
    val statusMessage: String = "All Systems Running",
    val ownerId: String = "",
    @ServerTimestamp val updatedAt: Timestamp? = null,
)

@IgnoreExtraProperties
data class BackupSnapshot(
    @DocumentId val id: String = "",
    val label: String = "",
    val catalogCount: Long = 0L,
    val episodesCount: Long = 0L,
    val channelsCount: Long = 0L,
    val epgCount: Long = 0L,
    val payloadJson: String = "{}",
    val ownerId: String = "",
    @ServerTimestamp val createdAt: Timestamp? = null,
)

data class StorageHealthStatus(
    val checkedAt: String = "",
    val bucketName: String = "",
    val isReachableAndWritable: Boolean = false,
    val httpCode: Int = 0,
    val summaryMessage: String = "",
)

data class AnalyticsSummary(
    val totalViews: Long = 0L,
    val uniqueViewers: Int = 0,
    val totalWatchTimeMinutes: Long = 0L,
    val averageWatchSeconds: Long = 0L,
    val completionRatePercent: Int = 0,
    val totalLikes: Int = 0,
    val totalComments: Int = 0,
    val topVideos: List<Pair<String, Long>> = emptyList(),
    val popularMovies: List<CatalogItem> = emptyList(),
    val popularSeries: List<CatalogItem> = emptyList(),
    val channelStats: List<TvChannel> = emptyList(),
    val dateWiseViews: Map<String, Int> = emptyMap(),
    val categoryWiseViews: Map<String, Int> = emptyMap(),
)

