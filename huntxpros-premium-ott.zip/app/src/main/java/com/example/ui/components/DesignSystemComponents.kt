package com.example.ui.components

import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.defaultMinSize
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowRight
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material.icons.filled.Movie
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Schedule
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.R
import com.example.data.model.CatalogItem
import com.example.data.model.TvChannel
import com.example.data.model.WatchHistoryEntry
import com.example.i18n.LocalStrings
import com.example.ui.theme.HuntBorderSubtle
import com.example.ui.theme.HuntCrimsonBright
import com.example.ui.theme.HuntCrimsonRed
import com.example.ui.theme.HuntElevatedCard
import com.example.ui.theme.HuntMetallicSilver
import com.example.ui.theme.HuntMutedSilver
import com.example.ui.theme.HuntObsidianBlack
import com.example.ui.theme.HuntPlatinumWhite
import com.example.ui.theme.HuntSurfaceCard

@Composable
fun HuntBrandHeaderLogo(
    customLogoUrl: String = "",
    tagline: String = LocalStrings.current.brandTagline,
    iconSize: Dp = 38.dp,
    showTagline: Boolean = true,
    modifier: Modifier = Modifier,
) {
    Row(
        verticalAlignment = Alignment.CenterVertically,
        modifier = modifier.testTag("huntxpros_brand_header"),
    ) {
        if (customLogoUrl.isNotBlank()) {
            AsyncImage(
                model = customLogoUrl,
                contentDescription = "HUNTXPROS Official Logo",
                contentScale = ContentScale.Fit,
                placeholder = painterResource(id = R.drawable.huntxpros_logo),
                error = painterResource(id = R.drawable.huntxpros_logo),
                modifier = Modifier
                    .size(iconSize)
                    .clip(RoundedCornerShape(8.dp)),
            )
        } else {
            Image(
                painter = painterResource(id = R.drawable.huntxpros_logo),
                contentDescription = "HUNTXPROS Official Logo",
                contentScale = ContentScale.Fit,
                modifier = Modifier
                    .size(iconSize)
                    .clip(RoundedCornerShape(8.dp)),
            )
        }
        Spacer(modifier = Modifier.width(10.dp))
        Column {
            Text(
                text = buildAnnotatedString {
                    withStyle(SpanStyle(color = HuntPlatinumWhite, fontWeight = FontWeight.ExtraBold)) {
                        append("HUNT")
                    }
                    withStyle(SpanStyle(color = HuntCrimsonBright, fontWeight = FontWeight.Black)) {
                        append("X")
                    }
                    withStyle(SpanStyle(color = HuntMetallicSilver, fontWeight = FontWeight.ExtraBold)) {
                        append("PROS")
                    }
                },
                style = MaterialTheme.typography.titleMedium.copy(letterSpacing = 1.2.sp),
                maxLines = 1,
            )
            if (showTagline) {
                Text(
                    text = tagline,
                    style = MaterialTheme.typography.labelSmall,
                    color = HuntMutedSilver,
                    maxLines = 1,
                )
            }
        }
    }
}

@Composable
fun HuntPrimaryButton(
    text: String,
    onClick: () -> Unit,
    icon: ImageVector? = null,
    isLoading: Boolean = false,
    enabled: Boolean = true,
    testTag: String = "primary_action_button",
    modifier: Modifier = Modifier,
) {
    Button(
        onClick = onClick,
        enabled = enabled && !isLoading,
        shape = RoundedCornerShape(50),
        colors = ButtonDefaults.buttonColors(
            containerColor = HuntCrimsonRed,
            contentColor = HuntPlatinumWhite,
            disabledContainerColor = HuntCrimsonRed.copy(alpha = 0.45f),
            disabledContentColor = HuntPlatinumWhite.copy(alpha = 0.6f),
        ),
        contentPadding = PaddingValues(horizontal = 20.dp, vertical = 12.dp),
        modifier = modifier
            .defaultMinSize(minHeight = 48.dp)
            .testTag(testTag),
    ) {
        if (isLoading) {
            CircularProgressIndicator(
                color = HuntPlatinumWhite,
                strokeWidth = 2.dp,
                modifier = Modifier.size(18.dp),
            )
        } else {
            if (icon != null) {
                Icon(
                    imageVector = icon,
                    contentDescription = null,
                    modifier = Modifier.size(20.dp),
                )
                Spacer(modifier = Modifier.width(6.dp))
            }
            Text(
                text = text,
                style = MaterialTheme.typography.labelLarge,
                fontWeight = FontWeight.Bold,
            )
        }
    }
}

@Composable
fun HuntGlassButton(
    text: String,
    onClick: () -> Unit,
    icon: ImageVector? = null,
    testTag: String = "secondary_glass_button",
    modifier: Modifier = Modifier,
) {
    OutlinedButton(
        onClick = onClick,
        shape = RoundedCornerShape(50),
        border = BorderStroke(1.dp, HuntBorderSubtle),
        colors = ButtonDefaults.outlinedButtonColors(
            containerColor = HuntElevatedCard.copy(alpha = 0.88f),
            contentColor = HuntPlatinumWhite,
        ),
        contentPadding = PaddingValues(horizontal = 18.dp, vertical = 12.dp),
        modifier = modifier
            .defaultMinSize(minHeight = 48.dp)
            .testTag(testTag),
    ) {
        if (icon != null) {
            Icon(
                imageVector = icon,
                contentDescription = null,
                modifier = Modifier.size(18.dp),
            )
            Spacer(modifier = Modifier.width(6.dp))
        }
        Text(
            text = text,
            style = MaterialTheme.typography.labelLarge,
        )
    }
}

@Composable
fun HuntCategoryChip(
    label: String,
    selected: Boolean,
    onClick: () -> Unit,
    testTag: String = "category_chip_$label",
) {
    Surface(
        onClick = onClick,
        shape = RoundedCornerShape(50),
        color = if (selected) HuntCrimsonRed else HuntSurfaceCard,
        border = if (selected) null else BorderStroke(1.dp, HuntBorderSubtle),
        modifier = Modifier
            .defaultMinSize(minHeight = 40.dp)
            .testTag(testTag),
    ) {
        Box(
            contentAlignment = Alignment.Center,
            modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp),
        ) {
            Text(
                text = label,
                style = MaterialTheme.typography.labelLarge,
                color = if (selected) HuntPlatinumWhite else HuntMetallicSilver,
                fontWeight = if (selected) FontWeight.Bold else FontWeight.Medium,
            )
        }
    }
}

@Composable
fun SectionHeaderRow(
    title: String,
    onSeeAll: (() -> Unit)? = null,
) {
    val strings = LocalStrings.current
    Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween,
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 8.dp),
    ) {
        Text(
            text = title,
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.onBackground,
        )
        if (onSeeAll != null) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier
                    .clip(RoundedCornerShape(8.dp))
                    .clickable(onClick = onSeeAll)
                    .padding(horizontal = 8.dp, vertical = 6.dp)
                    .testTag("see_all_$title"),
            ) {
                Text(
                    text = strings.seeAll,
                    style = MaterialTheme.typography.labelMedium,
                    color = HuntMetallicSilver,
                )
                Icon(
                    imageVector = Icons.AutoMirrored.Filled.KeyboardArrowRight,
                    contentDescription = strings.seeAll,
                    tint = HuntMetallicSilver,
                    modifier = Modifier.size(16.dp),
                )
            }
        }
    }
}

@Composable
fun PosterContentCard(
    item: CatalogItem,
    onClick: () -> Unit,
    width: Dp = 122.dp,
    modifier: Modifier = Modifier,
) {
    Card(
        onClick = onClick,
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = HuntSurfaceCard),
        elevation = CardDefaults.cardElevation(defaultElevation = 6.dp),
        modifier = modifier
            .width(width)
            .aspectRatio(0.68f)
            .border(1.dp, HuntBorderSubtle.copy(alpha = 0.6f), RoundedCornerShape(12.dp))
            .testTag("poster_card_${item.id}"),
    ) {
        Box(modifier = Modifier.fillMaxSize()) {
            if (item.posterUrl.isNotBlank()) {
                AsyncImage(
                    model = item.posterUrl,
                    contentDescription = item.title,
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.fillMaxSize(),
                )
            } else {
                Box(
                    contentAlignment = Alignment.Center,
                    modifier = Modifier
                        .fillMaxSize()
                        .background(
                            Brush.linearGradient(
                                listOf(HuntElevatedCard, HuntObsidianBlack)
                            )
                        ),
                ) {
                    Icon(
                        imageVector = Icons.Filled.Movie,
                        contentDescription = null,
                        tint = HuntCrimsonRed,
                        modifier = Modifier.size(36.dp),
                    )
                }
            }

            // Bottom dark gradient + title + red play indicator matching reference mockup
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(74.dp)
                    .align(Alignment.BottomCenter)
                    .background(
                        Brush.verticalGradient(
                            listOf(Color.Transparent, HuntObsidianBlack.copy(alpha = 0.94f))
                        )
                    )
            )

            Column(
                modifier = Modifier
                    .align(Alignment.BottomStart)
                    .padding(10.dp),
            ) {
                Text(
                    text = item.title,
                    style = MaterialTheme.typography.labelLarge,
                    color = HuntPlatinumWhite,
                    fontWeight = FontWeight.Bold,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis,
                )
                Spacer(modifier = Modifier.height(3.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Filled.PlayArrow,
                        contentDescription = null,
                        tint = HuntCrimsonBright,
                        modifier = Modifier.size(14.dp),
                    )
                    Spacer(modifier = Modifier.width(3.dp))
                    Text(
                        text = item.streamFormat,
                        style = MaterialTheme.typography.labelSmall,
                        color = HuntMetallicSilver,
                    )
                }
            }
        }
    }
}

@Composable
fun ContinueWatchingCard(
    entry: WatchHistoryEntry,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val progress = if (entry.durationMs > 0L) {
        (entry.positionMs.toFloat() / entry.durationMs.toFloat()).coerceIn(0.03f, 1f)
    } else {
        0.15f
    }
    val remainingSec = ((entry.durationMs - entry.positionMs).coerceAtLeast(0L)) / 1000L
    val remFormatted = String.format("%d:%02d:%02d", remainingSec / 3600, (remainingSec % 3600) / 60, remainingSec % 60)

    Column(
        modifier = modifier
            .width(230.dp)
            .clickable(onClick = onClick)
            .testTag("continue_card_${entry.contentId}"),
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(126.dp)
                .clip(RoundedCornerShape(12.dp))
                .background(HuntSurfaceCard)
                .border(1.dp, HuntBorderSubtle, RoundedCornerShape(12.dp)),
        ) {
            if (entry.thumbnailUrl.isNotBlank()) {
                AsyncImage(
                    model = entry.thumbnailUrl,
                    contentDescription = entry.title,
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.fillMaxSize(),
                )
            }
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(HuntObsidianBlack.copy(alpha = 0.35f))
            )
            // Centered translucent Play circle matching reference UI
            Box(
                contentAlignment = Alignment.Center,
                modifier = Modifier
                    .size(44.dp)
                    .align(Alignment.Center)
                    .clip(CircleShape)
                    .background(HuntObsidianBlack.copy(alpha = 0.72f))
                    .border(1.5.dp, HuntPlatinumWhite, CircleShape),
            ) {
                Icon(
                    imageVector = Icons.Filled.PlayArrow,
                    contentDescription = "Resume ${entry.title}",
                    tint = HuntPlatinumWhite,
                    modifier = Modifier.size(26.dp),
                )
            }

            if (entry.durationMs > 0L) {
                Surface(
                    shape = RoundedCornerShape(6.dp),
                    color = HuntObsidianBlack.copy(alpha = 0.82f),
                    modifier = Modifier
                        .align(Alignment.BottomEnd)
                        .padding(8.dp),
                ) {
                    Text(
                        text = remFormatted,
                        style = MaterialTheme.typography.labelSmall,
                        color = HuntPlatinumWhite,
                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp),
                    )
                }
            }

            LinearProgressIndicator(
                progress = { progress },
                color = HuntCrimsonRed,
                trackColor = HuntPlatinumWhite.copy(alpha = 0.25f),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(3.5.dp)
                    .align(Alignment.BottomCenter),
            )
        }
        Spacer(modifier = Modifier.height(6.dp))
        Text(
            text = entry.title,
            style = MaterialTheme.typography.labelLarge,
            color = MaterialTheme.colorScheme.onBackground,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
        )
        entry.subtitle?.takeIf { it.isNotBlank() }?.let { sub ->
            Text(
                text = sub,
                style = MaterialTheme.typography.bodySmall,
                color = HuntMutedSilver,
                maxLines = 1,
            )
        }
    }
}

@Composable
fun LivePulseBadge(
    label: String = LocalStrings.current.liveBadge,
    modifier: Modifier = Modifier,
) {
    val transition = rememberInfiniteTransition(label = "live_pulse")
    val pulseAlpha by transition.animateFloat(
        initialValue = 1f,
        targetValue = 0.45f,
        animationSpec = infiniteRepeatable(tween(750), RepeatMode.Reverse),
        label = "pulse_alpha",
    )

    Surface(
        shape = RoundedCornerShape(6.dp),
        color = HuntCrimsonRed,
        modifier = modifier,
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp),
        ) {
            Box(
                modifier = Modifier
                    .size(6.dp)
                    .alpha(pulseAlpha)
                    .clip(CircleShape)
                    .background(HuntPlatinumWhite),
            )
            Spacer(modifier = Modifier.width(5.dp))
            Text(
                text = label,
                style = MaterialTheme.typography.labelSmall,
                color = HuntPlatinumWhite,
                fontWeight = FontWeight.ExtraBold,
            )
        }
    }
}

@Composable
fun ChannelRowCard(
    channel: TvChannel,
    isSelected: Boolean,
    isFavorite: Boolean,
    onPlayClick: () -> Unit,
    onFavoriteClick: () -> Unit,
    onEpgClick: () -> Unit,
    modifier: Modifier = Modifier,
) {
    Card(
        onClick = onPlayClick,
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(
            containerColor = if (isSelected) HuntElevatedCard else HuntSurfaceCard
        ),
        border = BorderStroke(
            width = if (isSelected) 1.5.dp else 1.dp,
            color = if (isSelected) HuntCrimsonRed else HuntBorderSubtle,
        ),
        modifier = modifier
            .fillMaxWidth()
            .testTag("channel_card_${channel.id}"),
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
        ) {
            Box(
                contentAlignment = Alignment.Center,
                modifier = Modifier
                    .size(54.dp)
                    .clip(RoundedCornerShape(10.dp))
                    .background(HuntObsidianBlack)
                    .border(1.dp, HuntBorderSubtle, RoundedCornerShape(10.dp)),
            ) {
                if (channel.logoUrl.isNotBlank()) {
                    AsyncImage(
                        model = channel.logoUrl,
                        contentDescription = channel.name,
                        contentScale = ContentScale.Crop,
                        modifier = Modifier.fillMaxSize(),
                    )
                } else {
                    Text(
                        text = channel.name.take(3).uppercase(),
                        style = MaterialTheme.typography.titleSmall,
                        color = HuntCrimsonBright,
                        fontWeight = FontWeight.Black,
                    )
                }
            }

            Spacer(modifier = Modifier.width(12.dp))

            Column(modifier = Modifier.weight(1f)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = channel.name,
                        style = MaterialTheme.typography.titleSmall,
                        color = HuntPlatinumWhite,
                        fontWeight = FontWeight.Bold,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.weight(1f, fill = false),
                    )
                    if (channel.isLive) {
                        Spacer(modifier = Modifier.width(8.dp))
                        LivePulseBadge()
                    }
                }
                Spacer(modifier = Modifier.height(3.dp))
                Text(
                    text = channel.currentProgramTitle.ifBlank { channel.category },
                    style = MaterialTheme.typography.bodySmall,
                    color = HuntMetallicSilver,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                )
                if (channel.upcomingProgramTitle.isNotBlank()) {
                    Text(
                        text = "Next: ${channel.upcomingProgramTitle} (${channel.upcomingProgramTime})",
                        style = MaterialTheme.typography.labelSmall,
                        color = HuntMutedSilver,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                    )
                }
            }

            IconButton(
                onClick = onEpgClick,
                modifier = Modifier.testTag("epg_btn_${channel.id}"),
            ) {
                Icon(
                    imageVector = Icons.Filled.Schedule,
                    contentDescription = "EPG Schedule",
                    tint = HuntMetallicSilver,
                )
            }

            IconButton(
                onClick = onFavoriteClick,
                modifier = Modifier.testTag("fav_channel_btn_${channel.id}"),
            ) {
                Icon(
                    imageVector = if (isFavorite) Icons.Filled.Favorite else Icons.Filled.FavoriteBorder,
                    contentDescription = "Favorite Channel",
                    tint = if (isFavorite) HuntCrimsonBright else HuntMutedSilver,
                )
            }

            Surface(
                shape = CircleShape,
                color = HuntObsidianBlack,
                border = BorderStroke(1.dp, HuntBorderSubtle),
                modifier = Modifier.size(38.dp),
            ) {
                Box(contentAlignment = Alignment.Center) {
                    Icon(
                        imageVector = Icons.Filled.PlayArrow,
                        contentDescription = "Play ${channel.name}",
                        tint = HuntPlatinumWhite,
                        modifier = Modifier.size(20.dp),
                    )
                }
            }
        }
    }
}
